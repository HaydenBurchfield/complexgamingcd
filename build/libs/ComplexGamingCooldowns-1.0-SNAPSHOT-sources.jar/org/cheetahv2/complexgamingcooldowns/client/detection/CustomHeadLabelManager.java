package org.cheetahv2.complexgamingcooldowns.client.detection;

import org.cheetahv2.complexgamingcooldowns.client.ComplexgamingcooldownsClient;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;

/**
 * Tracks and renders custom above-head labels over specific players.
 * Labels expire automatically after the specified duration.
 * Used by custom enchants like Love Birds to render "❤ STUNNED ❤" above target players.
 */
public class CustomHeadLabelManager {

    // Maps playerName -> expiry timestamp
    private static final Map<String, Long>   labelExpiry = new ConcurrentHashMap<>();
    // Maps playerName -> label text
    private static final Map<String, String> labelText   = new ConcurrentHashMap<>();

    public static void registerLabel(String playerName, String text, long durationMs) {
        labelExpiry.put(playerName, System.currentTimeMillis() + durationMs);
        labelText.put(playerName, text);
    }

    public static boolean hasLabel(String playerName) {
        Long expiry = labelExpiry.get(playerName);
        return expiry != null && expiry > System.currentTimeMillis();
    }

    public static String getLabel(String playerName) {
        return labelText.getOrDefault(playerName, "");
    }

    public static void tick() {
        long now = System.currentTimeMillis();
        labelExpiry.entrySet().removeIf(e -> {
            if (e.getValue() <= now) {
                labelText.remove(e.getKey());
                return true;
            }
            return false;
        });
    }

    /**
     * Renders above-head labels in the world for all active target effects.
     * Called from WorldRenderEvents.AFTER_ENTITIES.
     */
    public static void renderHeadLabels(
            net.minecraft.class_4587 matrices,
            net.minecraft.class_4184 camera,
            class_310 mc) {

        if (mc == null || mc.field_1687 == null || labelExpiry.isEmpty()) return;
        if (matrices == null || camera == null) return;

        class_327 tr = mc.field_1772;
        long now = System.currentTimeMillis();

        float scale  = Math.max(0.5f, Math.min(4.0f, ComplexgamingcooldownsClient.HUD_SETTINGS.labelScale));
        float ds     = 0.025f * scale;
        float height = ComplexgamingcooldownsClient.HUD_SETTINGS.labelHeightOffset + 0.8f;

        net.minecraft.class_4597.class_4598 imm =
                mc.method_22940().method_23000();

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;

            String name = p.method_5477().getString();
            Long expiry = labelExpiry.get(name);
            if (expiry == null || expiry <= now) {
                labelExpiry.remove(name);
                labelText.remove(name);
                continue;
            }

            String text = labelText.getOrDefault(name, "");
            if (text.isEmpty()) continue;

            // Pulse alpha for last 500ms
            long rem = expiry - now;
            float alpha = (rem < 500L) ? (rem / 500f) : 1f;
            int alphaByte = (int)(alpha * 255);
            int col = (alphaByte << 24) | 0xFFAA00;

            int width = tr.method_1727(text);

            matrices.method_22903();
            matrices.method_22904(
                    p.method_23317() - camera.method_71156().field_1352,
                    p.method_23318() + p.method_17682() + height - camera.method_71156().field_1351,
                    p.method_23321() - camera.method_71156().field_1350);
            matrices.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(camera.method_19329()));
            matrices.method_22905(-ds, -ds, ds);

            tr.method_27522(
                    class_2561.method_43470(text),
                    -width / 2f,
                    0f,
                    col,
                    false,
                    matrices.method_23760().method_23761(),
                    imm,
                    class_327.class_6415.field_33994,
                    0x20000000,
                    15728880);

            matrices.method_22909();
        }

        imm.method_22993();
    }
}
