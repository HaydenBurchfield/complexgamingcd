package org.cheetahv2.complexgamingcooldowns.client.detection;

import org.cheetahv2.complexgamingcooldowns.client.ComplexgamingcooldownsClient;
import org.cheetahv2.complexgamingcooldowns.client.util.ConfigHelper;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Lark ability tracker.
 *
 * YOUR OWN state machine (triggered by equipping a Lark weapon in main hand):
 *
 *   [equip]
 *      │
 *      ▼
 *   BUFF (+50%)  ──5 s──►  NORMAL  ──5 s──►  COOLDOWN (-50%)  ──30 s──►  IDLE
 *                                                  ▲
 *                                           [equip again]  ← resets the 30 s timer
 *
 * ENEMY tracking state machine (per enemy player):
 *
 *   [enemy equips lark]
 *      │
 *      ├─ if was IDLE/BUFF/NORMAL ──► ENEMY_BUFF  (+50%, RED label)  ──5s──► ENEMY_NORMAL ──5s──► ENEMY_COOLDOWN ──30s──► ENEMY_IDLE
 *      │
 *      └─ if was ENEMY_COOLDOWN   ──► ENEMY_COOLDOWN reset timer (GRAY label, still on cd)
 */
public class LarkManager {
    public static final Path FILE = Paths.get("config", "complexgamingcooldowns", "lark.json");

    // =========================================================================
    //  ENEMY LARK STATE TRACKING
    // =========================================================================

    public enum EnemyLarkState { IDLE, BUFF, NORMAL, COOLDOWN }

    public static class EnemyLarkData {
        public EnemyLarkState state = EnemyLarkState.IDLE;
        public long stateStartMs    = 0;
        public int  level           = 0;
        public boolean wasHoldingLark = false;

        // Phase durations — mirror the global config at the time of equip
        public long buffMs;
        public long normalMs;
        public long cooldownMs;

        public EnemyLarkData(long buffMs, long normalMs, long cooldownMs) {
            this.buffMs     = buffMs;
            this.normalMs   = normalMs;
            this.cooldownMs = cooldownMs;
        }

        public long remaining() {
            if (state == EnemyLarkState.IDLE) return 0;
            long elapsed = System.currentTimeMillis() - stateStartMs;
            long total = switch (state) {
                case BUFF     -> buffMs;
                case NORMAL   -> normalMs;
                case COOLDOWN -> cooldownMs;
                default       -> 0;
            };
            return Math.max(0, total - elapsed);
        }

        /**
         * Called every tick when we detect the enemy is holding a Lark weapon.
         * Returns true if the state changed (equip event fired).
         */
        public boolean onEquipDetected(int larkLevel, long buffMs, long normalMs, long cooldownMs) {
            this.level = larkLevel;
            if (!wasHoldingLark) {
                // Rising edge — player just pulled out their lark
                wasHoldingLark = true;
                if (state == EnemyLarkState.COOLDOWN) {
                    // Re-equip during cooldown: reset timer, stay in COOLDOWN (gray label)
                    this.buffMs     = buffMs;
                    this.normalMs   = normalMs;
                    this.cooldownMs = cooldownMs;
                    stateStartMs    = System.currentTimeMillis();
                } else {
                    // Fresh equip: start BUFF (red label, dangerous)
                    this.buffMs     = buffMs;
                    this.normalMs   = normalMs;
                    this.cooldownMs = cooldownMs;
                    state        = EnemyLarkState.BUFF;
                    stateStartMs = System.currentTimeMillis();
                }
                return true;
            }
            return false;
        }

        public void onUnequip() {
            wasHoldingLark = false;
            // Do NOT reset state — the timer keeps running even if they swap weapons
        }

        /** Advance phase transitions each tick. */
        public void tick() {
            if (remaining() == 0) {
                switch (state) {
                    case BUFF     -> { state = EnemyLarkState.NORMAL;   stateStartMs = System.currentTimeMillis(); }
                    case NORMAL   -> { state = EnemyLarkState.COOLDOWN; stateStartMs = System.currentTimeMillis(); }
                    case COOLDOWN -> state = EnemyLarkState.IDLE;
                    default       -> {}
                }
            }
        }

        /** True if this enemy is actively buffed (+50%) — show RED label. */
        public boolean isBuffed() { return state == EnemyLarkState.BUFF; }

        /** True if this enemy is on cooldown (-50%) — show GRAY label. */
        public boolean isOnCooldown() { return state == EnemyLarkState.COOLDOWN; }

        /** True if label should be shown at all (any non-idle state). */
        public boolean shouldShowLabel() { return state != EnemyLarkState.IDLE; }
    }

    // Maps playerName -> their lark tracking data
    private final Map<String, EnemyLarkData> enemyData = new ConcurrentHashMap<>();

    // =========================================================================
    //  YOUR OWN STATE
    // =========================================================================

    // ---------- config (persisted) ----------
    public boolean alertEnabled = true;
    public long buffMs     = 5_000;
    public long normalMs   = 5_000;
    public long cooldownMs = 30_000;
    public String headLabel = "⚔ LARK {roman}";

    // ---------- runtime state ----------
    public enum State { IDLE, BUFF, NORMAL, COOLDOWN }
    public State state = State.IDLE;
    public long stateStartMs = 0;

    /** Tracks the previous main-hand item so we can detect the moment the player equips a Lark weapon. */
    private boolean wasHoldingLark = false;

    // =========================================================================
    //  PERSISTENCE
    // =========================================================================

    public static class SaveData {
        public long buffMs, normalMs, cooldownMs;
        public String headLabel;
        public boolean alertEnabled;
    }

    public void save() {
        SaveData d = new SaveData();
        d.buffMs       = buffMs;
        d.normalMs     = normalMs;
        d.cooldownMs   = cooldownMs;
        d.headLabel    = headLabel;
        d.alertEnabled = alertEnabled;
        ConfigHelper.save(FILE, d);
    }

    public void load() {
        SaveData d = ConfigHelper.load(FILE, SaveData.class);
        if (d != null) {
            if (d.buffMs     > 0) buffMs     = d.buffMs;
            if (d.normalMs   > 0) normalMs   = d.normalMs;
            if (d.cooldownMs > 0) cooldownMs = d.cooldownMs;
            if (d.headLabel  != null) headLabel = d.headLabel;
            alertEnabled = d.alertEnabled;
        }
    }

    // =========================================================================
    //  CHAT-TRIGGER SHIMS (called by ComplexgamingcooldownsClient)
    // =========================================================================

    /** Manually force the BUFF phase — used by chat-based trigger in ComplexgamingcooldownsClient. */
    public void onChatBuff() {
        state        = State.BUFF;
        stateStartMs = System.currentTimeMillis();
    }

    /** Manually force the NORMAL phase (neutral window between buff and cooldown). */
    public void onChatDebuff() {
        state        = State.NORMAL;
        stateStartMs = System.currentTimeMillis();
    }

    /** Manually force the COOLDOWN phase. */
    public void onChatCooldown() {
        state        = State.COOLDOWN;
        stateStartMs = System.currentTimeMillis();
    }

    // =========================================================================
    //  OWN STATE HELPERS
    // =========================================================================

    /** Called when the local player pulls out a Lark weapon. */
    private void onWeaponEquipped() {
        if (state == State.COOLDOWN) {
            // Re-equip during cooldown: just reset the timer, stay in COOLDOWN
            stateStartMs = System.currentTimeMillis();
            // ── MIS-TIMED LARK ──────────────────────────────────────────────
            // Player equipped Lark while the cooldown was still active.
            // Flash them with a blue glow and show a blue warning notification.
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.field_1724 != null) {
                CustomGlowManager.registerGlow(mc.field_1724.method_5477().getString(), 3000L, 0x3399FF);
                ComplexgamingcooldownsClient.NOTIF_MANAGER.push(
                        "\u00A7b\u26A0 Mis-timed Lark! (still on CD)", 0xFF3399FF, 3000);
            }
        } else {
            // Fresh equip: start BUFF phase
            state        = State.BUFF;
            stateStartMs = System.currentTimeMillis();
        }
    }

    public long remaining() {
        if (state == State.IDLE) return 0;
        long elapsed = System.currentTimeMillis() - stateStartMs;
        long total = switch (state) {
            case BUFF     -> buffMs;
            case NORMAL   -> normalMs;
            case COOLDOWN -> cooldownMs;
            default       -> 0;
        };
        return Math.max(0, total - elapsed);
    }

    /** 0 → just started, 1 → phase complete */
    public float progress() {
        if (state == State.IDLE) return 1f;
        long elapsed = System.currentTimeMillis() - stateStartMs;
        long total = switch (state) {
            case BUFF     -> buffMs;
            case NORMAL   -> normalMs;
            case COOLDOWN -> cooldownMs;
            default       -> 1;
        };
        return Math.min(1f, (float) elapsed / Math.max(1, total));
    }

    // =========================================================================
    //  TICK — own state + all enemies
    // =========================================================================

    public void tick(class_310 mc) {
        if (mc == null || mc.field_1724 == null) return;

        // --- own equip detection ---
        boolean holdingLark = isLarkWeapon(mc.field_1724.method_6047());
        if (holdingLark && !wasHoldingLark) {
            onWeaponEquipped();
        }
        wasHoldingLark = holdingLark;

        // --- own phase transitions ---
        if (remaining() == 0) {
            switch (state) {
                case BUFF     -> { state = State.NORMAL;   stateStartMs = System.currentTimeMillis(); }
                case NORMAL   -> { state = State.COOLDOWN; stateStartMs = System.currentTimeMillis(); }
                case COOLDOWN -> state = State.IDLE;
                default       -> {}
            }
        }

        // --- enemy lark tracking ---
        if (mc.field_1687 == null) return;

        Set<String> seenThisTick = new HashSet<>();

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1657 p) || p == mc.field_1724) continue;

            String name = p.method_5477().getString();
            seenThisTick.add(name);

            int larkLevel = getLarkLevel(p.method_6047());
            boolean holdingLarkNow = larkLevel > 0;

            EnemyLarkData data = enemyData.computeIfAbsent(
                    name, k -> new EnemyLarkData(buffMs, normalMs, cooldownMs));

            if (holdingLarkNow) {
                boolean justEquipped = data.onEquipDetected(larkLevel, buffMs, normalMs, cooldownMs);
                if (justEquipped && alertEnabled) {
                    if (data.isBuffed()) {
                        ComplexgamingcooldownsClient.NOTIF_MANAGER.push(
                                "\u00A7c\u2694 " + name + " pulled out Lark " + toRoman(larkLevel) + " \u00A7f[\u00A7c+50%\u00A7f]",
                                0xFFE84A6A);
                    } else {
                        // was on cooldown, re-equipped — still dangerous but timer reset
                        ComplexgamingcooldownsClient.NOTIF_MANAGER.push(
                                "\u00A77\u2694 " + name + " re-equipped Lark (still on CD)",
                                0xFF888888);
                    }
                }
            } else {
                if (data.wasHoldingLark) {
                    data.onUnequip();
                }
            }

            data.tick();

            // Register red glow while enemy is actively buffed (+50%) — refreshed each tick
            if (data.isBuffed()) {
                CustomGlowManager.registerGlow(name, 600, 0xFF2020);
            }
        }

        // Clean up players who left the world
        enemyData.keySet().removeIf(name -> !seenThisTick.contains(name));
    }

    // =========================================================================
    //  ITEM INSPECTION
    // =========================================================================

    public static int getLarkLevel(class_1799 stack) {
        if (stack == null || stack.method_7960()) return 0;
        try {
            List<class_2561> tt = stack.method_7950(
                    net.minecraft.class_1792.class_9635.field_51353,
                    class_310.method_1551().field_1724,
                    class_1836.field_41070
            );
            for (class_2561 line : tt) {
                String plain = line.getString().replaceAll("\u00A7[0-9a-fk-orA-FK-OR]", "");
                if (!plain.contains("\u25C6")) continue; // ◆
                String lo = plain.toLowerCase();
                if (!lo.contains("lark")) continue;
                int idx = lo.indexOf("lark");
                String after = plain.substring(idx + 4).trim();
                if (after.startsWith("V"))   return 5;
                if (after.startsWith("IV"))  return 4;
                if (after.startsWith("III")) return 3;
                if (after.startsWith("II"))  return 2;
                if (after.startsWith("I"))   return 1;
                return 1;
            }
        } catch (Exception ignored) {}
        return 0;
    }

    public static boolean isLarkWeapon(class_1799 stack) { return getLarkLevel(stack) > 0; }

    public Map<class_1657, Integer> getLarkThreats(class_310 mc) {
        Map<class_1657, Integer> t = new LinkedHashMap<>();
        if (!alertEnabled || mc == null || mc.field_1687 == null) return t;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e instanceof class_1657 p && p != mc.field_1724) {
                int lvl = getLarkLevel(p.method_6047());
                if (lvl > 0) t.put(p, lvl);
            }
        }
        return t;
    }

    public String buildHeadLabel(int lvl) {
        String[] ROMAN = {"", "I", "II", "III", "IV", "V"};
        String r = (lvl >= 1 && lvl <= 5) ? ROMAN[lvl] : String.valueOf(lvl);
        return ComplexgamingcooldownsClient.colorize(headLabel)
                .replace("{roman}", r)
                .replace("{level}", String.valueOf(lvl));
    }

    // =========================================================================
    //  ABOVE-HEAD LABEL RENDERING FOR ENEMIES
    // =========================================================================

    /**
     * Renders Lark state labels above enemy players' heads.
     * Called from WorldRenderEvents.AFTER_ENTITIES.
     *
     * RED   = BUFF  (+50%, dangerous — they just equipped it)
     * GRAY  = COOLDOWN (they re-equipped on cd or the buff has expired, -50%)
     * No label shown during NORMAL or IDLE.
     */
    public void renderEnemyHeadLabels(
            net.minecraft.class_4587 matrices,
            net.minecraft.class_4184 camera,
            class_310 mc) {

        if (mc == null || mc.field_1687 == null || enemyData.isEmpty()) return;
        if (matrices == null || camera == null) return;

        class_327 tr = mc.field_1772;
        long now = System.currentTimeMillis();

        float scale  = Math.max(0.5f, Math.min(8.0f, ComplexgamingcooldownsClient.HUD_SETTINGS.larkLabelScale));
        float ds     = 0.025f * scale;
        // Render slightly above the CustomHeadLabelManager layer so they don't overlap
        float height = ComplexgamingcooldownsClient.HUD_SETTINGS.labelHeightOffset + 1.4f;

        net.minecraft.class_4597.class_4598 imm =
                mc.method_22940().method_23000();

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;

            String name = p.method_5477().getString();
            EnemyLarkData data = enemyData.get(name);
            if (data == null || !data.shouldShowLabel()) continue;

            // Only show labels for BUFF (red) and COOLDOWN (gray)
            // NORMAL phase intentionally has no label — it's a brief neutral window
            if (data.state == EnemyLarkState.NORMAL) continue;

            // Build label text and color
            String labelText;
            int labelColor;
            long rem = data.remaining();
            String timeStr = String.format("%.1fs", rem / 1000.0);
            String roman   = toRoman(data.level);

            if (data.isBuffed()) {
                // RED — they are at +50%, dangerous
                labelText  = "\u00A7c\u2694 LARK " + roman + " +50% \u00A7f[" + timeStr + "]";
                labelColor = 0xFFE84A6A; // red
            } else {
                // GRAY — they are on cooldown, -50%
                labelText  = "\u00A77\u2694 LARK " + roman + " -50% \u00A7f[" + timeStr + "]";
                labelColor = 0xFF888888; // gray
            }

            // Pulse alpha for the last 500ms of each phase
            float alpha = (rem < 500L) ? (rem / 500f) : 1f;
            int alphaByte = (int)(alpha * 255);
            int col = (alphaByte << 24) | (labelColor & 0x00FFFFFF);

            int width = tr.method_1727(labelText);

            matrices.method_22903();
            matrices.method_22904(
                    p.method_23317() - camera.method_71156().field_1352,
                    p.method_23318() + p.method_17682() + height - camera.method_71156().field_1351,
                    p.method_23321() - camera.method_71156().field_1350);
            matrices.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(camera.method_19329()));
            matrices.method_22905(-ds, -ds, ds);

            tr.method_27522(
                    class_2561.method_43470(labelText),
                    -width / 2f,
                    0f,
                    col,
                    false,
                    matrices.method_23760().method_23761(),
                    imm,
                    class_327.class_6415.field_33994,
                    0x20000000,
                    15728880);

            matrices.method_22909();
        }

        imm.method_22993();
    }

    // =========================================================================
    //  HUD — own state panel
    // =========================================================================

    public void renderHud(class_332 ctx, class_327 tr, class_310 mc, int sw, int sh) {
        int sc = switch (state) {
            case BUFF     -> 0xFF4AE87A; // green  – +50%
            case NORMAL   -> 0xFFDDD0F8; // pale lavender – neutral
            case COOLDOWN -> 0xFFE84A6A; // red    – -50%
            default       -> 0xFF7860A8; // purple – idle
        };
        String sl = switch (state) {
            case BUFF     -> "LARK +50%";
            case NORMAL   -> "LARK";
            case COOLDOWN -> "LARK -50%";
            default       -> "LARK";
        };

        int px = (ComplexgamingcooldownsClient.HUD_SETTINGS.larkHudX >= 0)
                ? ComplexgamingcooldownsClient.HUD_SETTINGS.larkHudX : 10;
        int py = (ComplexgamingcooldownsClient.HUD_SETTINGS.larkHudY >= 0)
                ? ComplexgamingcooldownsClient.HUD_SETTINGS.larkHudY : (sh - 40);

        float larkScale = Math.max(0.4f, ComplexgamingcooldownsClient.HUD_SETTINGS.larkScale);
        var larkMs = ctx.method_51448();
        larkMs.pushMatrix();
        larkMs.translate((float) px, (float) py);
        larkMs.scale(larkScale, larkScale);

        // Draw relative to (0, 0) after translate
        int pw = 120, ph = 30;

        // Liquid-glass panel
        ctx.method_25294(0, 0, pw, ph, 0x40050209);
        gborder(ctx, 0, 0, pw, ph, 0x25FFFFFF);
        ctx.method_25294(1, 1, pw - 1, 2, 0x15FFFFFF);
        ctx.method_25294(1, 1, 3, ph - 1, sc);

        ctx.method_25303(tr, sl, 7, 5, sc);

        if (state != State.IDLE) {
            long rem = remaining();
            String ts = String.format("%.1fs", rem / 1000.0);
            int tw = tr.method_1727(ts);
            ctx.method_25303(tr, ts, pw - tw - 7, 5, 0xFFDDD0F8);
        }

        // Progress bar
        int bx = 6, by = 18, bw = pw - 12, bh = 4;
        ctx.method_25294(bx, by, bx + bw, by + bh, 0x40000000);

        float prog = progress();
        int filled = (int)(prog * bw);
        if (filled > 0) ctx.method_25294(bx, by, bx + filled, by + bh, sc);

        if (ComplexgamingcooldownsClient.larkHudDragging) {
            gborder(ctx, 0, 0, pw, ph, 0xFFFFD060);
        } else {
            ctx.method_25303(tr, "\u283F", pw - 8, ph - 8, 0x887860A8);
        }

        larkMs.popMatrix();
    }

    // =========================================================================
    //  HELPERS
    // =========================================================================

    private static String toRoman(int n) {
        return switch (n) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(n);
        };
    }

    private void gborder(class_332 c, int x, int y, int w, int h, int col) {
        c.method_25294(x, y, x + w, y + 1, col);
        c.method_25294(x, y + h - 1, x + w, y + h, col);
        c.method_25294(x, y, x + 1, y + h, col);
        c.method_25294(x + w - 1, y, x + w, y + h, col);
    }
}