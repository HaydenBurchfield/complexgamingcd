package org.cheetahv2.complexgamingcooldowns.client.tracker;

import java.util.*;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class PlayerTracker {
    private final Map<String, ArrayDeque<class_1799>> heldHistory = new LinkedHashMap<>();

    public void tick(class_310 mc) {
        if (mc == null || mc.field_1687 == null) return;
        for (class_1657 p : mc.field_1687.method_18456()) {
            String name = p.method_5477().getString();
            class_1799 hand = p.method_6047();
            ArrayDeque<class_1799> hist = heldHistory.computeIfAbsent(name, k -> new ArrayDeque<>());
            class_1799 last = hist.isEmpty() ? class_1799.field_8037 : hist.peekFirst();
            if (!class_1799.method_7984(hand, last)) {
                if (!hand.method_7960()) {
                    hist.addFirst(hand.method_7972());
                    while (hist.size() > 10) hist.pollLast();
                }
            }
        }
    }

    public List<class_1799> getHistory(String playerName) {
        ArrayDeque<class_1799> hist = heldHistory.get(playerName);
        return hist == null ? Collections.emptyList() : new ArrayList<>(hist);
    }
}
