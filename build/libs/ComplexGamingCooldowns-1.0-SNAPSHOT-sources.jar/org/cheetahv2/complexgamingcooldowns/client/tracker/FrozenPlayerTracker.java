package org.cheetahv2.complexgamingcooldowns.client.tracker;

import org.cheetahv2.complexgamingcooldowns.client.ComplexgamingcooldownsClient;
import org.cheetahv2.complexgamingcooldowns.client.util.ConfigHelper;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class FrozenPlayerTracker {
    public static final Path FILE = Paths.get("config", "complexgamingcooldowns", "frozen_tracker.json");

    public static class SavedConfig {
        public boolean enabled = true;
        public boolean showOutline = true;
        public boolean showHeadTag = true;
        public boolean showHudList = true;
        /** HUD widget screen position — draggable via Shift+LMB in-game */
        public int hudX = 10;
        public int hudY = 160;
    }

    private SavedConfig config = new SavedConfig();
    private final Map<String, Long> abilityFrozenPlayers = new ConcurrentHashMap<>();
    public final Set<Integer> activeFrozenIds = java.util.concurrent.ConcurrentHashMap.newKeySet();

    // ── drag state (no screen needed — same GLFW pattern as AbilityCooldownManager) ──
    public boolean dragging = false;
    private int dragOffX, dragOffY;
    private static final int BOX_W = 120;

    private static final Pattern[] CHAT_FREEZE_PATTERNS = {
            Pattern.compile("(?i)(?:.+)?\\b([a-z0-9_]{3,16})\\b has been frozen solid"),
            Pattern.compile("(?i)freezing \\b([a-z0-9_]{3,16})\\b solid"),
            Pattern.compile("(?i)stunned \\b([a-z0-9_]{3,16})\\b for"),
            Pattern.compile("(?i)(?:.+)?\\b([a-z0-9_]{3,16})\\b was stunned by deep freeze"),
            Pattern.compile("(?i)(?:.+)?\\b([a-z0-9_]{3,16})\\b is frozen solid")
    };

    public void load() {
        SavedConfig c = ConfigHelper.load(FILE, SavedConfig.class);
        if (c != null) this.config = c;
    }

    public void save() {
        ConfigHelper.save(FILE, this.config);
    }

    public SavedConfig getConfig() {
        return config;
    }

    public void onChat(String plain) {
        if (!config.enabled) return;
        String clean = plain.replaceAll("\u00A7[0-9a-fk-orA-FK-OR]", "").trim();
        for (Pattern p : CHAT_FREEZE_PATTERNS) {
            Matcher m = p.matcher(clean);
            if (m.find()) {
                String playerName = m.group(1);
                abilityFrozenPlayers.put(playerName, System.currentTimeMillis() + 2500);
                ComplexgamingcooldownsClient.NOTIF_MANAGER.push("\u2744 §b" + playerName + " §fIS FROZEN!", 0x33CCFF, 2500);
                break;
            }
        }
    }

    public boolean isPlayerFrozen(class_1657 p) {
        if (!config.enabled || p == null) return false;

        String name = p.method_5477().getString();
        Long expiry = abilityFrozenPlayers.get(name);
        if (expiry != null && expiry > System.currentTimeMillis()) return true;
        if (p.method_32312() > 0) return true;

        class_310 mc = class_310.method_1551();
        if (mc != null && mc.field_1687 != null) {
            if (p.method_6059(class_1294.field_5909)) {
                class_2338 pos = p.method_24515();
                net.minecraft.class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                net.minecraft.class_2248 below = mc.field_1687.method_8320(pos.method_10074()).method_26204();

                boolean standsOnIce = block == net.minecraft.class_2246.field_10295 ||
                        block == net.minecraft.class_2246.field_10225 ||
                        block == net.minecraft.class_2246.field_10384 ||
                        block == net.minecraft.class_2246.field_10110 ||
                        below == net.minecraft.class_2246.field_10295 ||
                        below == net.minecraft.class_2246.field_10225 ||
                        below == net.minecraft.class_2246.field_10384 ||
                        below == net.minecraft.class_2246.field_10110 ||
                        block == net.minecraft.class_2246.field_10477 ||
                        block == net.minecraft.class_2246.field_27879;
                if (standsOnIce) return true;
            }
        }
        return false;
    }

    public void tick(class_310 mc) {
        activeFrozenIds.clear();
        if (!config.enabled || mc == null || mc.field_1687 == null) return;

        long now = System.currentTimeMillis();
        abilityFrozenPlayers.entrySet().removeIf(e -> e.getValue() <= now);

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (isPlayerFrozen(p)) activeFrozenIds.add(p.method_5628());
        }
    }

    /**
     * Tick drag — call from ClientTickEvents.END_CLIENT_TICK (same as Lark / Cooldown drags).
     * Shift + LMB on the frozen HUD widget while no screen is open.
     */
    public void tickDrag(class_310 mc) {
        if (mc == null || mc.field_1755 != null || mc.method_22683() == null) return;
        if (!config.enabled || !config.showHudList) return;

        long win = mc.method_22683().method_4490();
        double[] mx = new double[1], my = new double[1];
        GLFW.glfwGetCursorPos(win, mx, my);
        double gx = mx[0] / mc.method_22683().method_4495();
        double gy = my[0] / mc.method_22683().method_4495();

        boolean lmb   = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean shift  = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT)  == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;

        // Current dynamic box height (matches renderHud)
        int frozenCount = activeFrozenIds.size();
        int boxH = 16 + Math.max(1, frozenCount) * 11;

        int bx = config.hudX, by = config.hudY;

        if (lmb && shift && !dragging && gx >= bx && gx <= bx + BOX_W && gy >= by && gy <= by + boxH) {
            dragging  = true;
            dragOffX  = (int)(gx - bx);
            dragOffY  = (int)(gy - by);
        }

        if (dragging) {
            if (lmb) {
                config.hudX = (int)(gx - dragOffX);
                config.hudY = (int)(gy - dragOffY);
            } else {
                dragging = false;
                save();
            }
        }
    }

    public void renderHud(class_332 ctx, class_310 mc) {
        if (!config.enabled || !config.showHudList || mc == null || mc.field_1687 == null) return;

        List<String> frozenList = new ArrayList<>();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (activeFrozenIds.contains(p.method_5628())) frozenList.add(p.method_5477().getString());
        }

        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> entry : abilityFrozenPlayers.entrySet()) {
            if (entry.getValue() > now && !frozenList.contains(entry.getKey())) {
                frozenList.add(entry.getKey());
            }
        }

        if (frozenList.isEmpty() && mc.field_1755 == null && !dragging) return;

        class_327 tr = mc.field_1772;
        int x = config.hudX;
        int y = config.hudY;
        int boxH = 16 + Math.max(1, frozenList.size()) * 11;

        ctx.method_25294(x, y, x + BOX_W, y + boxH, 0x40050209);
        gborder(ctx, x, y, BOX_W, boxH, dragging ? 0xCCFFD060 : 0x25FFFFFF);
        ctx.method_25294(x + 1, y + 1, x + BOX_W - 1, y + 2, 0x15FFFFFF);
        ctx.method_25294(x + 1, y + 1, x + 3, y + boxH - 1, 0xFF33CCFF);

        ctx.method_25303(tr, "\u2744 FROZEN", x + 7, y + 4, 0xFF33CCFF);
        int listY = y + 15;

        if (frozenList.isEmpty()) {
            ctx.method_25303(tr, "\u00A78None", x + 7, listY, 0xFF888888);
            return;
        }

        for (String name : frozenList) {
            ctx.method_25303(tr, "\u2744 " + name, x + 7, listY, 0xFF33CCFF);
            listY += 11;
        }
    }

    public void renderHeadLabels(net.minecraft.class_4587 matrices,
                                 net.minecraft.class_4184 camera,
                                 class_310 mc) {
        if (!config.enabled || !config.showHeadTag || mc == null || mc.field_1687 == null) return;

        class_327 tr = mc.field_1772;
        float scale  = Math.max(0.5f, Math.min(4.0f, ComplexgamingcooldownsClient.HUD_SETTINGS.labelScale));
        float ds     = 0.025f * scale;
        float height = ComplexgamingcooldownsClient.HUD_SETTINGS.labelHeightOffset + 0.6f;
        net.minecraft.class_4597.class_4598 imm =
                mc.method_22940().method_23000();

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;
            if (!activeFrozenIds.contains(p.method_5628())) continue;

            String text = "\u00A7b\u2744 [FROZEN]";
            int width   = tr.method_1727(text);

            matrices.method_22903();
            matrices.method_22904(p.method_23317() - camera.method_71156().field_1352,
                    p.method_23318() + p.method_17682() + height - camera.method_71156().field_1351,
                    p.method_23321() - camera.method_71156().field_1350);
            matrices.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(camera.method_19329()));
            matrices.method_22905(-ds, -ds, ds);

            tr.method_27522(class_2561.method_43470(text), -width / 2f, 0f,
                    0x33CCFF | 0xFF000000, false,
                    matrices.method_23760().method_23761(), imm,
                    class_327.class_6415.field_33994, 0x20000000, 15728880);
            matrices.method_22909();
        }
        imm.method_22993();
    }

    private void gborder(class_332 c, int x, int y, int w, int h, int col) {
        c.method_25294(x, y, x + w, y + 1, col);
        c.method_25294(x, y + h - 1, x + w, y + h, col);
        c.method_25294(x, y, x + 1, y + h, col);
        c.method_25294(x + w - 1, y, x + w, y + h, col);
    }
}