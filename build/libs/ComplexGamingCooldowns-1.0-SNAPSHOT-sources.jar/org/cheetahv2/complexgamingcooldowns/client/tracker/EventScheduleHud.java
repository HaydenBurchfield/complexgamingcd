package org.cheetahv2.complexgamingcooldowns.client.tracker;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * EventScheduleHud
 *
 * Renders a compact HUD panel showing:
 *  • Current active event (if any) or next 2 upcoming events with countdowns
 *  • Active DestroyTheCore spawn location (when detected from chat)
 *
 * Displayed bottom-left by default. Follows the same glass-pill style used
 * elsewhere in the CGC mod.
 */
public class EventScheduleHud {

    // ── Colours (matching CgcSettingsScreen palette) ─────────────────────
    private static final int
        BG          = 0xCC07050F,
        BORDER      = 0x60AABBDD,
        ACCENT      = 0xFF5BAAFF,
        TEXT_HI     = 0xFFEEF4FF,
        TEXT_MID    = 0xFFAABBCC,
        TEXT_DIM    = 0xFF556677,
        GREEN       = 0xFF3DDA6E,
        YELLOW      = 0xFFFFCC44,
        ORANGE      = 0xFFFF9944,
        RED         = 0xFFDD4444,
        GOLD        = 0xFFFFAA00,
        AQUA        = 0xFF55FFFF;

    private static final int PANEL_W  = 170;
    private static final int LINE_H   = 10;
    private static final int PADDING  = 5;

    private EventScheduleHud() {}

    // ── Public entry point ─────────────────────────────────────────────────

    public static void render(class_332 ctx, class_310 mc,
                              EventScheduleManager manager) {
        if (mc == null || mc.method_22683() == null) return;
        if (!manager.isHudEnabled()) return;

        class_327 tr = mc.field_1772;
        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();

        // Gather data
        EventScheduleManager.ScheduledEvent current = manager.getCurrentEvent();
        List<EventScheduleManager.ScheduledEvent> upcoming = manager.getUpcomingEvents(2);
        EventScheduleManager.CoreLocation activeCore = manager.getActiveCore();
        boolean hasRawCore = manager.getRawCoreX() != Integer.MIN_VALUE;

        // Count rows
        int rows = 1; // header
        if (current != null) rows += 1;
        rows += Math.min(2, upcoming.size()); // up to 2 upcoming
        if (current == null && upcoming.isEmpty()) rows += 1; // "no data"
        if (activeCore != null || hasRawCore) rows += 2; // separator + core line

        int panelH = PADDING * 2 + rows * LINE_H + (rows - 1) * 2;

        // Position: bottom-left, 6px margin
        int px = 6;
        int py = sh - panelH - 6;

        // Draw panel
        drawPanel(ctx, px, py, PANEL_W, panelH);

        int tx = px + PADDING;
        int ty = py + PADDING;

        // ── Header ─────────────────────────────────────────────────────────
        ctx.method_25303(tr, "§8⬡ §7Events", tx, ty, TEXT_MID);
        ty += LINE_H + 2;

        // ── Current event ──────────────────────────────────────────────────
        if (current != null) {
            long nowMs = System.currentTimeMillis();
            long elapsed = nowMs - current.startMs;
            String elapsedStr = EventScheduleManager.formatCountdown(elapsed);
            String icon = EventScheduleManager.eventIcon(current.type);
            String name = EventScheduleManager.eventName(current.type);
            ctx.method_25303(tr,
                icon + " " + name + " §a▶ §7" + elapsedStr + " ago",
                tx, ty, 0xFFFFFFFF);
            ty += LINE_H + 2;
        }

        // ── Upcoming ───────────────────────────────────────────────────────
        if (upcoming.isEmpty() && current == null) {
            ctx.method_25303(tr, "§8No events scheduled", tx, ty, TEXT_DIM);
            ty += LINE_H + 2;
        } else {
            long nowMs = System.currentTimeMillis();
            for (int i = 0; i < Math.min(2, upcoming.size()); i++) {
                EventScheduleManager.ScheduledEvent ev = upcoming.get(i);
                long diff = ev.startMs - nowMs;
                String countdown = EventScheduleManager.formatCountdown(diff);
                String icon = EventScheduleManager.eventIcon(ev.type);
                String name = EventScheduleManager.eventName(ev.type);

                // Colour code by imminence
                String timeColor;
                if (diff < 5 * 60 * 1000L)       timeColor = "§c"; // < 5 min = red
                else if (diff < 30 * 60 * 1000L)  timeColor = "§e"; // < 30 min = yellow
                else                               timeColor = "§7"; // relaxed = grey

                String prefix = i == 0 ? "§a▸ " : "§8▸ ";
                ctx.method_25303(tr,
                    prefix + icon + " " + name + " §8in " + timeColor + countdown,
                    tx, ty, 0xFFFFFFFF);
                ty += LINE_H + 2;
            }
        }

        // ── Core location ──────────────────────────────────────────────────
        if (activeCore != null || hasRawCore) {
            // Thin separator
            ctx.method_25294(tx, ty, px + PANEL_W - PADDING, ty + 1, BORDER);
            ty += LINE_H;

            if (activeCore != null) {
                ctx.method_25303(tr,
                    "§c⚔ §fCore: §e" + activeCore.name,
                    tx, ty, 0xFFFFFFFF);
            } else {
                // Unknown location — show raw coords
                ctx.method_25303(tr,
                    "§c⚔ §fCore: §7" + manager.getRawCoreX()
                        + " " + manager.getRawCoreY()
                        + " " + manager.getRawCoreZ(),
                    tx, ty, 0xFFFFFFFF);
            }
        }
    }

    // ── Draw helpers ───────────────────────────────────────────────────────

    private static void drawPanel(class_332 ctx, int x, int y, int w, int h) {
        ctx.method_25294(x, y, x + w, y + h, BG);
        // top accent stripe
        ctx.method_25294(x, y, x + w, y + 1, ACCENT);
        // border
        border(ctx, x, y, w, h, BORDER);
        // sheen
        ctx.method_25294(x + 2, y + 1, x + w - 2, y + 2, 0x10FFFFFF);
    }

    private static void border(class_332 ctx, int x, int y, int w, int h, int col) {
        ctx.method_25294(x,       y,       x + w, y + 1,   col);
        ctx.method_25294(x,       y + h-1, x + w, y + h,   col);
        ctx.method_25294(x,       y + 1,   x + 1, y + h-1, col);
        ctx.method_25294(x + w-1, y + 1,   x + w, y + h-1, col);
    }
}
