package org.cheetahv2.complexgamingcooldowns.client.gui;

import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.cheetahv2.complexgamingcooldowns.client.util.SignatureManager;
import org.lwjgl.glfw.GLFW;

/**
 * In-game screen for editing the /sign signature.
 *
 * Open it with the /signsettings client command:
 *
 *   ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
 *       dispatcher.register(ClientCommandManager.literal("signsettings")
 *           .executes(ctx -> {
 *               MinecraftClient.getInstance().send(() ->
 *                   MinecraftClient.getInstance().setScreen(new SignatureSettingsScreen()));
 *               return 1;
 *           })));
 *
 * The screen is also navigable from any other CGC settings screen.
 */
public class SignatureSettingsScreen extends class_437 {

    // ── layout constants ─────────────────────────────────────────────────
    private static final int PW = 380;
    private static final int PH = 200;

    // Liquid Glass palette — matches ViewInvScreen / FrozenPlayerTracker
    private static final int
            GLASS_BG     = 0xD00A0614,
            GLASS_BORDER = 0x25FFFFFF,
            GLASS_SHEEN  = 0x15FFFFFF,
            GLASS_SHADOW = 0x40000000,
            COLOR_BLUE   = 0xFF5AB4FF,
            COLOR_GREEN  = 0xFF4AE87A,
            COLOR_WHITE  = 0xFFFFFFFF,
            COLOR_GREY   = 0xFF888888;

    // ── widgets ───────────────────────────────────────────────────────────
    private class_342 signatureField;
    private class_4185    saveButton;
    private class_4185    resetButton;
    private class_4185    closeButton;

    /** Preview of what /sign would actually send (first 80 chars of the command). */
    private String previewText = "";

    public SignatureSettingsScreen() {
        super(class_2561.method_43470("CGC — Signature Settings"));
    }

    @Override
    public boolean method_25421() { return false; }

    // ── helpers ───────────────────────────────────────────────────────────

    private int px() { return (field_22789  - PW) / 2; }
    private int py() { return (field_22790 - PH) / 2; }

    private void drawGlassPanel(class_332 ctx, int x, int y, int w, int h) {
        ctx.method_25294(x, y, x + w, y + h, GLASS_BG);
        gborder(ctx, x, y, w, h, GLASS_BORDER);
        ctx.method_25294(x + 1, y + 1, x + w - 1, y + 2,     GLASS_SHEEN);
        ctx.method_25294(x + 1, y + h - 2, x + w - 1, y + h - 1, GLASS_SHADOW);
    }

    private static void gborder(class_332 c, int x, int y, int w, int h, int col) {
        c.method_25294(x,         y,         x + w,     y + 1,     col);
        c.method_25294(x,         y + h - 1, x + w,     y + h,     col);
        c.method_25294(x,         y,         x + 1,     y + h,     col);
        c.method_25294(x + w - 1, y,         x + w,     y + h,     col);
    }

    // ── lifecycle ─────────────────────────────────────────────────────────

    @Override
    protected void method_25426() {
        int x = px(), y = py();

        // ── Signature text field ──────────────────────────────────────────
        // Positioned below the title header, full panel width with padding.
        signatureField = new class_342(
                field_22793,
                x + 10, y + 48,
                PW - 20, 20,
                class_2561.method_43470("Signature command"));
        signatureField.method_1880(512);
        signatureField.method_1852(SignatureManager.getSignature());
        signatureField.method_1863(this::onFieldChanged);
        signatureField.method_47404(class_2561.method_43470("e.g. sll 1 &#FFBCE2 ☆ ...").method_27692(net.minecraft.class_124.field_1063));
        method_37063(signatureField);

        onFieldChanged(signatureField.method_1882()); // seed preview

        // ── Buttons ───────────────────────────────────────────────────────
        int btnY  = y + PH - 40;
        int btnW  = 90;
        int btnH  = 20;
        int gap   = 8;
        // Centre the three buttons
        int totalW = btnW * 3 + gap * 2;
        int btnX  = x + (PW - totalW) / 2;

        saveButton = class_4185.method_46430(
                class_2561.method_43470("✔ Save"),
                b -> onSave()
        ).method_46434(btnX, btnY, btnW, btnH).method_46431();
        method_37063(saveButton);

        resetButton = class_4185.method_46430(
                class_2561.method_43470("↺ Reset"),
                b -> onReset()
        ).method_46434(btnX + btnW + gap, btnY, btnW, btnH).method_46431();
        method_37063(resetButton);

        closeButton = class_4185.method_46430(
                class_2561.method_43470("✕ Close"),
                b -> onClose()
        ).method_46434(btnX + (btnW + gap) * 2, btnY, btnW, btnH).method_46431();
        method_37063(closeButton);
    }

    /** Called whenever the text field changes — updates live preview. */
    private void onFieldChanged(String text) {
        if (text == null || text.isBlank()) {
            previewText = "§8(empty — will use default on save)";
        } else {
            // Show the first ~60 chars of the command for a quick sanity check
            String display = text.length() > 60 ? text.substring(0, 57) + "…" : text;
            previewText = "§7/" + display;
        }
    }

    private void onSave() {
        String value = signatureField.method_1882().strip();
        SignatureManager.setSignature(value.isEmpty() ? null : value);
        // Brief flash — button label temporarily changes
        saveButton.method_25355(class_2561.method_43470("§a✔ Saved!"));
        // Re-seed in case it was blank and got default
        signatureField.method_1852(SignatureManager.getSignature());
        onFieldChanged(signatureField.method_1882());
    }

    private void onReset() {
        signatureField.method_1852(SignatureManager.getDefaultSignature());
        onFieldChanged(signatureField.method_1882());
        resetButton.method_25355(class_2561.method_43470("§e↺ Reset!"));
    }

    public void onClose() {
        class_310.method_1551().method_1507(null);
    }

    // ── rendering ─────────────────────────────────────────────────────────

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        // Dim backdrop
        ctx.method_25294(0, 0, field_22789, field_22790, 0x70020104);

        int x = px(), y = py();

        // Glass card
        drawGlassPanel(ctx, x, y, PW, PH);

        // ── Header bar ────────────────────────────────────────────────────
        ctx.method_25294(x + 6, y + 6, x + PW - 6, y + 24, 0x30000000);
        gborder(ctx, x + 6, y + 6, PW - 12, 18, 0x10FFFFFF);
        ctx.method_25303(field_22793,
                "✦ CGC §8| §fSignature Settings",
                x + 12, y + 11, COLOR_WHITE);

        // ── Field label ───────────────────────────────────────────────────
        ctx.method_25303(field_22793,
                "§8Command sent by §f/sign§8:",
                x + 10, y + 38, COLOR_GREY);

        // ── Hint ──────────────────────────────────────────────────────────
        ctx.method_25303(field_22793,
                "§8Tip: paste your full §f/sll§8 or §f/sign§8 command here.",
                x + 10, y + 76, COLOR_GREY);

        // ── Live preview ──────────────────────────────────────────────────
        ctx.method_25303(field_22793,
                "§8Preview:",
                x + 10, y + 94, COLOR_GREY);
        ctx.method_25303(field_22793,
                previewText,
                x + 10, y + 106, COLOR_BLUE);

        // ── Divider ───────────────────────────────────────────────────────
        ctx.method_25294(x + 8, y + 120, x + PW - 8, y + 121, 0x20FFFFFF);

        // ── Keybind hint ──────────────────────────────────────────────────
        ctx.method_25294(x + 6, y + PH - 16, x + PW - 6, y + PH - 6, 0x30000000);
        gborder(ctx, x + 6, y + PH - 16, PW - 12, 10, 0x10FFFFFF);
        ctx.method_25300(field_22793,
                "§8Press ESC to close without saving",
                x + PW / 2, y + PH - 15, COLOR_GREY);

        // Draw widgets on top
        super.method_25394(ctx, mx, my, delta);
    }

    // ── keyboard ──────────────────────────────────────────────────────────

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        if (input.comp_4795() == GLFW.GLFW_KEY_ENTER || input.comp_4795() == GLFW.GLFW_KEY_KP_ENTER) {
            onSave();
            return true;
        }
        return super.method_25404(input);
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}