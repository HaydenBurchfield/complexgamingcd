package org.cheetahv2.complexgamingcooldowns.client.gui;

import org.cheetahv2.complexgamingcooldowns.client.detection.TargetManager;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import net.minecraft.class_11908;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * /target — Lists all pinned targets.
 *
 * Player heads are rendered via ctx.drawItem() on a PLAYER_HEAD ItemStack
 * with CUSTOM_DATA containing {"SkullOwner": "playerName"}.
 * This avoids the ProfileComponent / RenderPipeline API entirely and works
 * across all 1.21.x versions.
 */
public class TargetListScreen extends class_437 {

    // ── Palette ───────────────────────────────────────────────────────────
    private static final int
            BG          = 0xEA07050F,
            PANEL       = 0x55101830,
            PANEL_HOV   = 0x7018243C,
            BORDER      = 0x40AABBDD,
            ACCENT      = 0xFF5BAAFF,
            TEXT_HI     = 0xFFEEF4FF,
            TEXT_MID    = 0xFFAABBCC,
            TEXT_DIM    = 0xFF556677,
            RED_HOV     = 0xFFFF6666;

    // ── Layout ────────────────────────────────────────────────────────────
    private static final int PW = 360, PH = 320;
    private static final int HDR_H = 28;
    private static final int ROW_H = 36;
    private static final int ROW_PAD = 4;
    private static final int MARGIN = 10;
    private static final int HEAD_SIZE = 16; // drawItem always renders 16x16
    private static final int BTN_W = 22, BTN_H = 16;

    private int px() { return (field_22789  - PW) / 2; }
    private int py() { return (field_22790 - PH) / 2; }

    // ── State ─────────────────────────────────────────────────────────────
    private int scrollOffset = 0;
    private final int MAX_VISIBLE = 7;
    private List<Map.Entry<String, Integer>> rows = new ArrayList<>();

    // Cache head stacks — rebuilt if target list changes
    private final Map<String, class_1799> headCache = new HashMap<>();

    // GLFW polling
    private boolean prevLmb = false;
    private double gx, gy;
    private int hovRow  = -1;
    private int hovType = -1;
    private boolean hovUp = false, hovDown = false;

    public TargetListScreen() {
        super(class_2561.method_43470("Target List"));
    }

    @Override
    public boolean method_25421() { return false; }

    // ── Render ────────────────────────────────────────────────────────────
    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        rows = new ArrayList<>(TargetManager.getAll().entrySet());
        rows.sort(Map.Entry.comparingByKey());

        int px = px(), py = py();

        // Cursor
        long win = class_310.method_1551().method_22683().method_4490();
        double[] cx = new double[1], cy = new double[1];
        GLFW.glfwGetCursorPos(win, cx, cy);
        double scale = class_310.method_1551().method_22683().method_4495();
        gx = cx[0] / scale;
        gy = cy[0] / scale;
        boolean lmb = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = lmb && !prevLmb;

        // Background
        ctx.method_25294(px - 2, py - 2, px + PW + 2, py + PH + 2, BORDER);
        ctx.method_25294(px, py, px + PW, py + PH, BG);
        ctx.method_25294(px, py, px + PW, py + HDR_H, 0xCC0D1A33);
        ctx.method_25294(px, py + HDR_H - 1, px + PW, py + HDR_H, BORDER);

        // Title
        ctx.method_51439(field_22793, class_2561.method_43470("\u25CE  TARGET LIST"), px + 10, py + 9, ACCENT, false);
        String badge = rows.size() + " target" + (rows.size() == 1 ? "" : "s");
        ctx.method_51439(field_22793, class_2561.method_43470(badge),
                px + PW - field_22793.method_1727(badge) - 10, py + 9, TEXT_DIM, false);

        // Scroll arrows
        int contentAreaH = PH - HDR_H - 6;
        int maxRows = rows.size();
        boolean canScrollUp   = scrollOffset > 0;
        boolean canScrollDown = (scrollOffset + MAX_VISIBLE) < maxRows;

        int arrowX = px + PW - 16;
        int upArY  = py + HDR_H + 4;
        int dnArY  = py + PH - 14;

        hovUp   = gx >= arrowX && gx <= arrowX + 12 && gy >= upArY && gy <= upArY + 10;
        hovDown = gx >= arrowX && gx <= arrowX + 12 && gy >= dnArY && gy <= dnArY + 10;

        if (canScrollUp) {
            ctx.method_25294(arrowX, upArY, arrowX + 12, upArY + 10, hovUp ? PANEL_HOV : PANEL);
            ctx.method_51439(field_22793, class_2561.method_43470("\u25B2"), arrowX + 2, upArY + 1,
                    hovUp ? ACCENT : TEXT_MID, false);
            if (click && hovUp) scrollOffset--;
        }
        if (canScrollDown) {
            ctx.method_25294(arrowX, dnArY, arrowX + 12, dnArY + 10, hovDown ? PANEL_HOV : PANEL);
            ctx.method_51439(field_22793, class_2561.method_43470("\u25BC"), arrowX + 2, dnArY + 1,
                    hovDown ? ACCENT : TEXT_MID, false);
            if (click && hovDown) scrollOffset++;
        }
        scrollOffset = Math.max(0, Math.min(scrollOffset, Math.max(0, maxRows - MAX_VISIBLE)));

        // Empty state
        if (rows.isEmpty()) {
            String msg1 = "No targets set.";
            String msg2 = "Use: /target add <player> [color]";
            ctx.method_51439(field_22793, class_2561.method_43470(msg1),
                    px + (PW - field_22793.method_1727(msg1)) / 2,
                    py + HDR_H + contentAreaH / 2 - 10, TEXT_MID, false);
            ctx.method_51439(field_22793, class_2561.method_43470(msg2),
                    px + (PW - field_22793.method_1727(msg2)) / 2,
                    py + HDR_H + contentAreaH / 2 + 4, TEXT_DIM, false);
            prevLmb = lmb;
            super.method_25394(ctx, mouseX, mouseY, delta);
            return;
        }

        // Rows
        hovRow  = -1;
        hovType = -1;

        int rowY = py + HDR_H + ROW_PAD;
        int visCount = Math.min(MAX_VISIBLE, rows.size() - scrollOffset);

        for (int i = 0; i < visCount; i++) {
            int idx = scrollOffset + i;
            Map.Entry<String, Integer> entry = rows.get(idx);
            String name  = entry.getKey();
            int    color = entry.getValue();

            int rx = px + MARGIN;
            int rw = PW - MARGIN * 2 - 18;
            int ry = rowY + i * (ROW_H + 2);

            int btnX = rx + rw - BTN_W - 2;
            boolean overRow = gx >= rx && gx <= rx + rw && gy >= ry && gy <= ry + ROW_H;
            boolean overBtn = gx >= btnX && gx <= btnX + BTN_W
                    && gy >= ry + (ROW_H - BTN_H) / 2
                    && gy <= ry + (ROW_H - BTN_H) / 2 + BTN_H;

            if (overRow) { hovRow = idx; hovType = overBtn ? 1 : 0; }

            boolean rowHov = (hovRow == idx && hovType == 0);
            ctx.method_25294(rx, ry, rx + rw, ry + ROW_H, rowHov ? PANEL_HOV : PANEL);
            ctx.method_25294(rx, ry, rx + 1, ry + ROW_H, color | 0xFF000000);

            // Player head — centered vertically in the row
            int headX = rx + 4;
            int headY = ry + (ROW_H - HEAD_SIZE) / 2;
            ctx.method_51427(getHeadStack(name), headX, headY);

            // Name
            ctx.method_51439(field_22793, class_2561.method_43470(name),
                    headX + HEAD_SIZE + 6, ry + 6, TEXT_HI, false);

            // Color swatch + label
            String colorLabel = colorLabel(color);
            int swatchX = headX + HEAD_SIZE + 6;
            int swatchY = ry + ROW_H - 12;
            ctx.method_25294(swatchX, swatchY, swatchX + 8, swatchY + 7, color | 0xFF000000);
            ctx.method_25294(swatchX, swatchY, swatchX + 8, swatchY + 1, 0x40FFFFFF);
            ctx.method_51439(field_22793, class_2561.method_43470(colorLabel),
                    swatchX + 10, swatchY, TEXT_MID, false);

            // Remove [×] button
            int btnY = ry + (ROW_H - BTN_H) / 2;
            boolean btnHov = (hovRow == idx && hovType == 1);
            ctx.method_25294(btnX, btnY, btnX + BTN_W, btnY + BTN_H,
                    btnHov ? RED_HOV : 0x55DD4444);
            ctx.method_25294(btnX, btnY, btnX + BTN_W, btnY + 1, 0x30FFFFFF);
            String xLabel = "\u00D7";
            ctx.method_51439(field_22793, class_2561.method_43470(xLabel),
                    btnX + (BTN_W - field_22793.method_1727(xLabel)) / 2,
                    btnY + (BTN_H - 7) / 2,
                    btnHov ? 0xFFFFFFFF : 0xFFDD4444, false);

            if (click && overBtn) {
                TargetManager.removeTarget(name);
                headCache.remove(name);
            }
        }

        // Footer
        String hint = "ESC to close  •  /target add <player> [color]";
        ctx.method_51439(field_22793, class_2561.method_43470(hint),
                px + (PW - field_22793.method_1727(hint)) / 2,
                py + PH - 11, TEXT_DIM, false);

        prevLmb = lmb;
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    // ── Player head ItemStack ─────────────────────────────────────────────
    /**
     * Builds a PLAYER_HEAD ItemStack using CUSTOM_DATA with a SkullOwner NBT tag.
     * This is the most version-stable way to get a named player head without
     * touching ProfileComponent or any drawTexture API.
     *
     * The SkullOwner tag is recognized by Minecraft's skull item renderer and
     * will trigger a skin lookup for the named player automatically.
     */
    private class_1799 getHeadStack(String playerName) {
        return headCache.computeIfAbsent(playerName, name -> {
            class_1799 stack = new class_1799(class_1802.field_8575);
            class_2487 nbt = new class_2487();
            nbt.method_10582("SkullOwner", name);
            stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
            return stack;
        });
    }

    // ── Color label ──────────────────────────────────────────────────────
    private static String colorLabel(int rgb) {
        for (Map.Entry<String, Integer> e : TargetManager.COLOR_NAMES.entrySet()) {
            if (e.getValue() == rgb) return e.getKey();
        }
        return String.format("#%06X", rgb & 0xFFFFFF);
    }

    // ── Input ─────────────────────────────────────────────────────────────
    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
            class_310.method_1551().method_1507(null);
            return true;
        }
        return super.method_25404(input);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0 && (scrollOffset + MAX_VISIBLE) < rows.size()) scrollOffset++;
        if (verticalAmount > 0 && scrollOffset > 0) scrollOffset--;
        return true;
    }
}