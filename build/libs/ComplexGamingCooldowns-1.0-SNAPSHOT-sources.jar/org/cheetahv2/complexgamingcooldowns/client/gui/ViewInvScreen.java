package org.cheetahv2.complexgamingcooldowns.client.gui;

import org.cheetahv2.complexgamingcooldowns.client.ComplexgamingcooldownsClient;
import org.cheetahv2.complexgamingcooldowns.client.detection.LarkManager;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ViewInvScreen extends class_437 {
    private static final int SLOT = 18;

    private final class_1657 target;
    private final String targetName;
    private final class_1799 head, chest, legs, feet, mainHand, offHand;
    private class_1799 hoveredStack = class_1799.field_8037;

    // Liquid Glass Palette
    private static final int
            GLASS_BG       = 0xD00A0614,
            GLASS_BORDER   = 0x25FFFFFF,
            GLASS_SHEEN    = 0x15FFFFFF,
            GLASS_SHADOW   = 0x40000000,
            SLOT_BG        = 0x30FFFFFF,
            SLOT_BORDER    = 0x10FFFFFF,
            COLOR_BLUE     = 0xFF5AB4FF,
            COLOR_GREEN    = 0xFF4AE87A,
            COLOR_GOLD     = 0xFFFFD060,
            COLOR_RED      = 0xFFE84A6A,
            COLOR_WHITE    = 0xFFFFFFFF;

    public ViewInvScreen(class_1657 p) {
        super(class_2561.method_43470("viewinv"));
        this.target = p;
        this.targetName = p.method_5477().getString();
        this.head = p.method_31548().method_5438(39).method_7972();
        this.chest = p.method_31548().method_5438(38).method_7972();
        this.legs = p.method_31548().method_5438(37).method_7972();
        this.feet = p.method_31548().method_5438(36).method_7972();
        this.mainHand = p.method_6047().method_7972();
        this.offHand = p.method_6079().method_7972();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private int pw() { return 340; }
    private int ph() { return 250; }
    private int px() { return (field_22789 - pw()) / 2; }
    private int py() { return (field_22790 - ph()) / 2; }

    private void drawGlassPanel(class_332 ctx, int x, int y, int w, int h) {
        // Base glass dark transparent background
        ctx.method_25294(x, y, x + w, y + h, GLASS_BG);
        // Clean white glass border
        gborder(ctx, x, y, w, h, GLASS_BORDER);
        // Highlight sheen at top
        ctx.method_25294(x + 1, y + 1, x + w - 1, y + 2, GLASS_SHEEN);
        // Shadow line at bottom
        ctx.method_25294(x + 1, y + h - 2, x + w - 1, y + h - 1, GLASS_SHADOW);
    }

    private void drawGlassSlot(class_332 ctx, int x, int y) {
        // Dark translucent inset
        ctx.method_25294(x, y, x + SLOT, y + SLOT, 0x40000000);
        // Glassy border
        gborder(ctx, x, y, SLOT, SLOT, SLOT_BORDER);
        // Highlight top-left inset
        ctx.method_25294(x + 1, y + 1, x + SLOT - 1, y + 2, 0x10FFFFFF);
        ctx.method_25294(x + 1, y + 1, x + 2, y + SLOT - 1, 0x10FFFFFF);
    }

    private static void gborder(class_332 c, int x, int y, int w, int h, int col) {
        c.method_25294(x, y, x + w, y + 1, col);
        c.method_25294(x, y + h - 1, x + w, y + h, col);
        c.method_25294(x, y, x + 1, y + h, col);
        c.method_25294(x + w - 1, y, x + w, y + h, col);
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        int px = px(), py = py(), pw = pw(), ph = ph();
        ctx.method_25294(0, 0, field_22789, field_22790, 0x70020104); // subtle background dim

        // Main Liquid Glass Dialog Card
        drawGlassPanel(ctx, px, py, pw, ph);

        // Header Slot (Frosted slot)
        ctx.method_25294(px + 6, py + 6, px + pw - 6, py + 24, 0x30000000);
        gborder(ctx, px + 6, py + 6, pw - 12, 18, 0x10FFFFFF);
        ctx.method_25303(field_22793, "\u2726 CGC \u00A78| \u00A7fViewing: \u00A7b" + targetName, px + 12, py + 11, COLOR_WHITE);

        // Lark Level Gold Badge on top right
        int larkLvl = LarkManager.getLarkLevel(mainHand);
        if (larkLvl > 0) {
            String[] R = {"", "I", "II", "III", "IV", "V"};
            String badge = "\u2694 Lark " + R[Math.min(larkLvl, 5)];
            int bw = field_22793.method_1727(badge) + 10;
            ctx.method_25294(px + pw - bw - 12, py + 8, px + pw - 12, py + 22, 0x60002000);
            gborder(ctx, px + pw - bw - 12, py + 8, bw, 14, COLOR_GREEN);
            ctx.method_25303(field_22793, badge, px + pw - bw - 7, py + 11, 0xFF4AE87A);
        }

        int ly = py + 34;
        
        // Target stats info slot (Health & Ping)
        ctx.method_25294(px + 8, ly, px + pw - 8, ly + 18, 0x20FFFFFF);
        gborder(ctx, px + 8, ly, pw - 16, 18, 0x10FFFFFF);
        
        float hp = target.method_6032();
        float maxHp = target.method_6063();
        String hpStr = String.format("\u00A7c\u2764 \u00A7fHealth: \u00A7e%.1f/%.1f", hp, maxHp);
        ctx.method_25303(field_22793, hpStr, px + 14, ly + 5, COLOR_WHITE);
        
        String pingStr = "\u00A79\u23F3 \u00A7fState: " + (target.method_29504() ? "\u00A7cDead" : "\u00A7aAlive");
        int tw = field_22793.method_1727(pingStr);
        ctx.method_25303(field_22793, pingStr, px + pw - tw - 14, ly + 5, COLOR_WHITE);
        
        ly += 24;

        // Section Label
        ctx.method_25303(field_22793, "\u00A78Target Equipment Slots:", px + 8, ly, 0xFF7860A8);
        ly += 11;

        class_1799[] equip = {head, chest, legs, feet, mainHand, offHand};
        String[] labels = {"Head", "Chest", "Legs", "Feet", "Hand", "Off"};
        int slotY = ly, slotX = px + 8;
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            drawSlot(ctx, field_22793, mx, my, sx, slotY, equip[i], labels[i]);
            if (!equip[i].method_7960() && equip[i].method_7963()) {
                int dur = equip[i].method_7936() - equip[i].method_7919();
                int maxDur = equip[i].method_7936();
                float pct = (float) dur / maxDur;
                int col = pct > 0.6f ? 0xFF4AE87A : pct > 0.3f ? 0xFFFFD060 : 0xFFE84A6A;
                String durStr = dur + "/" + maxDur;
                ctx.method_25300(field_22793, durStr, sx + SLOT / 2, slotY + SLOT + 10, col);
            }
        }
        ly += SLOT + 22; // was 14, extra 8px for durability line

        // Visual divider
        ctx.method_25294(px + 8, ly, px + pw - 8, ly + 1, 0x20FFFFFF);
        ly += 6;

        ctx.method_25303(field_22793, "\u00A78Recent Held Items Logs:", px + 8, ly, 0xFF7860A8);
        ly += 11;

        List<class_1799> hist = ComplexgamingcooldownsClient.PLAYER_TRACKER.getHistory(targetName);
        int histX = px + 8;
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            int sx = histX + i * (SLOT + 6);
            if (sx + SLOT > px + pw - 6) break;
            drawSlot(ctx, field_22793, mx, my, sx, ly, hist.get(i), null);
        }
        if (hist.isEmpty()) {
            ctx.method_25303(field_22793, "\u00A78No logs recorded yet.", px + 8, ly + 4, 0xFF7F7F7F);
        }

        // Close instruction footer
        ctx.method_25294(px + 6, py + ph - 16, px + pw - 6, py + ph - 6, 0x30000000);
        gborder(ctx, px + 6, py + ph - 16, pw - 12, 10, 0x10FFFFFF);
        ctx.method_25300(field_22793, "\u00A78Press ESC key to exit screen", px + pw / 2, py + ph - 15, 0xFF7F7F7F);

        super.method_25394(ctx, mx, my, delta);

        // Tooltip rendering over everything else
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            if (mx >= sx && mx < sx + SLOT && my >= slotY && my < slotY + SLOT && !equip[i].method_7960()) {
                ctx.method_51446(field_22793, equip[i], mx, my);
            }
        }
        int hy2 = py + 34 + 24 + 11 + SLOT + 22 + 6 + 11; // was +14
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            int sx = histX + i * (SLOT + 6);
            if (sx + SLOT > px + pw - 6) break;
            if (mx >= sx && mx < sx + SLOT && my >= hy2 && my < hy2 + SLOT && !hist.get(i).method_7960()) {
                ctx.method_51446(field_22793, hist.get(i), mx, my);
            }
        }

        // Track which item the mouse is over (for Z key inspection)
        hoveredStack = class_1799.field_8037;
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            if (mx >= sx && mx < sx + SLOT && my >= slotY && my < slotY + SLOT && !equip[i].method_7960()) {
                hoveredStack = equip[i];
                break;
            }
        }
        if (hoveredStack.method_7960()) {
            List<class_1799> hist2 = ComplexgamingcooldownsClient.PLAYER_TRACKER.getHistory(targetName);
            int histX2 = px + 8;
            hy2 = py + 34 + 24 + 11 + SLOT + 22 + 6 + 11; // updated offset (+22 instead of +14)
            for (int i = 0; i < Math.min(10, hist2.size()); i++) {
                int sx = histX2 + i * (SLOT + 6);
                if (sx + SLOT > px + pw - 6) break;
                if (mx >= sx && mx < sx + SLOT && my >= hy2 && my < hy2 + SLOT && !hist2.get(i).method_7960()) {
                    hoveredStack = hist2.get(i);
                    break;
                }
            }
        }
    }

    private void drawSlot(class_332 ctx, class_327 tr, int mx, int my, int sx, int sy, class_1799 stack, String label) {
        boolean hov = mx >= sx && mx < sx + SLOT && my >= sy && my < sy + SLOT;

        drawGlassSlot(ctx, sx, sy);

        if (hov) {
            ctx.method_25294(sx + 1, sy + 1, sx + SLOT - 1, sy + SLOT - 1, 0x20FFFFFF);
        }

        if (!stack.method_7960()) {
            ctx.method_51427(stack, sx + 1, sy + 1);
            ctx.method_51432(tr, stack, sx + 1, sy + 1, null);
        }
        if (label != null) {
            ctx.method_25300(tr, "\u00A78" + label, sx + SLOT / 2, sy + SLOT + 2, 0xFF888888);
        }
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
            class_310.method_1551().method_1507(null);
            return true;
        }
        int inspectKey = net.minecraft.class_3675
                .method_15981(ComplexgamingcooldownsClient.inspectItemKey.method_1428())
                .method_1444();
        if (input.comp_4795() == inspectKey && !hoveredStack.method_7960()) {
            class_310.method_1551().method_1507(new ItemInspectScreen(hoveredStack));
            return true;
        }
        return super.method_25404(input);
    }
}
