package org.cheetahv2.complexgamingcooldowns.client.utility;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.cheetahv2.complexgamingcooldowns.client.ComplexgamingcooldownsClient;
import org.cheetahv2.complexgamingcooldowns.client.cooldown.AbilityCooldownManager;
import org.cheetahv2.complexgamingcooldowns.client.util.ConfigHelper;

import java.nio.file.Path;
import java.nio.file.Paths;
import net.minecraft.class_10938;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2813;
import net.minecraft.class_310;
import net.minecraft.class_9334;

/**
 * AutoTotemModule
 *
 * TWO MODES:
 *
 *  ALWAYS  (original behaviour)
 *      Keeps a Totem of Undying in the offhand at all times.
 *      Re-equips automatically after one is consumed.
 *
 *  SMART  (new — mirrors Sacred Shield logic)
 *      Only equips a totem when:
 *        • HP ≤ triggerHealth, AND
 *        • Sacred Shield cannot be deployed:
 *            – not in inventory, OR on cooldown (jack of hearts CD is tracked separately)
 *        • Tropical Shield cannot be deployed:
 *            – not in inventory, OR on cooldown in the ability cooldown map
 *      Un-equips (and returns totem to its original slot) when HP recovers above
 *      the threshold OR a shield becomes available again.
 *
 * Tick-delay state machine (ALWAYS mode):
 *   IDLE → EQUIP_STEP1 [if from main inv: swap mainInv↔hotbar8]
 *        → EQUIP_STEP2  swap hotbar8↔offhand
 *        → IDLE
 *
 * Tick-delay state machine (SMART mode):
 *   IDLE     → (trigger) → EQUIP_STEP1 → EQUIP_STEP2 → EQUIPPED
 *   EQUIPPED → (clear)   → UNEQUIP_STEP1 → UNEQUIP_STEP2 → IDLE
 */
public class AutoTotemModule implements UtilityModule {

    public enum Mode { ALWAYS, SMART }

    // ── Config ────────────────────────────────────────────────────────────
    public static class Config {
        public boolean enabled          = false;
        public Mode    mode             = Mode.ALWAYS;
        /** SMART mode: HP (half-hearts) at or below which to consider equipping. */
        public float   triggerHealth    = 8.0f;
        /** Minimum ms between equip actions to avoid spam. */
        public int     actionCooldownMs = 500;
    }

    private Config config = new Config();
    private static final Path FILE = Paths.get("config", "complexgamingcooldowns", "module_totem.json");

    // ── State machine ─────────────────────────────────────────────────────
    private enum Phase { IDLE, EQUIP_STEP1, EQUIP_STEP2, EQUIPPED, UNEQUIP_STEP1, UNEQUIP_STEP2 }
    private Phase phase        = Phase.IDLE;
    private long  lastActionMs = 0L;
    private int   totemInvSlot = -1;
    private int   totemScrSlot = -1;

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public String getName()           { return "Auto Totem"; }
    @Override public String getDescription()    { return "Keeps Totem of Undying in offhand"; }
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    @Override
    public void tick(class_310 mc) {
        if (!config.enabled || mc.field_1724 == null || mc.field_1687 == null) return;

        if (config.mode == Mode.ALWAYS) {
            tickAlways(mc);
        } else {
            tickSmart(mc);
        }
    }

    // ── ALWAYS mode ───────────────────────────────────────────────────────

    private void tickAlways(class_310 mc) {
        long now = System.currentTimeMillis();
        if (now - lastActionMs < config.actionCooldownMs) return;

        switch (phase) {
            case IDLE: {
                if (!isTotem(mc.field_1724.method_6079())) phase = Phase.EQUIP_STEP1;
                break;
            }
            case EQUIP_STEP1: {
                if (isTotem(mc.field_1724.method_6079())) { phase = Phase.IDLE; break; }

                int slot = findTotem(mc);
                if (slot < 0) { phase = Phase.IDLE; break; }

                totemInvSlot = slot;
                totemScrSlot = slot < 9 ? 36 + slot : slot;

                if (slot >= 9) {
                    sendSwap(mc, (short) totemScrSlot, (byte) 8);
                    phase = Phase.EQUIP_STEP2;
                } else {
                    phase = Phase.EQUIP_STEP2;
                }
                lastActionMs = now;
                break;
            }
            case EQUIP_STEP2: {
                sendSwap(mc, (short) 44, (byte) 40);
                totemInvSlot = -1;
                totemScrSlot = -1;
                phase = Phase.IDLE;
                lastActionMs = now;
                break;
            }
            default:
                phase = Phase.IDLE;
                break;
        }
    }

    // ── SMART mode ────────────────────────────────────────────────────────

    private void tickSmart(class_310 mc) {
        long now = System.currentTimeMillis();
        if (now - lastActionMs < config.actionCooldownMs) return;

        float hp  = mc.field_1724.method_6032();
        boolean low = hp <= config.triggerHealth && hp > 0;

        // Trigger condition: low HP AND shields can't save us
        boolean shouldEquip = low && !shieldCanDeploy(mc);

        switch (phase) {

            case IDLE: {
                if (shouldEquip) phase = Phase.EQUIP_STEP1;
                break;
            }

            case EQUIP_STEP1: {
                if (!shouldEquip) { phase = Phase.IDLE; break; }

                if (isTotem(mc.field_1724.method_6079())) {
                    totemInvSlot = -1;
                    totemScrSlot = -1;
                    phase = Phase.EQUIPPED;
                    lastActionMs = now;
                    break;
                }

                int slot = findTotem(mc);
                if (slot < 0) { phase = Phase.IDLE; break; }

                totemInvSlot = slot;
                totemScrSlot = slot < 9 ? 36 + slot : slot;

                if (slot >= 9) {
                    sendSwap(mc, (short) totemScrSlot, (byte) 8);
                    phase = Phase.EQUIP_STEP2;
                } else {
                    phase = Phase.EQUIP_STEP2;
                }
                lastActionMs = now;
                break;
            }

            case EQUIP_STEP2: {
                if (!shouldEquip) { smartReset(mc); break; }
                sendSwap(mc, (short) 44, (byte) 40);
                phase = Phase.EQUIPPED;
                lastActionMs = now;
                break;
            }

            case EQUIPPED: {
                // Un-equip when HP recovers OR a shield becomes available
                boolean clear = !shouldEquip;
                // Also reset if totem was consumed externally
                if (totemInvSlot == -1 && !isTotem(mc.field_1724.method_6079())) {
                    phase = Phase.IDLE;
                    break;
                }
                if (clear) phase = Phase.UNEQUIP_STEP1;
                break;
            }

            case UNEQUIP_STEP1: {
                if (!isTotem(mc.field_1724.method_6079())) { smartReset(mc); break; }
                // Offhand (45) → hotbar slot 8 (button 40)
                sendSwap(mc, (short) 45, (byte) 40);
                phase = Phase.UNEQUIP_STEP2;
                lastActionMs = now;
                break;
            }

            case UNEQUIP_STEP2: {
                if (totemInvSlot >= 0 && totemInvSlot < 9) {
                    sendSwap(mc, (short) 44, (byte) totemInvSlot);
                } else if (totemInvSlot >= 9) {
                    sendSwap(mc, (short) totemScrSlot, (byte) 8);
                }
                smartReset(mc);
                lastActionMs = now;
                break;
            }
        }
    }

    private void smartReset(class_310 mc) {
        phase        = Phase.IDLE;
        totemInvSlot = -1;
        totemScrSlot = -1;
    }

    /**
     * Returns true if at least one shield (Sacred or Tropical) can be deployed:
     *   • Its item is present in inventory, AND
     *   • Its cooldown is NOT currently active in the ability cooldown map.
     *
     * "On cooldown" here means the AbilityCooldownManager has an active entry with
     * the shield's known cooldown ID. We key on partial name matches since the
     * sacred/tropical shields are handled by their own modules, not the rune system.
     */
    private boolean shieldCanDeploy(class_310 mc) {
        if (mc.field_1724 == null) return false;

        var active = ComplexgamingcooldownsClient.ABILITY_COOLDOWN.getActive();

        // Sacred Shield
        boolean sacredInInv = false;
        for (int i = 0; i < 36; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (isSacredShield(s)) { sacredInInv = true; break; }
        }
        if (!sacredInInv) {
            class_1799 off = mc.field_1724.method_6079();
            if (isSacredShield(off)) sacredInInv = true;
        }
        // Sacred shield is "deployable" if in inv and not on cooldown.
        // Sacred shield doesn't have a rune-system cooldown; it's always ready if in inv.
        if (sacredInInv) return true;

        // Tropical Shield — check if in inv
        boolean tropicalInInv = false;
        for (int i = 0; i < 36; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (isTropicalShield(s)) { tropicalInInv = true; break; }
        }
        if (!tropicalInInv) {
            class_1799 off = mc.field_1724.method_6079();
            if (isTropicalShield(off)) tropicalInInv = true;
        }
        // Tropical shield has no rune-system cooldown tracked; available if in inv
        if (tropicalInInv) return true;

        return false;
    }

    // ── Item detection ────────────────────────────────────────────────────

    private int findTotem(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        for (int i = 9; i < 36; i++) {
            if (isTotem(mc.field_1724.method_31548().method_5438(i))) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (isTotem(mc.field_1724.method_31548().method_5438(i))) return i;
        }
        return -1;
    }

    private boolean isTotem(class_1799 stack) {
        return stack != null && !stack.method_7960() && stack.method_31574(class_1802.field_8288);
    }

    private boolean isSacredShield(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        String name = stack.method_7964().getString().toLowerCase();
        if (!name.contains("sacred")) return false;
        // Also check for divine intervention lore to be sure
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore != null) {
            for (net.minecraft.class_2561 line : lore.comp_2400()) {
                if (line.getString().toLowerCase().contains("divine intervention")) return true;
                for (net.minecraft.class_2561 sib : line.method_10855()) {
                    if (sib.getString().toLowerCase().contains("divine intervention")) return true;
                }
            }
        }
        // Fallback: just name check
        return name.contains("sacred shield");
    }

    private boolean isTropicalShield(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return stack.method_7964().getString().toLowerCase().contains("tropical");
    }

    // ── Packet helper ─────────────────────────────────────────────────────

    private void sendSwap(class_310 mc, short screenSlot, byte button) {
        if (mc.field_1724 == null) return;
        mc.field_1724.field_3944.method_52787(new class_2813(
                mc.field_1724.field_7512.field_7763,
                mc.field_1724.field_7512.method_37421(),
                screenSlot,
                button,
                class_1713.field_7791,
                new Int2ObjectOpenHashMap<>(),
                class_10938.field_58176
        ));
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(FILE, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(FILE, Config.class);
        if (c != null) config = c;
    }

    public Config getConfig() { return config; }
}
