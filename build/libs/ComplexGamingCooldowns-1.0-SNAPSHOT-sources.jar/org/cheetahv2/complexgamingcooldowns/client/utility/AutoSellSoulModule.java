package org.cheetahv2.complexgamingcooldowns.client.utility;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.cheetahv2.complexgamingcooldowns.client.util.ConfigHelper;
import org.cheetahv2.complexgamingcooldowns.client.util.RomanHelper;

import java.nio.file.Path;
import java.nio.file.Paths;
import net.minecraft.class_10938;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2813;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_9334;

/**
 * AutoSellSoulModule
 *
 * Keybind-triggered (not threshold-triggered, unlike Sacred/Tropical Shield).
 * On key press: finds the "Sell Soul" leggings anywhere in the inventory,
 * swaps them into the held hotbar slot (or uses the swap-hands button if the
 * held slot IS slot 0), taps the vanilla swap-hands key twice to open the
 * server's custom sell menu, presses "1" to confirm the sale, then restores
 * the leggings (if anything is left of them) back to their original slot.
 *
 * Item detection: lore contains "Sell Soul" (color-code/format independent —
 * matched on the stripped string), with the level read from the trailing
 * roman numeral in the lore line.
 *
 * Tick-delay state machine — one action per tick so the server has time to
 * process each step before the next is sent:
 *
 *  IDLE → (keybind pressed) → MOVE_TO_SLOT → [swap leggings into target slot]
 *        → OPEN_MENU_1 → tap swap-hands (1st press)
 *        → OPEN_MENU_2 → tap swap-hands (2nd press, opens menu)
 *        → CONFIRM_SELL → tap "1" key (confirms sale)
 *        → RESTORE → [swap leggings back to original slot, if present]
 *        → IDLE
 */
public class AutoSellSoulModule implements UtilityModule {

    // ── Config ────────────────────────────────────────────────────────────
    public static class Config {
        public boolean enabled          = false;
        /** Minimum ms between state transitions. */
        public int     actionCooldownMs = 150;
    }

    private Config config = new Config();
    private static final Path FILE = Paths.get("config", "complexgamingcooldowns", "module_sell_soul.json");

    // ── State machine ─────────────────────────────────────────────────────
    private enum Phase { IDLE, MOVE_TO_SLOT, OPEN_MENU_1, OPEN_MENU_1_RELEASE,
                          OPEN_MENU_2, OPEN_MENU_2_RELEASE,
                          CONFIRM_SELL, CONFIRM_SELL_RELEASE, RESTORE }
    private Phase phase        = Phase.IDLE;
    private long  lastActionMs = 0L;

    // Set during MOVE_TO_SLOT, used during RESTORE
    private int   legsInvSlot  = -1;   // original 0-35 inventory slot
    private int   legsScrSlot  = -1;   // screen-handler slot for legsInvSlot
    private int   workingSlot  = -1;   // hotbar slot used to perform the sell (0-8)
    private boolean usedSwapButton = false; // true if we used button 40 (offhand) instead of a hotbar slot swap

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public String getName()           { return "Auto Sell Soul"; }
    @Override public String getDescription()    { return "Sells Sell Soul leggings via keybind"; }
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    /**
     * Called from ComplexgamingcooldownsClient's tick loop. The caller is
     * responsible for checking KeyBinding.wasPressed() and invoking trigger()
     * only when phase == IDLE (handled internally here too, defensively).
     */
    public void trigger(class_310 mc) {
        if (!config.enabled || phase != Phase.IDLE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        int slot = findSellSoulLeggings(mc);
        if (slot < 0) {
            mc.field_1724.method_7353(class_2561.method_43470("§c[CGC] §fNo Sell Soul leggings found in inventory."), true);
            return;
        }

        legsInvSlot = slot;
        legsScrSlot = slot < 9 ? 36 + slot : slot;
        phase = Phase.MOVE_TO_SLOT;
        lastActionMs = 0L; // force-allow immediate first tick
    }

    @Override
    public void tick(class_310 mc) {
        if (!config.enabled || mc.field_1724 == null || mc.field_1687 == null) {
            if (phase != Phase.IDLE) reset();
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastActionMs < config.actionCooldownMs) return;

        switch (phase) {

            case IDLE:
                break;

            case MOVE_TO_SLOT: {
                int heldSlot = mc.field_1724.method_31548().method_67532();

                if (legsInvSlot == heldSlot) {
                    // Leggings already sitting in the currently-held slot —
                    // nothing to swap, go straight to the menu.
                    workingSlot = heldSlot;
                    usedSwapButton = false;
                    phase = Phase.OPEN_MENU_1;
                    lastActionMs = now;
                    break;
                }

                if (heldSlot == 0) {
                    // Held slot is hotbar slot 0 — per spec, use the offhand
                    // swap button (40) to bring the leggings in instead of
                    // overwriting the held slot.
                    sendSwap(mc, (short) legsScrSlot, (byte) 40);
                    workingSlot = -1;
                    usedSwapButton = true;
                } else {
                    // Swap leggings into the currently held hotbar slot.
                    byte heldButton = (byte) heldSlot;
                    sendSwap(mc, (short) legsScrSlot, heldButton);
                    workingSlot = heldSlot;
                    usedSwapButton = false;
                }
                phase = Phase.OPEN_MENU_1;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_1: {
                setKeyPressed(mc.field_1690.field_1831, true);
                phase = Phase.OPEN_MENU_1_RELEASE;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_1_RELEASE: {
                setKeyPressed(mc.field_1690.field_1831, false);
                phase = Phase.OPEN_MENU_2;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_2: {
                setKeyPressed(mc.field_1690.field_1831, true);
                phase = Phase.OPEN_MENU_2_RELEASE;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_2_RELEASE: {
                setKeyPressed(mc.field_1690.field_1831, false);
                phase = Phase.CONFIRM_SELL;
                lastActionMs = now;
                break;
            }

            case CONFIRM_SELL: {
                setKeyPressed(mc.field_1690.field_1852[0], true); // "1" key
                phase = Phase.CONFIRM_SELL_RELEASE;
                lastActionMs = now;
                break;
            }

            case CONFIRM_SELL_RELEASE: {
                setKeyPressed(mc.field_1690.field_1852[0], false);
                phase = Phase.RESTORE;
                lastActionMs = now;
                break;
            }

            case RESTORE: {
                // Move whatever ended up in the working location back to the
                // leggings' original slot, if it's still there to move.
                if (usedSwapButton) {
                    // Came in via offhand button — swap offhand back out to original slot.
                    if (isSellSoul(mc.field_1724.method_6079())) {
                        sendSwap(mc, (short) legsScrSlot, (byte) 40);
                    }
                } else if (workingSlot >= 0 && workingSlot != legsInvSlot) {
                    class_1799 working = mc.field_1724.method_31548().method_5438(workingSlot);
                    if (isSellSoul(working)) {
                        byte button = (byte) workingSlot;
                        sendSwap(mc, (short) legsScrSlot, button);
                    }
                }
                mc.field_1724.method_7353(class_2561.method_43470("§a[CGC] §fSell Soul sale complete."), true);
                reset();
                lastActionMs = now;
                break;
            }
        }
    }

    private void reset() {
        phase          = Phase.IDLE;
        legsInvSlot    = -1;
        legsScrSlot    = -1;
        workingSlot    = -1;
        usedSwapButton = false;
    }

    // ── Item detection ────────────────────────────────────────────────────

    private int findSellSoulLeggings(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        for (int i = 9; i < 36; i++) {
            if (isSellSoul(mc.field_1724.method_31548().method_5438(i))) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (isSellSoul(mc.field_1724.method_31548().method_5438(i))) return i;
        }
        return -1;
    }

    private boolean isSellSoul(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return hasLoreContaining(stack, "sell soul") || hasLoreContaining(stack, "&#881334🌶&#9A1D39 &#AC273ES&#BF3143e&#D13B47l&#E3454Cl&#F54F51 &#E3454CS&#D13B47o&#BF3143u&#AC273El&#9A1D39");
    }

    /** Extracts the level (1-10) from the Sell Soul lore line's trailing roman numeral, or -1 if not found. */
    public int getSellSoulLevel(class_1799 stack) {
        if (stack == null || stack.method_7960()) return -1;
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore == null) return -1;
        for (class_2561 line : lore.comp_2400()) {
            String stripped = stripFormatting(line.getString()).trim();
            String siblingsAppended = stripped;
            for (class_2561 sib : line.method_10855()) {
                siblingsAppended += stripFormatting(sib.getString());
            }
            String lower = siblingsAppended.toLowerCase();
            if (lower.contains("sell soul")) {
                // pull the trailing token (roman numeral) off the line
                String[] parts = siblingsAppended.trim().split("\\s+");
                if (parts.length > 0) {
                    String last = parts[parts.length - 1];
                    int lvl = RomanHelper.fromRoman(last);
                    if (lvl > 0) return lvl;
                }
            }
        }
        return -1;
    }

    private boolean hasLoreContaining(class_1799 stack, String keyword) {
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore == null) return false;
        for (class_2561 line : lore.comp_2400()) {
            String combined = stripFormatting(line.getString());
            for (class_2561 sib : line.method_10855()) {
                combined += stripFormatting(sib.getString());
            }
            if (combined.toLowerCase().contains(keyword)) return true;
        }
        return false;
    }

    /** Strips legacy (&x) and hex (&#RRGGBB) color codes so lore can be matched on plain text. */
    private String stripFormatting(String s) {
        if (s == null) return "";
        // Remove &#RRGGBB hex codes
        String noHex = s.replaceAll("&#[0-9A-Fa-f]{6}", "");
        // Remove legacy &x codes (color + formatting)
        return noHex.replaceAll("&[0-9a-fk-orA-FK-OR]", "");
    }

    // ── Key simulation helper ─────────────────────────────────────────────

    /**
     * Sets a vanilla KeyBinding's pressed state for one tick, mirroring how
     * MinecraftClient's own input handler would process a real key press —
     * no mixin required. Caller is responsible for releasing it on a
     * subsequent tick (handled by the *_RELEASE phases above).
     */
    private void setKeyPressed(class_304 key, boolean pressed) {
        net.minecraft.class_3675.class_306 inputKey =
                net.minecraft.class_3675.method_15981(key.method_1428());
        class_304.method_1416(inputKey, pressed);
    }

    // ── Packet helper ─────────────────────────────────────────────────────

    private void sendSwap(class_310 mc, short screenSlot, byte button) {
        if (mc.field_1724 == null) return;
        mc.field_1724.field_3944.method_52787(new class_2813(
                mc.field_1724.field_7512.field_7763,
                mc.field_1724.field_7512.method_37421(),
                screenSlot,
                button,
                class_1713.field_7791,
                new Int2ObjectOpenHashMap<>(),
                class_10938.field_58176
        ));
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(FILE, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(FILE, Config.class);
        if (c != null) config = c;
    }

    public Config getConfig() { return config; }
}
