package org.cheetahv2.complexgamingcooldowns.client.utility;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.cheetahv2.complexgamingcooldowns.client.ComplexgamingcooldownsClient;
import org.cheetahv2.complexgamingcooldowns.client.detection.RunicObstructionManager;
import org.cheetahv2.complexgamingcooldowns.client.util.ConfigHelper;

import java.nio.file.Path;
import java.nio.file.Paths;
import net.minecraft.class_10938;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2813;
import net.minecraft.class_2868;
import net.minecraft.class_310;

/**
 * AutoJackOfHeartsModule
 *
 * When the local player is runiced (RunicObstructionManager.isSelfRuniced()),
 * automatically right-click uses a "Jack of Hearts" (minecraft:paper with
 * "jack" in the display name) from inventory.
 *
 * Flow:
 *  1. Detect runic debuff
 *  2. Wait <triggerDelayMs> ms
 *  3. Find Jack of Hearts in inventory (main inv first, then hotbar)
 *  4. If not already in slot 8: SWAP it to hotbar slot 8
 *  5. Select slot 8 + interactItem (right-click use)
 *  6. Next tick: swap back and restore selected slot
 *  7. Enforce <useCooldownMs> before triggering again
 */
public class AutoJackOfHeartsModule implements UtilityModule {

    // ── Config ────────────────────────────────────────────────────────────
    public static class Config {
        public boolean enabled         = false;
        /** How long after runic is detected before using the card (ms). 0 = instant. */
        public int triggerDelayMs      = 100;
        /** Minimum time between Jack of Hearts uses (ms). 0 = no cooldown limit. */
        public int useCooldownMs       = 3000;
    }

    private Config config = new Config();
    private static final Path FILE = Paths.get("config", "complexgamingcooldowns", "module_jack_of_hearts.json");

    // ── State ─────────────────────────────────────────────────────────────
    private long    runicedAt        = -1L;
    private long    lastUseMs        = 0L;
    private boolean useInProgress    = false;
    private int     savedInvSlot     = -1;   // inventory slot the card came from
    private int     savedHotbarSlot  = -1;   // previously selected hotbar slot
    private boolean needsSwapBack    = false; // swap back on the next tick

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public String getName()           { return "Auto Jack of Hearts"; }
    @Override public String getDescription()    { return "Uses Jack of Hearts when runiced"; }
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    @Override
    public void tick(class_310 mc) {
        if (!config.enabled || mc.field_1724 == null || mc.field_1687 == null) return;

        // ── Swap-back phase: runs the tick AFTER we used the card ──────────
        if (needsSwapBack) {
            needsSwapBack = false;
            performSwapBack(mc);
            return;
        }

        boolean runiced = RunicObstructionManager.isSelfRuniced();

        if (!runiced) {
            runicedAt     = -1L;
            useInProgress = false;
            return;
        }

        long now = System.currentTimeMillis();

        // First tick we notice the runic
        if (runicedAt < 0) {
            runicedAt     = now;
            useInProgress = true;
        }

        if (!useInProgress) return;
        if (now - lastUseMs < config.useCooldownMs) return;
        if (now - runicedAt < config.triggerDelayMs) return;

        useInProgress = false;
        tryUseCard(mc);
    }

    private void tryUseCard(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;

        // Check if hotbar slot 8 (index 7) already has the card
        class_1799 slot7 = mc.field_1724.method_31548().method_5438(7);
        if (isJackOfHearts(slot7)) {
            useCardFromSlot7(mc, -1);
            return;
        }

        // Search main inventory first (slots 9-35), then rest of hotbar (0-6)
        int cardSlot = -1;
        for (int i = 9; i < 36; i++) {
            if (isJackOfHearts(mc.field_1724.method_31548().method_5438(i))) { cardSlot = i; break; }
        }
        if (cardSlot == -1) {
            for (int i = 0; i < 7; i++) {
                if (isJackOfHearts(mc.field_1724.method_31548().method_5438(i))) { cardSlot = i; break; }
            }
        }
        if (cardSlot == -1) return; // no card found

        savedInvSlot    = cardSlot;
        savedHotbarSlot = mc.field_1724.method_31548().method_67532();

        swapToSlot8(mc, cardSlot);
        useCardFromSlot7(mc, cardSlot);
    }

    private void useCardFromSlot7(class_310 mc, int pulledFromSlot) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;

        mc.field_1724.method_31548().method_61496(7);
        mc.field_1724.field_3944.method_52787(new class_2868(7));
        mc.field_1761.method_2919(mc.field_1724, net.minecraft.class_1268.field_5808);

        lastUseMs = System.currentTimeMillis();
        runicedAt = -1L;

        // Register 1:30 cooldown on the HUD
        ComplexgamingcooldownsClient.ABILITY_COOLDOWN.triggerJackOfHearts();

        if (pulledFromSlot >= 0) {
            // Card was swapped in from another slot — swap back next tick
            needsSwapBack = true;
        } else {
            // Card was already in slot 8 — just restore the previously selected slot
            int restoreTo = savedHotbarSlot >= 0 ? savedHotbarSlot : 0;
            mc.field_1724.method_31548().method_61496(restoreTo);
            mc.field_1724.field_3944.method_52787(new class_2868(restoreTo));
            savedHotbarSlot = -1;
        }
    }

    private void performSwapBack(class_310 mc) {
        if (mc.field_1724 == null || savedInvSlot < 0) return;

        swapToSlot8(mc, savedInvSlot); // reverses the original swap

        int restoreTo = savedHotbarSlot >= 0 ? savedHotbarSlot : 0;
        mc.field_1724.method_31548().method_61496(restoreTo);
        mc.field_1724.field_3944.method_52787(new class_2868(restoreTo));

        savedInvSlot    = -1;
        savedHotbarSlot = -1;
    }

    /**
     * SWAP ClickSlotC2SPacket: swaps invSlot (0-35) with hotbar slot 8 (index 7).
     * PlayerScreenHandler screen-slot layout:
     *   hotbar 0-8  → screen slots 36-44
     *   main inv 9-35 → screen slots 9-35
     */
    private void swapToSlot8(class_310 mc, int invSlot) {
        if (mc.field_1724 == null) return;
        int screenSlot = invSlot < 9 ? 36 + invSlot : invSlot;
        mc.field_1724.field_3944.method_52787(
                new class_2813(
                        mc.field_1724.field_7512.field_7763,
                        mc.field_1724.field_7512.method_37421(),
                        (short) screenSlot,
                        (byte)  7,           // hotbar index 7 = slot 8
                        class_1713.field_7791,
                        new Int2ObjectOpenHashMap<>(),
                        class_10938.field_58176
                )
        );
    }

    // ── Item detection ────────────────────────────────────────────────────

    private boolean isJackOfHearts(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!stack.method_31574(class_1802.field_8407)) return false;
        String name = stack.method_7964().getString().toLowerCase();
        return name.contains("jack") && name.contains("heart");
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(FILE, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(FILE, Config.class);
        if (c != null) config = c;
    }

    public Config getConfig() { return config; }
}
