package org.cheetahv2.complexgamingcooldowns.client.utility;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.cheetahv2.complexgamingcooldowns.client.util.ConfigHelper;

import java.nio.file.Path;
import java.nio.file.Paths;
import net.minecraft.class_10938;
import net.minecraft.class_1294;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2813;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_310;

/**
 * AutoCookieModule — smart version
 *
 * Triggers when the player is frozen (getFrozenTicks > 0 or Slowness amp ≥ 5).
 *
 * Smart behaviour:
 *  - Aborts any in-progress attack or block-use before eating so it doesn't
 *    cancel an attack mid-swing or interrupt shielding.
 *  - Waits triggerDelayMs after freeze onset, respects cookieCooldownMs between uses.
 *  - Swaps cookie to hotbar slot 8, eats it, swaps back to original slot next tick,
 *    then restores the previously selected hotbar slot.
 *
 * Tick-delay state machine (one packet per tick):
 *   IDLE → WAIT_DELAY → SWAP_IN → USE → SWAP_BACK → IDLE
 */
public class AutoCookieModule implements UtilityModule {

    // ── Config ────────────────────────────────────────────────────────────
    public static class Config {
        public boolean enabled      = false;
        /** How long after freeze is detected before eating (ms). 0 = instant. */
        public int triggerDelayMs   = 200;
        /** Minimum time between cookie uses (ms). */
        public int cookieCooldownMs = 2000;
    }

    private Config config = new Config();
    private static final Path FILE = Paths.get("config", "complexgamingcooldowns", "module_cookie.json");

    // ── State machine ─────────────────────────────────────────────────────
    private enum Phase { IDLE, WAIT_DELAY, SWAP_IN, USE, SWAP_BACK }
    private Phase phase          = Phase.IDLE;
    private long  frozeAt        = -1L;
    private long  lastCookieUseMs = 0L;

    // Saved during SWAP_IN, used during SWAP_BACK
    private int  cookieInvSlot   = -1;  // 0-35 slot cookie came from (-1 = was already in slot 8)
    private int  prevHotbarSlot  = -1;  // hotbar slot selected before we touched anything

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public String getName()           { return "Auto Cookie"; }
    @Override public String getDescription()    { return "Eats Santa's Cookie when frozen"; }
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    @Override
    public void tick(class_310 mc) {
        if (!config.enabled || mc.field_1724 == null || mc.field_1687 == null) return;

        boolean frozen = isFrozen(mc);
        long    now    = System.currentTimeMillis();

        switch (phase) {

            case IDLE: {
                if (!frozen) { frozeAt = -1L; return; }
                if (frozeAt < 0) frozeAt = now;
                if (now - lastCookieUseMs < config.cookieCooldownMs) return;
                phase = Phase.WAIT_DELAY;
                break;
            }

            case WAIT_DELAY: {
                if (!frozen) { reset(); return; }
                if (now - frozeAt >= config.triggerDelayMs) {
                    phase = Phase.SWAP_IN;
                }
                break;
            }

            case SWAP_IN: {
                if (!frozen) { reset(); return; }

                // Abort any in-progress attack/use so we don't cancel a swing
                abortCurrentAction(mc);

                // Find cookie
                int slot = findCookie(mc);
                if (slot < 0) { reset(); return; }  // no cookie, give up

                prevHotbarSlot = mc.field_1724.method_31548().method_67532();

                if (slot == 7) {
                    // Already in hotbar 8 — skip the swap, go straight to USE
                    cookieInvSlot = -1;
                    phase = Phase.USE;
                } else {
                    cookieInvSlot = slot;
                    sendSwap(mc, slot, 7);  // swap cookie slot ↔ hotbar 8
                    phase = Phase.USE;      // USE runs next tick (packet already sent)
                }
                break;
            }

            case USE: {
                // One tick has passed since SWAP_IN — cookie is now in slot 8 on the server
                mc.field_1724.method_31548().method_61496(7);
                mc.field_1724.field_3944.method_52787(new class_2868(7));
                mc.field_1761.method_2919(mc.field_1724, net.minecraft.class_1268.field_5808);

                lastCookieUseMs = now;
                frozeAt = -1L;

                if (cookieInvSlot >= 0) {
                    phase = Phase.SWAP_BACK;  // need to swap back next tick
                } else {
                    // Was already in slot 8, just restore selected slot
                    restoreHotbar(mc);
                    phase = Phase.IDLE;
                }
                break;
            }

            case SWAP_BACK: {
                // One tick has passed since USE — swap cookie back to original slot
                sendSwap(mc, cookieInvSlot, 7);
                restoreHotbar(mc);
                cookieInvSlot = -1;
                phase = Phase.IDLE;
                break;
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void reset() {
        phase         = Phase.IDLE;
        frozeAt       = -1L;
        cookieInvSlot = -1;
        prevHotbarSlot = -1;
    }

    private void restoreHotbar(class_310 mc) {
        int restoreTo = prevHotbarSlot >= 0 ? prevHotbarSlot : 0;
        mc.field_1724.method_31548().method_61496(restoreTo);
        mc.field_1724.field_3944.method_52787(new class_2868(restoreTo));
        prevHotbarSlot = -1;
    }

    /**
     * Sends ABORT_DESTROY_BLOCK to cancel any in-progress mining/attack,
     * which prevents the cookie use from being dropped by a pending left-click action.
     */
    private void abortCurrentAction(class_310 mc) {
        if (mc.field_1724 == null) return;
        mc.field_1724.field_3944.method_52787(new class_2846(
                class_2846.class_2847.field_12971,
                class_2338.field_10980,
                class_2350.field_11033
        ));
    }

    /**
     * Find Santa's Cookie in inventory.
     * Returns inventory slot 0-35, or -1 if not found.
     * Checks hotbar slot 8 (index 7) first, then main inv, then rest of hotbar.
     */
    private int findCookie(class_310 mc) {
        // Slot 8 already?
        if (isCookie(mc.field_1724.method_31548().method_5438(7))) return 7;
        // Main inventory
        for (int i = 9; i < 36; i++) {
            if (isCookie(mc.field_1724.method_31548().method_5438(i))) return i;
        }
        // Rest of hotbar
        for (int i = 0; i < 7; i++) {
            if (isCookie(mc.field_1724.method_31548().method_5438(i))) return i;
        }
        return -1;
    }

    /**
     * Sends a SWAP ClickSlotC2SPacket: swaps invSlot (0-35) with hotbar slot hotbarIdx (0-8).
     * PlayerScreenHandler screen-slot layout:
     *   hotbar 0-8   → screen slots 36-44
     *   main inv 9-35 → screen slots 9-35
     */
    private void sendSwap(class_310 mc, int invSlot, int hotbarIdx) {
        if (mc.field_1724 == null) return;
        int screenSlot = invSlot < 9 ? 36 + invSlot : invSlot;
        mc.field_1724.field_3944.method_52787(new class_2813(
                mc.field_1724.field_7512.field_7763,
                mc.field_1724.field_7512.method_37421(),
                (short) screenSlot,
                (byte)  hotbarIdx,
                class_1713.field_7791,
                new Int2ObjectOpenHashMap<>(),
                class_10938.field_58176
        ));
    }

    // ── Item / effect detection ───────────────────────────────────────────

    private boolean isCookie(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!stack.method_31574(class_1802.field_8423)) return false;
        if (stack.method_57826(net.minecraft.class_9334.field_49631)) {
            return stack.method_7964().getString().toLowerCase().contains("santa");
        }
        return false;
    }

    private boolean isFrozen(class_310 mc) {
        if (mc.field_1724 == null) return false;
        if (mc.field_1724.method_32312() > 0) return true;
        if (mc.field_1724.method_6059(class_1294.field_5909)) {
            var effect = mc.field_1724.method_6112(class_1294.field_5909);
            if (effect != null && effect.method_5578() >= 5) return true;
        }
        return false;
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(FILE, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(FILE, Config.class);
        if (c != null) config = c;
    }

    public Config getConfig() { return config; }
}
