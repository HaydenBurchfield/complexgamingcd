package org.cheetahv2.complexgamingcooldowns.client.mixin;

import net.minecraft.class_1297;
import org.cheetahv2.complexgamingcooldowns.client.detection.CustomGlowManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Two injections into Entity:
 *
 * 1. isGlowing()        — makes the entity show the vanilla white outline.
 * 2. getTeamColorValue() — overrides the outline COLOUR so it uses whatever
 *                          colour was registered in CustomGlowManager instead
 *                          of always defaulting to white (0xFFFFFF).
 *
 * Both are purely client-side; no packets are sent.
 */
@Mixin(class_1297.class)
public class EntityGlowMixin {

    /** Step 1 — force the entity into the glowing render pass. */
    @Inject(method = "isGlowing", at = @At("RETURN"), cancellable = true)
    private void cgc_overrideGlow(CallbackInfoReturnable<Boolean> cir) {
        // If already glowing for vanilla reasons, leave it alone
        if (cir.getReturnValue()) return;

        class_1297 self = (class_1297)(Object) this;
        if (CustomGlowManager.activeGlowIds.contains(self.method_5628())) {
            cir.setReturnValue(true);
        }
    }

    /**
     * Step 2 — override the outline colour.
     *
     * Minecraft reads the glow outline colour from getTeamColorValue().
     * Without this injection the outline is always white, regardless of
     * what colour was registered in CustomGlowManager.
     */
    @Inject(method = "getTeamColorValue", at = @At("RETURN"), cancellable = true)
    private void cgc_overrideTeamColor(CallbackInfoReturnable<Integer> cir) {
        class_1297 self = (class_1297)(Object) this;
        if (CustomGlowManager.activeGlowIds.contains(self.method_5628())) {
            // Replace the vanilla team colour with our registered colour
            cir.setReturnValue(CustomGlowManager.getGlowColor(self.method_5477().getString()));
        }
    }
}