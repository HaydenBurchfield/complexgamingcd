package org.cheetahv2.complexgamingcooldowns.client.mixin;

import net.minecraft.class_310;
import net.minecraft.class_312;
import org.cheetahv2.complexgamingcooldowns.client.LockCamManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts Mouse#updateMouse() — the method that converts raw mouse deltas
 * into player yaw/pitch changes every tick.
 *
 * When LockCamManager is active we cancel the vanilla input and instead
 * force the player's yaw/pitch to the locked values every frame, so even
 * external jitter (e.g. held mouse) can't drift the camera.
 */
@Mixin(class_312.class)
public class MouseLockMixin {

    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void cgc_lockCamera(CallbackInfo ci) {
        if (!LockCamManager.isLocked()) return;

        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;

        // Cancel the vanilla delta-application entirely
        ci.cancel();

        // Re-apply the locked angles every frame so nothing can drift them
        mc.field_1724.method_36456(LockCamManager.getLockedYaw());
        mc.field_1724.method_36457(LockCamManager.getLockedPitch());
    }
}
