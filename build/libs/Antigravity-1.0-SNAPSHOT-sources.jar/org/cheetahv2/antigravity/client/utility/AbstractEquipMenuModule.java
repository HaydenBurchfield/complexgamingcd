package org.cheetahv2.antigravity.client.utility;

import org.cheetahv2.antigravity.client.util.ConfigHelper;
import org.cheetahv2.antigravity.client.util.RomanHelper;

import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_9334;

/**
 * AbstractEquipMenuModule — the shared "equip armor piece → double-tap
 * swap-hands → confirm → unequip → restore" state machine used by keybind
 * items whose enchant opens a server-side keybind menu (Sell Soul leggings,
 * Tiki / Rain Dance chestplate, ...).
 *
 * On trigger:
 *   1. Find the matching armor piece (display name OR lore contains the
 *      keyword, §/&/&#RRGGBB codes stripped; level filter minLevel-maxLevel,
 *      highest level preferred).
 *   2. Stage it in a hotbar slot (if it's in the main inventory).
 *   3. EQUIP it into the armor slot (previous armor parks in the stage slot).
 *   4. Double-tap swap-hands — opens the menu.
 *   5. Confirm: switch to hotbar slot 1, or ONE more swap-hands press if
 *      already on slot 1.
 *   6. UNEQUIP (old armor re-equips automatically) and restore all slots.
 *
 * Silent by design. Safe to trigger every tick while the key is held —
 * sequences chain back-to-back. Coordinates with other modules via ModuleSync.
 */
public abstract class AbstractEquipMenuModule implements UtilityModule {

    // ── Config (shared shape for all equip-menu modules) ──────────────────
    public static class Config {
        public boolean enabled           = true;
        /** Only act on pieces whose enchant level is within [minLevel, maxLevel]. */
        public int     minLevel          = 1;
        public int     maxLevel          = 5;
        /** Delay between the swap / F-tap steps. */
        public int     actionDelayMs     = 100;
        /** Extra wait after the 2nd F-tap so the server menu is open before confirming. */
        public int     menuConfirmDelayMs = 250;
    }

    protected Config config = new Config();

    private final String  lockKey;          // ModuleSync owner id
    private final int     armorScreenSlot;  // player screen handler: 5=head 6=chest 7=legs 8=feet
    private final String  keyword;          // lower-case match keyword ("sell soul", "rain dance")
    private final Path    file;
    private final Pattern levelPattern;

    protected AbstractEquipMenuModule(String lockKey, int armorScreenSlot, String keyword, Path file) {
        this.lockKey         = lockKey;
        this.armorScreenSlot = armorScreenSlot;
        this.keyword         = keyword.toLowerCase();
        this.file            = file;
        this.levelPattern    = Pattern.compile(
                Pattern.quote(this.keyword) + "\\s+([IVXivx]{1,4})\\b");
    }

    // ── State machine ─────────────────────────────────────────────────────
    private enum Phase { IDLE, MOVE_TO_HOTBAR, EQUIP, SWAP_HANDS_1, SWAP_HANDS_2,
                         CONFIRM, UNEQUIP, RESTORE }
    private Phase phase        = Phase.IDLE;
    private long  lastActionMs = 0L;

    private int itemInvSlot      = -1;  // original 0-35 inventory slot of the piece
    private int itemScrSlot      = -1;  // screen-handler slot for itemInvSlot
    private int workingSlot      = -1;  // hotbar slot used to stage the piece (0-8)
    private int prevSelectedSlot = -1;  // hotbar slot selected before "pressing 1"

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    /**
     * Keybind entry point — call every tick while the key is held; it no-ops
     * mid-sequence and starts the next run the moment the previous finishes.
     * Deliberately SILENT — no chat/action-bar output at all.
     */
    public void trigger(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (phase != Phase.IDLE) return;
        if (!config.enabled) return;
        if (ModuleSync.inventoryLocked(mc) || ModuleSync.isBusy(lockKey)) return;

        int slot = findMatchingItem(mc);
        if (slot < 0) return;

        ModuleSync.acquire(lockKey, 2500);
        itemInvSlot      = slot;
        itemScrSlot      = slot < 9 ? 36 + slot : slot;
        prevSelectedSlot = -1;
        phase            = Phase.MOVE_TO_HOTBAR;
        lastActionMs     = 0L;
    }

    @Override
    public void tick(class_310 mc) {
        if (phase == Phase.IDLE) return;
        if (mc.field_1724 == null || mc.field_1687 == null) { reset(); return; }

        long now  = System.currentTimeMillis();
        long wait = (phase == Phase.CONFIRM) ? config.menuConfirmDelayMs : config.actionDelayMs;
        if (now - lastActionMs < wait) return;

        switch (phase) {

            case MOVE_TO_HOTBAR: {
                if (itemInvSlot < 9) {
                    workingSlot = itemInvSlot; // already on the hotbar
                } else {
                    workingSlot = mc.field_1724.method_31548().method_67532();
                    sendSwap(mc, itemScrSlot, workingSlot);
                }
                phase = Phase.EQUIP;
                lastActionMs = now;
                break;
            }

            case EQUIP: {
                sendSwap(mc, armorScreenSlot, workingSlot);
                phase = Phase.SWAP_HANDS_1;
                lastActionMs = now;
                break;
            }

            case SWAP_HANDS_1: {
                sendSwapHands(mc);
                phase = Phase.SWAP_HANDS_2;
                lastActionMs = now;
                break;
            }

            case SWAP_HANDS_2: {
                sendSwapHands(mc);
                phase = Phase.CONFIRM;
                lastActionMs = now;
                break;
            }

            case CONFIRM: {
                int selected = mc.field_1724.method_31548().method_67532();
                if (selected == 0) {
                    // Already on hotbar slot 1 → ONE more swap-hands press.
                    sendSwapHands(mc);
                } else {
                    // "Press 1": select hotbar slot 0 (packet auto-sent next tick).
                    prevSelectedSlot = selected;
                    mc.field_1724.method_31548().method_61496(0);
                }
                phase = Phase.UNEQUIP;
                lastActionMs = now;
                break;
            }

            case UNEQUIP: {
                sendSwap(mc, armorScreenSlot, workingSlot);
                phase = Phase.RESTORE;
                lastActionMs = now;
                break;
            }

            case RESTORE: {
                if (prevSelectedSlot >= 0) {
                    mc.field_1724.method_31548().method_61496(prevSelectedSlot);
                    prevSelectedSlot = -1;
                }
                // Unconditional: the action can rename/relevel the item, so no
                // "is it still the same?" check (that used to strand items).
                if (itemInvSlot >= 9 && workingSlot >= 0) {
                    sendSwap(mc, itemScrSlot, workingSlot);
                }
                reset(); // silent
                lastActionMs = now;
                break;
            }

            default:
                reset();
                break;
        }
    }

    private void reset() {
        phase            = Phase.IDLE;
        itemInvSlot      = -1;
        itemScrSlot      = -1;
        workingSlot      = -1;
        prevSelectedSlot = -1;
        ModuleSync.release(lockKey);
    }

    // ── Item detection ────────────────────────────────────────────────────

    /** Search the whole inventory; prefer the highest level inside the configured range. */
    private int findMatchingItem(class_310 mc) {
        int bestSlot = -1, bestLevel = -1;
        for (int i = 0; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!matches(stack)) continue;
            int lvl = getLevel(stack);
            if (lvl < 1) lvl = 1;
            if (lvl < config.minLevel || lvl > config.maxLevel) continue;
            if (lvl > bestLevel) { bestLevel = lvl; bestSlot = i; }
        }
        return bestSlot;
    }

    /** True if display name OR any lore line contains the keyword (formatting stripped). */
    public boolean matches(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (cleaned(stack.method_7964().getString()).contains(keyword)) return true;
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore == null) return false;
        for (class_2561 line : lore.comp_2400()) {
            if (cleaned(fullLineText(line)).contains(keyword)) return true;
        }
        return false;
    }

    /** Level from the roman numeral after the keyword in name or lore; -1 if not found. */
    public int getLevel(class_1799 stack) {
        if (stack == null || stack.method_7960()) return -1;
        int lvl = levelFrom(cleaned(stack.method_7964().getString()));
        if (lvl > 0) return lvl;
        var lore = stack.method_58694(class_9334.field_49632);
        if (lore != null) {
            for (class_2561 line : lore.comp_2400()) {
                lvl = levelFrom(cleaned(fullLineText(line)));
                if (lvl > 0) return lvl;
            }
        }
        return -1;
    }

    private int levelFrom(String cleanedLower) {
        Matcher m = levelPattern.matcher(cleanedLower);
        if (m.find()) {
            int lvl = RomanHelper.fromRoman(m.group(1).toUpperCase());
            if (lvl > 0) return lvl;
        }
        return -1;
    }

    private static String fullLineText(class_2561 line) {
        StringBuilder sb = new StringBuilder(line.getString());
        for (class_2561 sib : line.method_10855()) sb.append(sib.getString());
        return sb.toString();
    }

    /** Strips §-codes, &-codes and &#RRGGBB hex codes, lowercases. */
    private static String cleaned(String s) {
        if (s == null) return "";
        return s.replaceAll("&#[0-9A-Fa-f]{6}", "")
                .replaceAll("[§&][0-9a-fk-orA-FK-OR]", "")
                .toLowerCase();
    }

    // ── Packet helpers ────────────────────────────────────────────────────

    /** Exactly what the vanilla [F] key sends. */
    private void sendSwapHands(class_310 mc) {
        mc.field_1724.field_3944.method_52787(new class_2846(
                class_2846.class_2847.field_12969,
                class_2338.field_10980, class_2350.field_11033));
    }

    /** SWAP click via the interaction manager — same path as a real click. */
    private void sendSwap(class_310 mc, int screenSlot, int hotbarButton) {
        if (mc.field_1761 == null) return;
        mc.field_1761.method_2906(
                mc.field_1724.field_7512.field_7763,
                screenSlot,
                hotbarButton,
                class_1713.field_7791,
                mc.field_1724);
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(file, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(file, Config.class);
        if (c != null) config = c;
    }

    public Config getConfig() { return config; }
}
