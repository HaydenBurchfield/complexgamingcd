package org.cheetahv2.antigravity.client.utility;

import org.cheetahv2.antigravity.client.util.ConfigHelper;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_310;

/**
 * AbilityKeybindModule — bind ANY key to an abilities-menu slot.
 *
 * Each bind maps a raw keyboard key → a menu slot (1-9). Pressing the key
 * runs the server's keybind-menu sequence:
 *
 *   double-tap swap-hands (opens the abilities menu)
 *     → select hotbar slot N (the menu reads the held-slot change)
 *     → if you were ALREADY on slot N, one extra swap-hands press instead
 *       (a slot change wouldn't register — same trick Sell Soul uses)
 *     → restore your previous hotbar slot
 *
 * Binds are managed in /ccsettings → Modules → Ability Keybinds: click
 * "+ Add Bind", press any key, pick the slot with the steppers. Keys are
 * polled raw via GLFW so anything on the keyboard works, not just keys
 * Minecraft lets you register. Sequences are silent, spam-safe (a held key
 * chains), and coordinate with the other modules via ModuleSync.
 */
public class AbilityKeybindModule implements UtilityModule {

    // ── Config ────────────────────────────────────────────────────────────
    public static class Bind {
        public int    keyCode  = -1;   // GLFW key code (-1 = unset)
        public String keyName  = "?";  // display name for the UI
        public int    menuSlot = 1;    // abilities menu slot 1-9
    }

    public static class Config {
        public boolean enabled = true;
        /** Delay between the F-taps. */
        public int actionDelayMs = 100;
        /** Extra wait after the 2nd F-tap so the menu is open before selecting. */
        public int menuConfirmDelayMs = 250;
        public List<Bind> binds = new ArrayList<>();
    }

    private Config config = new Config();
    private static final Path FILE = Paths.get("config", "antigravity", "module_ability_keys.json");

    public static final int MAX_BINDS = 9;

    // ── State machine ─────────────────────────────────────────────────────
    private enum Phase { IDLE, SWAP_HANDS_1, SWAP_HANDS_2, CONFIRM, RESTORE }
    private Phase phase        = Phase.IDLE;
    private long  lastActionMs = 0L;
    private int   targetSlot   = -1;  // hotbar index (menuSlot - 1)
    private int   prevSelected = -1;

    /** Edge detection per key code. */
    private final Map<Integer, Boolean> prevDown = new HashMap<>();

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public String getName()           { return "Ability Keybinds"; }
    @Override public String getDescription()    { return "Any key → abilities menu slot (F-F-N)"; }
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    @Override
    public void tick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_22683() == null) return;

        // ── Advance an active sequence ────────────────────────────────────
        if (phase != Phase.IDLE) {
            stepSequence(mc);
            return;
        }

        // ── Poll bound keys (raw GLFW — works for any key) ───────────────
        if (mc.field_1755 != null) { prevDown.clear(); return; }
        long win = mc.method_22683().method_4490();

        for (Bind bind : config.binds) {
            if (bind.keyCode <= 0) continue;
            boolean down = GLFW.glfwGetKey(win, bind.keyCode) == GLFW.GLFW_PRESS;
            boolean was  = prevDown.getOrDefault(bind.keyCode, false);
            prevDown.put(bind.keyCode, down);

            // Fire on press; a HELD key re-fires as soon as the previous
            // sequence finishes (spam-friendly, same as Sell Soul).
            if (down && (!was || phase == Phase.IDLE)) {
                start(mc, bind.menuSlot);
                if (phase != Phase.IDLE) break; // one sequence at a time
            }
        }
    }

    private void start(class_310 mc, int menuSlot) {
        if (!config.enabled) return;
        if (menuSlot < 1 || menuSlot > 9) return;
        if (ModuleSync.inventoryLocked(mc) || ModuleSync.isBusy("abilitykeys")) return;

        ModuleSync.acquire("abilitykeys", 2000);
        targetSlot   = menuSlot - 1;
        prevSelected = -1;
        phase        = Phase.SWAP_HANDS_1;
        lastActionMs = 0L;
    }

    private void stepSequence(class_310 mc) {
        long now  = System.currentTimeMillis();
        long wait = (phase == Phase.CONFIRM) ? config.menuConfirmDelayMs : config.actionDelayMs;
        if (now - lastActionMs < wait) return;

        switch (phase) {

            case SWAP_HANDS_1: {
                sendSwapHands(mc);
                phase = Phase.SWAP_HANDS_2;
                lastActionMs = now;
                break;
            }

            case SWAP_HANDS_2: {
                sendSwapHands(mc);
                phase = Phase.CONFIRM;
                lastActionMs = now;
                break;
            }

            case CONFIRM: {
                int selected = mc.field_1724.method_31548().method_67532();
                if (selected == targetSlot) {
                    // Already holding the target slot — no slot-change packet
                    // would fire, so activate the held item with a right-click
                    // instead.
                    if (mc.field_1761 != null) {
                        mc.field_1761.method_2919(mc.field_1724, net.minecraft.class_1268.field_5808);
                        mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
                    }
                } else {
                    prevSelected = selected;
                    mc.field_1724.method_31548().method_61496(targetSlot);
                }
                phase = Phase.RESTORE;
                lastActionMs = now;
                break;
            }

            case RESTORE: {
                if (prevSelected >= 0) {
                    mc.field_1724.method_31548().method_61496(prevSelected);
                    prevSelected = -1;
                }
                reset();
                lastActionMs = now;
                break;
            }

            default:
                reset();
                break;
        }
    }

    private void reset() {
        phase        = Phase.IDLE;
        targetSlot   = -1;
        prevSelected = -1;
        ModuleSync.release("abilitykeys");
    }

    // ── Bind management (used by the settings UI) ─────────────────────────

    public Bind addBind() {
        if (config.binds.size() >= MAX_BINDS) return null;
        Bind b = new Bind();
        config.binds.add(b);
        save();
        return b;
    }

    public void removeBind(int index) {
        if (index >= 0 && index < config.binds.size()) {
            config.binds.remove(index);
            save();
        }
    }

    // ── Packet helper ─────────────────────────────────────────────────────

    private void sendSwapHands(class_310 mc) {
        mc.field_1724.field_3944.method_52787(new class_2846(
                class_2846.class_2847.field_12969,
                class_2338.field_10980, class_2350.field_11033));
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(FILE, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(FILE, Config.class);
        if (c != null) {
            config = c;
            if (config.binds == null) config.binds = new ArrayList<>();
        }
    }

    public Config getConfig() { return config; }
}
