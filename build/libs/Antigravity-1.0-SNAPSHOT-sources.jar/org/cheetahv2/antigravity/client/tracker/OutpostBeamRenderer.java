package org.cheetahv2.antigravity.client.tracker;

import net.minecraft.class_12249;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

/**
 * OutpostBeamRenderer
 *
 * Draws a tall translucent waypoint beam into the sky at every active
 * DestroyTheCore core location (parsed from chat by EventScheduleManager),
 * plus a floating "⚑ CORE" label with live distance. Multiple beams render
 * simultaneously since several cores can spawn in the first minute.
 *
 * Called from the WorldRenderEvents.AFTER_ENTITIES hook in AntigravityClient.
 */
public final class OutpostBeamRenderer {

    /** Beam half-width in blocks. */
    private static final float BEAM_HALF = 0.55f;
    /** Beam vertical extent relative to the core Y. */
    private static final float BEAM_DOWN = 8f;
    private static final float BEAM_UP   = 260f;

    // Gold/orange core beam
    private static final int BEAM_R = 255, BEAM_G = 170, BEAM_B = 0;

    private OutpostBeamRenderer() {}

    public static void render(class_4587 matrices, class_4184 camera,
                              class_310 mc, EventScheduleManager manager) {
        if (mc == null || mc.field_1687 == null || mc.field_1724 == null) return;
        if (!manager.getConfig().showCoreBeams) return;

        var cores = manager.getActiveCores();
        if (cores.isEmpty()) return;

        class_4597.class_4598 imm = mc.method_22940().method_23000();
        class_327 tr = mc.field_1772;

        double camX = camera.method_71156().field_1352;
        double camY = camera.method_71156().field_1351;
        double camZ = camera.method_71156().field_1350;

        // Slow pulse so the beam reads as "alive"
        float pulse = (float)(0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 400.0));
        int alpha = 60 + (int)(50 * pulse);

        for (EventScheduleManager.ActiveCore core : cores) {
            float cx = (float)(core.x + 0.5 - camX);
            float cz = (float)(core.z + 0.5 - camZ);
            float y0 = (float)(core.y - BEAM_DOWN - camY);
            float y1 = (float)(core.y + BEAM_UP   - camY);

            matrices.method_22903();
            Matrix4f mat = matrices.method_23760().method_23761();
            class_4588 vc = imm.method_73477(class_12249.method_76023());

            // 4 faces of a square column, each drawn double-sided
            beamFace(vc, mat, cx - BEAM_HALF, y0, cz - BEAM_HALF, cx + BEAM_HALF, y1, cz - BEAM_HALF, alpha);
            beamFace(vc, mat, cx + BEAM_HALF, y0, cz - BEAM_HALF, cx + BEAM_HALF, y1, cz + BEAM_HALF, alpha);
            beamFace(vc, mat, cx + BEAM_HALF, y0, cz + BEAM_HALF, cx - BEAM_HALF, y1, cz + BEAM_HALF, alpha);
            beamFace(vc, mat, cx - BEAM_HALF, y0, cz + BEAM_HALF, cx - BEAM_HALF, y1, cz - BEAM_HALF, alpha);

            // Bright inner core (thinner, more opaque)
            float inner = BEAM_HALF * 0.35f;
            int innerAlpha = Math.min(255, alpha + 90);
            beamFace(vc, mat, cx - inner, y0, cz - inner, cx + inner, y1, cz - inner, innerAlpha);
            beamFace(vc, mat, cx + inner, y0, cz - inner, cx + inner, y1, cz + inner, innerAlpha);
            beamFace(vc, mat, cx + inner, y0, cz + inner, cx - inner, y1, cz + inner, innerAlpha);
            beamFace(vc, mat, cx - inner, y0, cz + inner, cx - inner, y1, cz - inner, innerAlpha);

            matrices.method_22909();
            imm.method_22993();

            // ── Floating label with distance ──────────────────────────────
            double dist = Math.sqrt(mc.field_1724.method_5649(
                    core.x + 0.5, core.y, core.z + 0.5));
            String label = "§6⚑ CORE" + (core.name != null ? " §e" + core.name : "")
                    + " §f" + (int) dist + "m";
            int width = tr.method_1727(label);

            // Scale label up with distance so it stays readable from far away
            float ds = 0.025f * Math.max(1.5f, (float)(dist / 12.0));

            matrices.method_22903();
            matrices.method_22904(core.x + 0.5 - camX, core.y + 3.0 - camY, core.z + 0.5 - camZ);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
            matrices.method_22905(-ds, -ds, ds);

            tr.method_27522(class_2561.method_43470(label), -width / 2f, 0f,
                    0xFFFFAA00, false,
                    matrices.method_23760().method_23761(), imm,
                    class_327.class_6415.field_33994,
                    0x40000000, 15728880);
            matrices.method_22909();
            imm.method_22993();
        }
    }

    /** One vertical quad from (x0,y0,z0) to (x1,y1,z1), drawn on both sides. */
    private static void beamFace(class_4588 vc, Matrix4f mat,
                                 float x0, float y0, float z0,
                                 float x1, float y1, float z1, int alpha) {
        // front winding
        vc.method_22918(mat, x0, y0, z0).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha);
        vc.method_22918(mat, x1, y0, z1).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha);
        vc.method_22918(mat, x1, y1, z1).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha / 3);
        vc.method_22918(mat, x0, y1, z0).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha / 3);
        // back winding (visible from the other side)
        vc.method_22918(mat, x0, y1, z0).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha / 3);
        vc.method_22918(mat, x1, y1, z1).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha / 3);
        vc.method_22918(mat, x1, y0, z1).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha);
        vc.method_22918(mat, x0, y0, z0).method_1336(BEAM_R, BEAM_G, BEAM_B, alpha);
    }
}
