package org.cheetahv2.antigravity.client.tracker;

import java.util.*;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;

/**
 * PlayerTracker
 *
 * 1. Held-item history: last 10 distinct main-hand items per player.
 * 2. Inventory snapshots: every visible player's armor + hands + health is
 *    snapshotted continuously, so /invsee <name> can show what someone was
 *    carrying even after they leave render distance.
 */
public class PlayerTracker {

    // ── Held-item history ─────────────────────────────────────────────────
    private final Map<String, ArrayDeque<class_1799>> heldHistory = new LinkedHashMap<>();

    // ── Inventory snapshots ───────────────────────────────────────────────

    public static class InvSnapshot {
        public final String name;              // exact-case player name
        public final class_1799 head, chest, legs, feet, mainHand, offHand;
        public final float health, maxHealth;
        public long seenAtMs;

        InvSnapshot(class_1657 p) {
            this.name      = p.method_5477().getString();
            this.head      = p.method_31548().method_5438(39).method_7972();
            this.chest     = p.method_31548().method_5438(38).method_7972();
            this.legs      = p.method_31548().method_5438(37).method_7972();
            this.feet      = p.method_31548().method_5438(36).method_7972();
            this.mainHand  = p.method_6047().method_7972();
            this.offHand   = p.method_6079().method_7972();
            this.health    = p.method_6032();
            this.maxHealth = p.method_6063();
            this.seenAtMs  = System.currentTimeMillis();
        }
    }

    /** lower-case name → latest snapshot. Kept for the whole session. */
    private final Map<String, InvSnapshot> snapshots = new LinkedHashMap<>();

    private int tickCounter = 0;

    public void tick(class_310 mc) {
        if (mc == null || mc.field_1687 == null) return;
        boolean snapshotTick = ++tickCounter % 10 == 0; // refresh snapshots every 0.5s

        for (class_1657 p : mc.field_1687.method_18456()) {
            String name = p.method_5477().getString();

            // held-item history
            class_1799 hand = p.method_6047();
            ArrayDeque<class_1799> hist = heldHistory.computeIfAbsent(name, k -> new ArrayDeque<>());
            class_1799 last = hist.isEmpty() ? class_1799.field_8037 : hist.peekFirst();
            if (!class_1799.method_7984(hand, last)) {
                if (!hand.method_7960()) {
                    hist.addFirst(hand.method_7972());
                    while (hist.size() > 10) hist.pollLast();
                }
            }

            // inventory snapshot
            if (snapshotTick && p != mc.field_1724) {
                snapshots.put(name.toLowerCase(), new InvSnapshot(p));
            }
        }
    }

    public List<class_1799> getHistory(String playerName) {
        ArrayDeque<class_1799> hist = heldHistory.get(playerName);
        return hist == null ? Collections.emptyList() : new ArrayList<>(hist);
    }

    /** Latest snapshot for this player (case-insensitive), or null if never seen. */
    public InvSnapshot getSnapshot(String playerName) {
        if (playerName == null) return null;
        return snapshots.get(playerName.toLowerCase().trim());
    }

    /** Names of all players we have snapshots for (exact case). */
    public List<String> getSnapshotNames() {
        List<String> names = new ArrayList<>(snapshots.size());
        for (InvSnapshot s : snapshots.values()) names.add(s.name);
        return names;
    }
}
