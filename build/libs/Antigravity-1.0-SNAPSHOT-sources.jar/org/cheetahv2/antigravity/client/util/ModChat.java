package org.cheetahv2.antigravity.client.util;

import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * ModChat — sends the mod's own chat messages behind a re-entrancy flag.
 *
 * Client-side sendMessage() re-enters the chat event, so a message the mod
 * prints is parsed again by the mod. If that text happens to match one of our
 * own detectors, it prints another message, which is parsed again... which is
 * exactly how the queue's "slow down" warning stack-overflowed the client.
 *
 * Everything the mod prints goes through here, and chat handlers skip input
 * while {@link #isSending()} is true.
 */
public final class ModChat {

    private static boolean sending = false;

    private ModChat() {}

    /** True while the mod is printing its own message — chat handlers must no-op. */
    public static boolean isSending() { return sending; }

    public static void send(String msg) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        if (sending) return;               // never nest
        sending = true;
        try {
            mc.field_1724.method_7353(class_2561.method_43470(msg), false);
        } finally {
            sending = false;
        }
    }

    /** Action-bar variant (also re-entrancy safe). */
    public static void actionBar(String msg) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        if (sending) return;
        sending = true;
        try {
            mc.field_1724.method_7353(class_2561.method_43470(msg), true);
        } finally {
            sending = false;
        }
    }
}
