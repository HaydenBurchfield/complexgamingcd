package org.cheetahv2.antigravity.client.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5251;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

/**
 * GuiDumper — copies the entire open GUI (or your own inventory) as text.
 *
 * For every non-empty slot it emits: slot index, count, item id, display
 * name, and all lore lines. Formatting is serialized back into the
 * &#RRGGBB / &l-style codes servers use, so a dumped name like
 * "&#9FFB08👺 Rain Dance IV" can be pasted straight into module configs.
 *
 * Output goes to the CLIPBOARD and to config/antigravity/gui_dumps/ as a
 * timestamped .txt (clipboards get overwritten; files don't).
 */
public final class GuiDumper {

    private GuiDumper() {}

    private static final Path DUMP_DIR = Paths.get("config", "antigravity", "gui_dumps");

    /** Dump the current screen handler. Returns a short status for the action bar. */
    public static String dump(class_310 mc) {
        if (mc == null || mc.field_1724 == null) return null;

        var handler = mc.field_1724.field_7512;
        String title = mc.field_1755 != null
                ? mc.field_1755.method_25440().getString()
                : "Player Inventory";

        StringBuilder out = new StringBuilder(4096);
        out.append("=== GUI DUMP: ").append(title).append(" ===\n");
        out.append("time: ").append(LocalDateTime.now()).append('\n');
        out.append("slots: ").append(handler.field_7761.size()).append("\n\n");

        int containerItems = 0, playerItems = 0;
        StringBuilder containerSec = new StringBuilder();
        StringBuilder playerSec    = new StringBuilder();

        for (class_1735 slot : handler.field_7761) {
            class_1799 stack = slot.method_7677();
            if (stack == null || stack.method_7960()) continue;

            boolean playerSlot = slot.field_7871 instanceof class_1661;
            StringBuilder sec = playerSlot ? playerSec : containerSec;
            if (playerSlot) playerItems++; else containerItems++;

            sec.append("[slot ").append(slot.field_7874).append("] x").append(stack.method_7947())
               .append("  ").append(class_7923.field_41178.method_10221(stack.method_7909())).append('\n');
            sec.append("  Name: ").append(toCodes(stack.method_7964())).append('\n');

            var lore = stack.method_58694(class_9334.field_49632);
            if (lore != null && !lore.comp_2400().isEmpty()) {
                sec.append("  Lore:\n");
                for (class_2561 line : lore.comp_2400()) {
                    sec.append("    ").append(toCodes(line)).append('\n');
                }
            }
            sec.append('\n');
        }

        if (containerItems > 0) {
            out.append("── Container (").append(containerItems).append(" items) ──\n\n");
            out.append(containerSec);
        }
        out.append("── Player Inventory (").append(playerItems).append(" items) ──\n\n");
        out.append(playerSec);

        String text = out.toString();

        // Clipboard
        mc.field_1774.method_1455(text);

        // File (clipboard survives one paste; files survive the session)
        String fileName = "gui_" + LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt";
        try {
            Files.createDirectories(DUMP_DIR);
            Files.writeString(DUMP_DIR.resolve(fileName), text);
        } catch (IOException ignored) {}

        return "§d✦ §fCopied GUI §7(" + (containerItems + playerItems)
                + " items) §fto clipboard §8+ gui_dumps/" + fileName;
    }

    // ── Text → &-code serialization ───────────────────────────────────────

    /**
     * Flattens a Text tree back into a string with &#RRGGBB / &l-style codes,
     * matching the ampersand format used in server configs.
     */
    public static String toCodes(class_2561 text) {
        StringBuilder sb = new StringBuilder();
        final class_2583[] last = { null };
        text.method_27658((style, str) -> {
            if (!str.isEmpty()) {
                if (!style.equals(last[0])) {
                    sb.append(codesFor(style));
                    last[0] = style;
                }
                sb.append(str);
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return sb.toString();
    }

    private static String codesFor(class_2583 s) {
        StringBuilder c = new StringBuilder();
        class_5251 col = s.method_10973();
        if (col != null) {
            // Prefer the legacy &x code for exact named colors, hex otherwise
            class_124 named = namedFormatting(col);
            if (named != null) c.append('&').append(named.method_36145());
            else               c.append(String.format("&#%06X", col.method_27716()));
        }
        if (s.method_10984())          c.append("&l");
        if (s.method_10966())        c.append("&o");
        if (s.method_10965())    c.append("&n");
        if (s.method_10986()) c.append("&m");
        if (s.method_10987())    c.append("&k");
        return c.toString();
    }

    private static class_124 namedFormatting(class_5251 col) {
        for (class_124 f : class_124.values()) {
            if (f.method_543() && f.method_532() != null && f.method_532() == col.method_27716()) {
                return f;
            }
        }
        return null;
    }
}
