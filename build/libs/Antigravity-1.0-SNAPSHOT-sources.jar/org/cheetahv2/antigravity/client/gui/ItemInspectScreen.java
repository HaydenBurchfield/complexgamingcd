package org.cheetahv2.antigravity.client.gui;

import org.lwjgl.glfw.GLFW;
import org.cheetahv2.antigravity.client.AntigravityClient;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_6880;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class ItemInspectScreen extends class_437 {

    // Unified Antigravity theme (see gui/Theme)
    private static final int
            BG          = Theme.GLASS_BG,
            GLASS_PANEL = 0x40160D2E,
            BORDER      = Theme.BORDER_SOFT,
            SHEEN       = Theme.SHEEN,
            ACCENT_GOLD = Theme.ACCENT,
            ACCENT_LIME = Theme.ACCENT_ALT,
            TXT_DIM     = Theme.TEXT_DIM,
            TXT_WHITE   = Theme.TEXT_HI,
            TAB_ACT     = 0x60A77BFF,
            TAB_HOV     = 0x30A77BFF,
            BTN_COPY    = 0xFF1C3020,
            BTN_COPY_B  = Theme.GOOD,
            ROW_EVEN    = 0x18FFFFFF,
            ROW_ODD     = 0x08FFFFFF;

    private static final int PW = 420, PH = 300;
    private static final int TAB_H = 18, HEADER_H = 26;
    private static final int COPY_BTN_W = 38, ROW_H = 11, SCROLL_BAR_W = 4;
    private static final String[] TAB_LABELS = { "\u00A7eLore", "\u00A7bStats", "\u00A77NBT" };

    private final class_1799 stack;
    private int activeTab = 0;
    private int scrollLore = 0, scrollStats = 0, scrollNbt = 0;
    private boolean draggingScroll = false;
    private double dragStartY = 0;
    private int dragStartScroll = 0;
    private List<String> loreLines;
    private List<class_2561>   loreTexts;      // NEW — for accurate hex color display
    private List<String> loreCopyLines;  // NEW — &#RRGGBB format for clipboard
    private List<String> statsLines;
    private List<String> nbtLines;
    private String styledName;           // &#RRGGBB copy string for item name
    private long copiedUntil = 0;
    private long copiedNameUntil = 0;

    // GLFW polling state — tracked frame-to-frame inside render()
    private boolean prevLeftDown = false;

    public static void openForItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return;
        class_310.method_1551().method_1507(new ItemInspectScreen(stack));
    }

    public ItemInspectScreen(class_1799 stack) {
        super(class_2561.method_43470("ItemInspect"));
        this.stack = stack.method_7972();
        buildCache();
    }

    // ----------------------------------------------------------------
    //  Keyboard — KeyInput is the correct API in this MC version
    // ----------------------------------------------------------------
    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE) { class_310.method_1551().method_1507(null); return true; }
        if (input.comp_4795() == GLFW.GLFW_KEY_1) { activeTab = 0; return true; }
        if (input.comp_4795() == GLFW.GLFW_KEY_2) { activeTab = 1; return true; }
        if (input.comp_4795() == GLFW.GLFW_KEY_3) { activeTab = 2; return true; }
        return super.method_25404(input);
    }

    // ----------------------------------------------------------------
    //  Scroll wheel — signature unchanged, no issue
    // ----------------------------------------------------------------
    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        setActiveScroll(activeScroll() - (int) verticalAmount);
        return true;
    }

    @Override
    public boolean method_25421() { return false; }

    // ----------------------------------------------------------------
    //  Render — also drives all mouse click/drag logic via GLFW polling.
    //  We never override mouseClicked / mouseDragged / mouseReleased,
    //  sidestepping the new Click-wrapper API entirely.
    // ----------------------------------------------------------------
    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {

        // --- poll GLFW for left-button state ---
        long win = class_310.method_1551().method_22683().method_4490();
        boolean leftDown = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        if (leftDown && !prevLeftDown) {
            // fresh click this frame
            onMouseClick(mx, my);
        } else if (leftDown && draggingScroll) {
            // held down and dragging scrollbar
            int total = activeLines().size(), visible = visibleRows();
            if (total > visible) {
                double ratio = (double)(total - visible) / Math.max(1, contentH() - 4);
                setActiveScroll(dragStartScroll + (int)((my - dragStartY) * ratio));
            }
        } else if (!leftDown) {
            draggingScroll = false;
        }
        prevLeftDown = leftDown;

        // --- drawing ---
        int px = px(), py = py();
        class_327 tr = field_22793;

        ctx.method_25294(0, 0, field_22789, field_22790, 0x70010108);
        ctx.method_25294(px, py, px + PW, py + PH, BG);
        gborder(ctx, px, py, PW, PH, BORDER);
        ctx.method_25294(px + 1, py + 1, px + PW - 1, py + 2, SHEEN);

        ctx.method_25294(px, py, px + PW, py + HEADER_H, GLASS_PANEL);
        gborder(ctx, px, py, PW, HEADER_H, BORDER);
        ctx.method_25294(px + 1, py + 1, px + 3, py + HEADER_H - 1, ACCENT_GOLD);
        ctx.method_51427(stack, px + 5, py + 4);

        ctx.method_25303(tr, "\u2726 \u00A77Item Inspect \u00A78| ", px + 24, py + 9, TXT_WHITE);
        int prefixW = tr.method_1727("\u2726 \u00A77Item Inspect \u00A78| ");
        ctx.method_27535(tr, stack.method_7964(), px + 24 + prefixW, py + 9, TXT_WHITE);

// "Copy Name" button — right side of header, left of ESC
        String cnLabel = System.currentTimeMillis() < copiedNameUntil ? "\u00A7aCopied!" : "\u00A7bName";
        int cnW = tr.method_1727(cnLabel) + 8, cnH = 12;
        int cnX = px + PW - cnW - 22, cnY = py + 7;
        boolean cnHov = mx >= cnX && mx < cnX + cnW && my >= cnY && my < cnY + cnH;
        ctx.method_25294(cnX, cnY, cnX + cnW, cnY + cnH, cnHov ? 0x605AB4FF : 0x201C3A);
        gborder(ctx, cnX, cnY, cnW, cnH, cnHov ? 0xFF5AB4FF : 0x30FFFFFF);
        ctx.method_25300(tr, cnLabel, cnX + cnW / 2, cnY + 2, TXT_WHITE);

        String esc = "\u00A78ESC";
        ctx.method_25303(tr, esc, px + PW - tr.method_1727(esc) - 6, py + 9, TXT_DIM);

        int tabW = PW / TAB_LABELS.length;
        int tabY = py + HEADER_H;
        for (int i = 0; i < TAB_LABELS.length; i++) {
            int tx = px + i * tabW;
            boolean active = i == activeTab;
            boolean hov    = mx >= tx && mx < tx + tabW && my >= tabY && my < tabY + TAB_H;
            ctx.method_25294(tx, tabY, tx + tabW, tabY + TAB_H, active ? TAB_ACT : hov ? TAB_HOV : 0x10FFFFFF);
            gborder(ctx, tx, tabY, tabW, TAB_H, active ? 0x60FFFFFF : 0x15FFFFFF);
            if (active) ctx.method_25294(tx, tabY + TAB_H - 1, tx + tabW, tabY + TAB_H, ACCENT_GOLD);
            int lw = tr.method_1727(TAB_LABELS[i]);
            ctx.method_25303(tr, TAB_LABELS[i], tx + (tabW - lw) / 2, tabY + 5, active ? ACCENT_GOLD : TXT_DIM);
        }

        int cy = contentY(), cw = PW - 12, ch = contentH();
        int cx = px + 6;
        ctx.method_25294(cx, cy, cx + cw, cy + ch, 0x18000000);
        gborder(ctx, cx, cy, cw, ch, 0x15FFFFFF);

        ctx.method_44379(cx + 1, cy + 1, cx + cw - 1, cy + ch - 1);
        List<String> lines = activeLines();
        int scroll = activeScroll();
        int displayCw = cw - SCROLL_BAR_W - 6;
        int ry = cy + 3;
        for (int i = scroll; i < lines.size() && (ry - cy) < ch - 2; i++) {
            String raw = lines.get(i);
            ctx.method_25294(cx + 1, ry - 1, cx + displayCw + 1, ry + ROW_H - 1, (i % 2 == 0) ? ROW_EVEN : ROW_ODD);
            if (activeTab == 0 && i < loreTexts.size()) {
                ctx.method_27535(tr, loreTexts.get(i), cx + 3, ry, TXT_WHITE);
            } else {
                ctx.method_25303(tr, raw, cx + 3, ry, TXT_WHITE);
            }
            if (activeTab == 0) {
                int bx = cx + displayCw - COPY_BTN_W + 2;
                boolean bhov = mx >= bx && mx < bx + COPY_BTN_W && my >= ry - 1 && my < ry + ROW_H;
                ctx.method_25294(bx, ry - 1, bx + COPY_BTN_W, ry + ROW_H - 1, bhov ? 0x604AE87A : BTN_COPY);
                gborder(ctx, bx, ry - 1, COPY_BTN_W, ROW_H, bhov ? BTN_COPY_B : 0x30FFFFFF);
                ctx.method_25303(tr, "\u00A7aCopy", bx + 3, ry, bhov ? ACCENT_LIME : TXT_DIM);
            }
            ry += ROW_H;
        }
        ctx.method_44380();

        int total = lines.size(), visible = visibleRows();
        if (total > visible) {
            int sbX = cx + cw - SCROLL_BAR_W - 1, sbH = ch - 4;
            int thumbH = Math.max(10, sbH * visible / total);
            int thumbY = cy + 2 + (sbH - thumbH) * scroll / (total - visible);
            ctx.method_25294(sbX, cy + 2, sbX + SCROLL_BAR_W, cy + ch - 2, 0x20FFFFFF);
            ctx.method_25294(sbX, thumbY, sbX + SCROLL_BAR_W, thumbY + thumbH, 0x90FFFFFF);
        }

        if (activeTab == 0) {
            int bw2 = 90, bh2 = 14, bx2 = px + PW - bw2 - 6, by2 = py + PH - bh2 - 4;
            boolean bhov2 = mx >= bx2 && mx < bx2 + bw2 && my >= by2 && my < by2 + bh2;
            ctx.method_25294(bx2, by2, bx2 + bw2, by2 + bh2, bhov2 ? 0x604AE87A : 0x201C3020);
            gborder(ctx, bx2, by2, bw2, bh2, bhov2 ? BTN_COPY_B : 0x30FFFFFF);
            ctx.method_25303(tr, "\u00A7aCopy All Lore", bx2 + 4, by2 + 3, bhov2 ? ACCENT_LIME : TXT_DIM);
        }

        if (System.currentTimeMillis() < copiedUntil) {
            long rem = copiedUntil - System.currentTimeMillis();
            int alpha = (rem < 400) ? (int)(rem * 255 / 400) : 255;
            String msg = "\u00A7a\u2714 Copied!";
            int mw = tr.method_1727(msg);
            ctx.method_25303(tr, msg, px + PW / 2 - mw / 2, py + PH - 18, (alpha << 24) | 0x4AE87A);
        }

        super.method_25394(ctx, mx, my, delta);
    }

    // ----------------------------------------------------------------
    //  Click logic (called from render on fresh left-click)
    // ----------------------------------------------------------------
    private void onMouseClick(int mx, int my) {
        int px = px(), py = py();

        // Copy Name button hit test
        String cnLabel2 = "\u00A7bName";
        int cnW2 = field_22793.method_1727(cnLabel2) + 8, cnH2 = 12;
        int cnX2 = px() + PW - cnW2 - 22, cnY2 = py() + 7;
        if (mx >= cnX2 && mx < cnX2 + cnW2 && my >= cnY2 && my < cnY2 + cnH2) {
            copyToClipboard(styledName);
            copiedNameUntil = System.currentTimeMillis() + 1200;
            return;
        }

        // Tab bar
        int tabW = PW / TAB_LABELS.length;
        int tabY = py + HEADER_H;
        for (int i = 0; i < TAB_LABELS.length; i++) {
            int tx = px + i * tabW;
            if (mx >= tx && mx < tx + tabW && my >= tabY && my < tabY + TAB_H) {
                activeTab = i;
                return;
            }
        }

        // Per-row copy buttons (Lore tab only)
        if (activeTab == 0) {
            int cx = px + 6, cy = contentY(), cw = PW - 12;
            int displayCw = cw - SCROLL_BAR_W - 6;
            int ry = cy + 3;
            for (int i = scrollLore; i < loreLines.size() && (ry - cy) < contentH() - 2; i++) {
                int bx = cx + displayCw - COPY_BTN_W + 2;
                if (mx >= bx && mx < bx + COPY_BTN_W && my >= ry - 1 && my < ry + ROW_H) {
                    copyToClipboard(loreCopyLines.get(i));
                    return;
                }
                ry += ROW_H;
            }
            // Copy All Lore button
            int bw2 = 90, bh2 = 14, bx2 = px + PW - bw2 - 6, by2 = py + PH - bh2 - 4;
            if (mx >= bx2 && mx < bx2 + bw2 && my >= by2 && my < by2 + bh2) {
                StringBuilder sb = new StringBuilder();
                for (String l : loreCopyLines) sb.append(l).append('\n');
                copyToClipboard(sb.toString().trim());
                return;
            }
        }

        // Scrollbar drag start
        int cx = px + 6, cy = contentY(), cw = PW - 12, ch = contentH();
        int sbX = cx + cw - SCROLL_BAR_W - 1;
        if (mx >= sbX && mx < sbX + SCROLL_BAR_W + 2 && my >= cy && my < cy + ch) {
            draggingScroll = true;
            dragStartY = my;
            dragStartScroll = activeScroll();
        }
    }

    // ----------------------------------------------------------------
    //  Data builders
    // ----------------------------------------------------------------
    private void buildCache() {
        loreLines = new ArrayList<>();
        styledName = toCopyString(stack.method_7964());

        loreLines     = new ArrayList<>();
        loreTexts     = new ArrayList<>();
        loreCopyLines = new ArrayList<>();
        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore != null) {
            for (class_2561 line : lore.comp_2400()) {
                loreTexts.add(line);
                loreLines.add(line.getString());        // plain — used for row count / widths
                loreCopyLines.add(toCopyString(line));  // &#RRGGBB — used for clipboard
            }
        }
        if (loreLines.isEmpty()) {
            loreLines.add("\u00A78(no lore)");
            loreTexts.add(class_2561.method_43470("\u00A78(no lore)"));
            loreCopyLines.add("(no lore)");
        }

        // ── Crate Puller injection (top of Lore tab) ─────────────────────
        if (AntigravityClient.HUD_SETTINGS.showCratePuller) {
            String puller = AntigravityClient.extractCratePuller(stack);
            if (puller != null) {
                long ts = AntigravityClient.extractPullTimestamp(stack);
                String datePart = ts > 0
                        ? " \u00A78(\u00A77" + AntigravityClient.formatPullDate(ts) + "\u00A78)" : "";
                String pullerLine = "\u00A78[\u00A76Crate Pull\u00A78] \u00A77Pulled by: \u00A7e" + puller + datePart;
                String plainPuller = "[Crate Pull] Pulled by: " + puller
                        + (ts > 0 ? " (" + AntigravityClient.formatPullDate(ts) + ")" : "");
                // Separator between injected info and real lore (only if there is real lore below)
                boolean hasRealLore = lore != null && !lore.comp_2400().isEmpty();
                if (hasRealLore) {
                    loreLines.add(0, "\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
                    loreTexts.add(0, class_2561.method_43470("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"));
                    loreCopyLines.add(0, "---------");
                }
                loreLines.add(0, pullerLine);
                loreTexts.add(0, class_2561.method_43470(pullerLine));
                loreCopyLines.add(0, plainPuller);
            }
        }

        statsLines = new ArrayList<>();
        statsLines.add("\u00A78\u25B8 \u00A77Item ID: \u00A7f" + stack.method_7909().method_7876());
        statsLines.add("\u00A78\u25B8 \u00A77Count: \u00A7e" + stack.method_7947());

        class_9304 enchants = stack.method_58694(class_9334.field_49633);
        if (enchants != null && !enchants.method_57543()) {
            statsLines.add("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
            statsLines.add("\u00A76\u26A1 \u00A7eEnchantments");
            for (var entry : enchants.method_57539()) {
                class_6880<class_1887> e = entry.getKey();
                statsLines.add("  \u00A78\u2022 \u00A7b" + e.comp_349().comp_2686().getString() + " \u00A77" + toRoman(entry.getIntValue()));
            }
        }

        class_9304 stored = stack.method_58694(class_9334.field_49643);
        if (stored != null && !stored.method_57543()) {
            statsLines.add("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
            statsLines.add("\u00A7d\u26A1 \u00A7dStored Enchants");
            for (var entry : stored.method_57539()) {
                class_6880<class_1887> e = entry.getKey();
                statsLines.add("  \u00A78\u2022 \u00A75" + e.comp_349().comp_2686().getString() + " \u00A77" + toRoman(entry.getIntValue()));
            }
        }

        if (stack.method_7963()) {
            statsLines.add("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
            int dur = stack.method_7936() - stack.method_7919();
            statsLines.add("\u00A78\u25B8 \u00A77Durability: \u00A7a" + dur + " \u00A77/ \u00A7a" + stack.method_7936());
        }

        if (stack.method_58694(class_9334.field_49630) != null) {
            statsLines.add("\u00A78\u25B8 \u00A7cUnbreakable");
        }

        class_2561 customName = stack.method_58694(class_9334.field_49631);
        if (customName != null) {
            statsLines.add("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
            statsLines.add("\u00A78\u25B8 \u00A77Custom Name: " + customName.getString());
        }

        var cmd = stack.method_58694(class_9334.field_49637);
        if (cmd != null) {
            statsLines.add("\u00A78\u25B8 \u00A77Custom Model: \u00A7e" + cmd);
        }

        var attrs = stack.method_58694(class_9334.field_49636);
        if (attrs != null && !attrs.comp_2393().isEmpty()) {
            statsLines.add("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
            statsLines.add("\u00A7c\u2694 \u00A7cAttribute Modifiers");
            attrs.comp_2393().forEach(entry -> {
                class_1322 mod = entry.comp_2396();
                String op = switch (mod.comp_2450()) {
                    case field_6328 -> "+";
                    case field_6330 -> "xBase ";
                    case field_6331 -> "xTotal ";
                };
                statsLines.add("  \u00A78\u2022 \u00A7f" + entry.comp_2395().comp_349().method_26830() + ": \u00A7a" + op + String.format("%.2f", mod.comp_2449()));
            });
        }

        nbtLines = new ArrayList<>();
        class_9279 customData = stack.method_58694(class_9334.field_49628);
        if (customData != null) {
            class_2487 tag = customData.method_57461();
            if (tag.method_33133()) nbtLines.add("\u00A78(custom_data is empty)");
            else flattenNbt(tag, nbtLines, 0);
        } else {
            nbtLines.add("\u00A78(no custom_data on this item)");
        }
        nbtLines.add("\u00A78\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
        nbtLines.add("\u00A77Components Present:");
        stack.method_57353().forEach(entry -> nbtLines.add("  \u00A78\u2022 \u00A79" + entry.comp_2443().toString()));
    }

    private void flattenNbt(class_2487 tag, List<String> out, int depth) {
        String indent = "  ".repeat(depth);
        for (String key : tag.method_10541()) {
            class_2520 val = tag.method_10580(key);
            if (val instanceof class_2487 sub) {
                out.add(indent + "\u00A7b" + key + "\u00A77: {");
                flattenNbt(sub, out, depth + 1);
                out.add(indent + "\u00A77}");
            } else {
                String vs = val.toString();
                if (vs.length() > 60) vs = vs.substring(0, 57) + "\u00A78...";
                out.add(indent + "\u00A7b" + key + "\u00A77: \u00A7f" + vs);
            }
        }
    }

    private static String toCopyString(class_2561 text) {
        StringBuilder sb = new StringBuilder();
        text.method_27658((style, str) -> {
            if (str.isEmpty()) return java.util.Optional.empty();

            net.minecraft.class_5251 tc = style.method_10973();
            if (tc != null) {
                boolean matched = false;
                for (net.minecraft.class_124 f : net.minecraft.class_124.values()) {
                    if (f.method_543() && f.method_532() != null
                            && f.method_532().equals(tc.method_27716())) {
                        sb.append('&').append(f.method_36145());
                        matched = true;
                        break;
                    }
                }
                if (!matched) {
                    // Hex color — &#RRGGBB format
                    sb.append(String.format("&#%06X", tc.method_27716()));
                }
            }
            if (style.method_10984())          sb.append("&l");
            if (style.method_10966())        sb.append("&o");
            if (style.method_10965())    sb.append("&n");
            if (style.method_10986()) sb.append("&m");
            if (style.method_10987())    sb.append("&k");
            sb.append(str);
            return java.util.Optional.empty();
        }, net.minecraft.class_2583.field_24360);
        return sb.toString();
    }

    private static String toRoman(int n) {
        return switch (n) {
            case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV";
            case 5 -> "V"; case 6 -> "VI"; case 7 -> "VII"; case 8 -> "VIII";
            case 9 -> "IX"; case 10 -> "X"; default -> String.valueOf(n);
        };
    }

    private List<String> activeLines() {
        return switch (activeTab) { case 0 -> loreLines; case 1 -> statsLines; default -> nbtLines; };
    }

    private int activeScroll() {
        return switch (activeTab) { case 0 -> scrollLore; case 1 -> scrollStats; default -> scrollNbt; };
    }

    private void setActiveScroll(int v) {
        int max = Math.max(0, activeLines().size() - visibleRows());
        v = Math.max(0, Math.min(v, max));
        switch (activeTab) { case 0 -> scrollLore = v; case 1 -> scrollStats = v; default -> scrollNbt = v; }
    }

    private int px()          { return (field_22789  - PW) / 2; }
    private int py()          { return (field_22790 - PH) / 2; }
    private int contentY()    { return py() + HEADER_H + TAB_H + 2; }
    private int contentH()    { return PH - HEADER_H - TAB_H - 2 - 6; }
    private int visibleRows() { return Math.max(1, (contentH() - 4) / ROW_H); }

    private void copyToClipboard(String text) {
        class_310.method_1551().field_1774.method_1455(text);
        copiedUntil = System.currentTimeMillis() + 1200;
    }

    private static void gborder(class_332 c, int x, int y, int w, int h, int col) {
        c.method_25294(x, y, x + w, y + 1, col);
        c.method_25294(x, y + h - 1, x + w, y + h, col);
        c.method_25294(x, y, x + 1, y + h, col);
        c.method_25294(x + w - 1, y, x + w, y + h, col);
    }
}