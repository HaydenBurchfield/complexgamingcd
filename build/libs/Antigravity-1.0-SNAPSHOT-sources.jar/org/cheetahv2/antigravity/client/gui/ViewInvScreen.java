package org.cheetahv2.antigravity.client.gui;

import org.cheetahv2.antigravity.client.AntigravityClient;
import org.cheetahv2.antigravity.client.detection.LarkManager;
import org.cheetahv2.antigravity.client.tracker.PlayerTracker;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_11908;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * ViewInvScreen — shows a player's armor/hands + recent held items.
 *
 * Two sources:
 *   • LIVE:   a PlayerEntity currently in render distance (I-key raycast).
 *   • CACHED: a PlayerTracker.InvSnapshot — what the player had the last time
 *             they were seen. Used by "/invsee <name>" for players out of
 *             render distance. A "CACHED · seen Xs ago" badge is shown.
 */
public class ViewInvScreen extends class_437 {
    private static final int SLOT = 18;

    private final class_1657 target;          // null when showing a cached snapshot
    private final String targetName;
    private final class_1799 head, chest, legs, feet, mainHand, offHand;
    private final float snapHealth, snapMaxHealth;
    private final long seenAtMs;                // 0 = live view
    private class_1799 hoveredStack = class_1799.field_8037;

    // Liquid Glass Palette — unified Antigravity theme (see gui/Theme)
    private static final int
            GLASS_BG       = Theme.GLASS_BG,
            GLASS_BORDER   = Theme.BORDER_SOFT,
            GLASS_SHEEN    = Theme.SHEEN,
            GLASS_SHADOW   = Theme.SHADOW,
            SLOT_BORDER    = 0x108D77E8,
            COLOR_GREEN    = Theme.GOOD,
            COLOR_GOLD     = Theme.WARN,
            COLOR_WHITE    = Theme.TEXT_HI;

    /** Live view of a player in render distance. */
    public ViewInvScreen(class_1657 p) {
        super(class_2561.method_43470("viewinv"));
        this.target = p;
        this.targetName = p.method_5477().getString();
        this.head = p.method_31548().method_5438(39).method_7972();
        this.chest = p.method_31548().method_5438(38).method_7972();
        this.legs = p.method_31548().method_5438(37).method_7972();
        this.feet = p.method_31548().method_5438(36).method_7972();
        this.mainHand = p.method_6047().method_7972();
        this.offHand = p.method_6079().method_7972();
        this.snapHealth = p.method_6032();
        this.snapMaxHealth = p.method_6063();
        this.seenAtMs = 0;
    }

    /** Cached view built from the last snapshot of a player we've seen. */
    public ViewInvScreen(PlayerTracker.InvSnapshot snap) {
        super(class_2561.method_43470("viewinv"));
        this.target = null;
        this.targetName = snap.name;
        this.head = snap.head;
        this.chest = snap.chest;
        this.legs = snap.legs;
        this.feet = snap.feet;
        this.mainHand = snap.mainHand;
        this.offHand = snap.offHand;
        this.snapHealth = snap.health;
        this.snapMaxHealth = snap.maxHealth;
        this.seenAtMs = snap.seenAtMs;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private int pw() { return 340; }
    private int ph() { return 250; }
    private int px() { return (field_22789 - pw()) / 2; }
    private int py() { return (field_22790 - ph()) / 2; }

    private void drawGlassPanel(class_332 ctx, int x, int y, int w, int h) {
        ctx.method_25294(x, y, x + w, y + h, GLASS_BG);
        gborder(ctx, x, y, w, h, GLASS_BORDER);
        ctx.method_25294(x + 1, y + 1, x + w - 1, y + 2, GLASS_SHEEN);
        ctx.method_25294(x + 1, y + h - 2, x + w - 1, y + h - 1, GLASS_SHADOW);
    }

    private void drawGlassSlot(class_332 ctx, int x, int y) {
        ctx.method_25294(x, y, x + SLOT, y + SLOT, 0x40000000);
        gborder(ctx, x, y, SLOT, SLOT, SLOT_BORDER);
        ctx.method_25294(x + 1, y + 1, x + SLOT - 1, y + 2, 0x10FFFFFF);
        ctx.method_25294(x + 1, y + 1, x + 2, y + SLOT - 1, 0x10FFFFFF);
    }

    private static void gborder(class_332 c, int x, int y, int w, int h, int col) {
        c.method_25294(x, y, x + w, y + 1, col);
        c.method_25294(x, y + h - 1, x + w, y + h, col);
        c.method_25294(x, y, x + 1, y + h, col);
        c.method_25294(x + w - 1, y, x + w, y + h, col);
    }

    /** "12s ago" / "3m ago" / "1h 4m ago" */
    private static String agoStr(long sinceMs) {
        long s = sinceMs / 1000;
        if (s < 60) return s + "s ago";
        long m = s / 60;
        if (m < 60) return m + "m " + (s % 60) + "s ago";
        return (m / 60) + "h " + (m % 60) + "m ago";
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        int px = px(), py = py(), pw = pw(), ph = ph();
        ctx.method_25294(0, 0, field_22789, field_22790, 0x70020104); // subtle background dim

        drawGlassPanel(ctx, px, py, pw, ph);

        // Header
        ctx.method_25294(px + 6, py + 6, px + pw - 6, py + 24, 0x30000000);
        gborder(ctx, px + 6, py + 6, pw - 12, 18, 0x10FFFFFF);
        ctx.method_25303(field_22793, Theme.WORDMARK + " §8| §fViewing: §d" + targetName, px + 12, py + 11, COLOR_WHITE);

        boolean cached = target == null;

        // Badge (top right): Lark level for live views, CACHED for snapshots
        if (cached) {
            String badge = "⌛ CACHED · " + agoStr(System.currentTimeMillis() - seenAtMs);
            int bw = field_22793.method_1727(badge) + 10;
            ctx.method_25294(px + pw - bw - 12, py + 8, px + pw - 12, py + 22, 0x60201800);
            gborder(ctx, px + pw - bw - 12, py + 8, bw, 14, COLOR_GOLD);
            ctx.method_25303(field_22793, badge, px + pw - bw - 7, py + 11, COLOR_GOLD);
        } else {
            int larkLvl = LarkManager.getLarkLevel(mainHand);
            if (larkLvl > 0) {
                String[] R = {"", "I", "II", "III", "IV", "V"};
                String badge = "⚔ Lark " + R[Math.min(larkLvl, 5)];
                int bw = field_22793.method_1727(badge) + 10;
                ctx.method_25294(px + pw - bw - 12, py + 8, px + pw - 12, py + 22, 0x60002000);
                gborder(ctx, px + pw - bw - 12, py + 8, bw, 14, COLOR_GREEN);
                ctx.method_25303(field_22793, badge, px + pw - bw - 7, py + 11, 0xFF4AE87A);
            }
        }

        int ly = py + 34;

        // Target stats info slot (Health & state)
        ctx.method_25294(px + 8, ly, px + pw - 8, ly + 18, 0x20FFFFFF);
        gborder(ctx, px + 8, ly, pw - 16, 18, 0x10FFFFFF);

        float hp    = target != null ? target.method_6032()    : snapHealth;
        float maxHp = target != null ? target.method_6063() : snapMaxHealth;
        String hpStr = String.format("§c❤ §fHealth: §e%.1f/%.1f%s", hp, maxHp,
                cached ? " §8(last seen)" : "");
        ctx.method_25303(field_22793, hpStr, px + 14, ly + 5, COLOR_WHITE);

        String stateStr = cached
                ? "§6⌛ §fState: §eOut of range"
                : "§9⏳ §fState: " + (target.method_29504() ? "§cDead" : "§aAlive");
        int tw = field_22793.method_1727(stateStr);
        ctx.method_25303(field_22793, stateStr, px + pw - tw - 14, ly + 5, COLOR_WHITE);

        ly += 24;

        // Section Label
        ctx.method_25303(field_22793, "§8Target Equipment Slots:", px + 8, ly, Theme.ACCENT);
        ly += 11;

        class_1799[] equip = {head, chest, legs, feet, mainHand, offHand};
        String[] labels = {"Head", "Chest", "Legs", "Feet", "Hand", "Off"};
        int slotY = ly, slotX = px + 8;
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            drawSlot(ctx, field_22793, mx, my, sx, slotY, equip[i], labels[i]);
            if (!equip[i].method_7960() && equip[i].method_7963()) {
                int dur = equip[i].method_7936() - equip[i].method_7919();
                int maxDur = equip[i].method_7936();
                float pct = (float) dur / maxDur;
                int col = pct > 0.6f ? 0xFF4AE87A : pct > 0.3f ? 0xFFFFD060 : 0xFFE84A6A;
                String durStr = dur + "/" + maxDur;
                ctx.method_25300(field_22793, durStr, sx + SLOT / 2, slotY + SLOT + 10, col);
            }
        }
        ly += SLOT + 22;

        // Visual divider
        ctx.method_25294(px + 8, ly, px + pw - 8, ly + 1, 0x20FFFFFF);
        ly += 6;

        ctx.method_25303(field_22793, "§8Recent Held Items Logs:", px + 8, ly, Theme.ACCENT);
        ly += 11;

        List<class_1799> hist = AntigravityClient.PLAYER_TRACKER.getHistory(targetName);
        int histX = px + 8;
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            int sx = histX + i * (SLOT + 6);
            if (sx + SLOT > px + pw - 6) break;
            drawSlot(ctx, field_22793, mx, my, sx, ly, hist.get(i), null);
        }
        if (hist.isEmpty()) {
            ctx.method_25303(field_22793, "§8No logs recorded yet.", px + 8, ly + 4, 0xFF7F7F7F);
        }

        // Close instruction footer
        ctx.method_25294(px + 6, py + ph - 16, px + pw - 6, py + ph - 6, 0x30000000);
        gborder(ctx, px + 6, py + ph - 16, pw - 12, 10, 0x10FFFFFF);
        ctx.method_25300(field_22793, "§8Press ESC key to exit screen", px + pw / 2, py + ph - 15, 0xFF7F7F7F);

        super.method_25394(ctx, mx, my, delta);

        // Tooltip rendering over everything else
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            if (mx >= sx && mx < sx + SLOT && my >= slotY && my < slotY + SLOT && !equip[i].method_7960()) {
                ctx.method_51446(field_22793, equip[i], mx, my);
            }
        }
        int hy2 = py + 34 + 24 + 11 + SLOT + 22 + 6 + 11;
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            int sx = histX + i * (SLOT + 6);
            if (sx + SLOT > px + pw - 6) break;
            if (mx >= sx && mx < sx + SLOT && my >= hy2 && my < hy2 + SLOT && !hist.get(i).method_7960()) {
                ctx.method_51446(field_22793, hist.get(i), mx, my);
            }
        }

        // Track which item the mouse is over (for Z key inspection)
        hoveredStack = class_1799.field_8037;
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            if (mx >= sx && mx < sx + SLOT && my >= slotY && my < slotY + SLOT && !equip[i].method_7960()) {
                hoveredStack = equip[i];
                break;
            }
        }
        if (hoveredStack.method_7960()) {
            for (int i = 0; i < Math.min(10, hist.size()); i++) {
                int sx = histX + i * (SLOT + 6);
                if (sx + SLOT > px + pw - 6) break;
                if (mx >= sx && mx < sx + SLOT && my >= hy2 && my < hy2 + SLOT && !hist.get(i).method_7960()) {
                    hoveredStack = hist.get(i);
                    break;
                }
            }
        }
    }

    private void drawSlot(class_332 ctx, class_327 tr, int mx, int my, int sx, int sy, class_1799 stack, String label) {
        boolean hov = mx >= sx && mx < sx + SLOT && my >= sy && my < sy + SLOT;

        drawGlassSlot(ctx, sx, sy);

        if (hov) {
            ctx.method_25294(sx + 1, sy + 1, sx + SLOT - 1, sy + SLOT - 1, 0x20FFFFFF);
        }

        if (!stack.method_7960()) {
            ctx.method_51427(stack, sx + 1, sy + 1);
            ctx.method_51432(tr, stack, sx + 1, sy + 1, null);
        }
        if (label != null) {
            ctx.method_25300(tr, "§8" + label, sx + SLOT / 2, sy + SLOT + 2, 0xFF888888);
        }
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
            class_310.method_1551().method_1507(null);
            return true;
        }
        int inspectKey = net.minecraft.class_3675
                .method_15981(AntigravityClient.inspectItemKey.method_1428())
                .method_1444();
        if (input.comp_4795() == inspectKey && !hoveredStack.method_7960()) {
            class_310.method_1551().method_1507(new ItemInspectScreen(hoveredStack));
            return true;
        }
        return super.method_25404(input);
    }
}
