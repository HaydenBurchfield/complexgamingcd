package org.cheetahv2.antigravity.client.mixin;

import net.minecraft.class_310;
import org.cheetahv2.antigravity.client.AutoClickManager;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects right before handleInputEvents() runs inside MinecraftClient.tick().
 *
 * This fires every tick regardless of window focus (multiplayer ticks continue
 * in the background). By setting LMB pressed HERE — before the game reads key
 * states — it overrides the GLFW key-up that fires on focus loss, so the click
 * is seen as held both focused and unfocused.
 */
@Mixin(class_310.class)
public class MinecraftClientAutoClickMixin {

    @Inject(
        method = "tick",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/MinecraftClient;handleInputEvents()V"
        )
    )
    private void cgc_autoClickBeforeInput(CallbackInfo ci) {
        class_310 mc = (class_310)(Object)this;
        if (!AutoClickManager.shouldClick()) return;
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) return;

        net.minecraft.class_304.method_1416(
            net.minecraft.class_3675.class_307.field_1672
                .method_1447(GLFW.GLFW_MOUSE_BUTTON_LEFT),
            true
        );
    }
}
