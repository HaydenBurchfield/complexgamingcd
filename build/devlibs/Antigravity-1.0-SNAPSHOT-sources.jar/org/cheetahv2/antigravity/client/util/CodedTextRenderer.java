package org.cheetahv2.antigravity.client.util;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * CodedTextRenderer — draws strings that contain &#RRGGBB hex codes.
 *
 * Vanilla text rendering only understands §-codes with the 16 legacy colours,
 * so gradient signatures/lore previewed through it come out flat. This walks
 * the string itself, tracking colour + format state, and draws each run with
 * its real RGB value — which is what makes the editor previews look like the
 * finished item.
 *
 * Supported: &#RRGGBB, legacy &0-&f, &l &o &n &m, &r.
 */
public final class CodedTextRenderer {

    private CodedTextRenderer() {}

    private static final int[] LEGACY = {
            0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
            0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
    };

    /**
     * Draws coded text, clipped to maxWidth (an ellipsis is appended if it
     * doesn't fit). Returns the pixel width actually drawn.
     */
    public static int draw(DrawContext ctx, TextRenderer tr, String coded,
                           int x, int y, int maxWidth, int defaultColor) {
        if (coded == null || coded.isEmpty()) return 0;

        int color = defaultColor;
        boolean bold = false, italic = false, underline = false, strike = false;
        StringBuilder run = new StringBuilder();
        int drawX = x;

        for (int i = 0; i < coded.length(); i++) {
            char c = coded.charAt(i);
            boolean isCode = (c == '&' || c == '§') && i + 1 < coded.length();

            if (isCode) {
                char n = coded.charAt(i + 1);

                // &#RRGGBB
                if (n == '#' && i + 7 < coded.length()) {
                    String hex = coded.substring(i + 2, i + 8);
                    try {
                        int rgb = (int) Long.parseLong(hex, 16);
                        drawX = flush(ctx, tr, run, drawX, y, color, bold, italic, underline, strike,
                                x + maxWidth);
                        color = 0xFF000000 | rgb;
                        i += 7;
                        continue;
                    } catch (NumberFormatException ignored) { /* not a real code */ }
                }

                int legacy = "0123456789abcdef".indexOf(Character.toLowerCase(n));
                if (legacy >= 0) {
                    drawX = flush(ctx, tr, run, drawX, y, color, bold, italic, underline, strike,
                            x + maxWidth);
                    color = 0xFF000000 | LEGACY[legacy];
                    bold = italic = underline = strike = false;
                    i++;
                    continue;
                }

                char f = Character.toLowerCase(n);
                if (f == 'l' || f == 'o' || f == 'n' || f == 'm' || f == 'r' || f == 'k') {
                    drawX = flush(ctx, tr, run, drawX, y, color, bold, italic, underline, strike,
                            x + maxWidth);
                    switch (f) {
                        case 'l' -> bold = true;
                        case 'o' -> italic = true;
                        case 'n' -> underline = true;
                        case 'm' -> strike = true;
                        case 'r' -> { bold = italic = underline = strike = false; color = defaultColor; }
                        default  -> { }
                    }
                    i++;
                    continue;
                }
            }
            run.append(c);
            if (drawX > x + maxWidth) break;
        }
        drawX = flush(ctx, tr, run, drawX, y, color, bold, italic, underline, strike, x + maxWidth);
        return drawX - x;
    }

    /** Draws the buffered run with the current style, returns the new x. */
    private static int flush(DrawContext ctx, TextRenderer tr, StringBuilder run,
                             int x, int y, int color,
                             boolean bold, boolean italic, boolean underline, boolean strike,
                             int limitX) {
        if (run.length() == 0) return x;
        String s = run.toString();
        run.setLength(0);
        if (x >= limitX) return x;

        // Re-apply formatting through §-codes; the colour is passed explicitly
        StringBuilder styled = new StringBuilder();
        if (bold)      styled.append("§l");
        if (italic)    styled.append("§o");
        if (underline) styled.append("§n");
        if (strike)    styled.append("§m");
        styled.append(s);

        String out = styled.toString();
        int w = tr.getWidth(out);
        if (x + w > limitX) {
            // Trim to fit and mark the cut
            while (out.length() > 1 && x + tr.getWidth(out + "…") > limitX) {
                out = out.substring(0, out.length() - 1);
            }
            out = out + "…";
            w = tr.getWidth(out);
        }
        ctx.drawTextWithShadow(tr, out, x, y, color);
        return x + w;
    }

    /** Visible width of coded text once codes are removed. */
    public static int width(TextRenderer tr, String coded) {
        return tr.getWidth(GradientUtil.stripCodes(coded));
    }

    // ── Centering ─────────────────────────────────────────────────────────

    /**
     * Pixel width of coded text AS IT WILL RENDER. Hex codes are dropped but
     * &l/&o are converted to §-codes first, because bold characters are one
     * pixel wider each — ignoring that is why naive space-padding always
     * lands slightly off-centre.
     */
    public static int measure(TextRenderer tr, String coded) {
        if (coded == null || coded.isEmpty()) return 0;
        String s = coded.replaceAll("&#[0-9A-Fa-f]{6}", "")
                        .replaceAll("&([0-9a-fk-orA-FK-OR])", "§$1");
        return tr.getWidth(s);
    }

    /** Counts leading pad units ("&f " pairs, or bare leading spaces). */
    public static int countPad(String coded) {
        if (coded == null || coded.isEmpty()) return 0;
        int pad = 0, i = 0;
        while (i < coded.length()) {
            char c = coded.charAt(i);
            if ((c == '&' || c == '§') && i + 2 < coded.length()
                    && "0123456789abcdefrABCDEFR".indexOf(coded.charAt(i + 1)) >= 0
                    && Character.isWhitespace(coded.charAt(i + 2))) {
                pad++; i += 3;
            } else if (Character.isWhitespace(c)) {
                pad++; i++;
            } else break;
        }
        return pad;
    }

    /** Rebuilds N pad units in the "&f " form the server preserves. */
    public static String padUnits(int n) {
        return n <= 0 ? "" : "&f ".repeat(n);
    }

    /** Removes ONE "&f " pad unit (or one leading space) — manual nudge. */
    public static String stripOnePad(String coded) {
        if (coded == null) return "";
        String s = coded.replaceFirst("^[&§][0-9a-fA-FrR]\\s", "");
        if (!s.equals(coded)) return s;
        return coded.replaceFirst("^\\s", "");
    }

    /** Removes leading padding so re-centering never compounds. */
    public static String stripLeadingPad(String coded) {
        if (coded == null) return "";
        // Handles "&f ", repeated "&f &f &f ", "§f ", and plain leading spaces
        return coded.replaceFirst("^(?:[&§][0-9a-fA-FrR]\\s*|\\s)+", "");
    }

    /**
     * Left-pads coded text with spaces so it is centred inside targetPx.
     *
     * IMPORTANT: each pad space gets its own "&f" prefix ("&f &f &f "), not
     * one code followed by a run of spaces. Servers routinely collapse or trim
     * consecutive whitespace in lore/sign text, which silently killed the
     * padding — the per-space code is what survives (and is exactly the style
     * used by hand-built signatures).
     */
    public static String centerTo(TextRenderer tr, String coded, int targetPx) {
        String body = stripLeadingPad(coded);
        if (body.isBlank()) return body;
        int w = measure(tr, body);
        if (w >= targetPx) return body;
        int spaceW = Math.max(1, tr.getWidth(" "));
        int pad = Math.round((targetPx - w) / 2f / spaceW);
        if (pad <= 0) return body;
        return "&f ".repeat(pad) + body;
    }

    /**
     * Centres every line against the widest line in the set — which is what
     * makes a title sit exactly between two border rows.
     */
    public static java.util.List<String> centerAll(TextRenderer tr, java.util.List<String> lines) {
        int widest = 0;
        for (String l : lines) {
            if (l == null || l.isBlank()) continue;
            widest = Math.max(widest, measure(tr, stripLeadingPad(l)));
        }
        java.util.List<String> out = new java.util.ArrayList<>(lines.size());
        for (String l : lines) {
            if (l == null || l.isBlank()) { out.add(l == null ? "" : l); continue; }
            out.add(centerTo(tr, l, widest));
        }
        return out;
    }
}
