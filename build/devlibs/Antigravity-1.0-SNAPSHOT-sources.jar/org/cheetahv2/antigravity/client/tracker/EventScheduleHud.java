package org.cheetahv2.antigravity.client.tracker;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/**
 * EventScheduleHud
 *
 * Renders a compact HUD panel showing:
 *  • Current active event (if any) or next 2 upcoming events with countdowns
 *  • All active DestroyTheCore spawn locations (multiple beams tracked)
 *
 * Position/scale are stored in EventScheduleManager.Config and editable in the
 * unified HUD editor. Default: bottom-left.
 */
public class EventScheduleHud {

    // ── Colours — unified Antigravity theme (see gui/Theme) ──────────────
    private static final int
        BG          = org.cheetahv2.antigravity.client.gui.Theme.GLASS_BG,
        BORDER      = org.cheetahv2.antigravity.client.gui.Theme.BORDER,
        ACCENT      = org.cheetahv2.antigravity.client.gui.Theme.ACCENT,
        TEXT_MID    = org.cheetahv2.antigravity.client.gui.Theme.TEXT_MID,
        TEXT_DIM    = org.cheetahv2.antigravity.client.gui.Theme.TEXT_DIM;

    public static final int PANEL_W  = 170;
    private static final int LINE_H   = 10;
    private static final int PADDING  = 5;

    /** Panel height from the last render — used by the HUD editor ghost box. */
    private static int lastPanelH = 60;

    private EventScheduleHud() {}

    public static int getPanelH() { return lastPanelH; }

    public static int getX(EventScheduleManager manager, int sw, int sh) {
        var cfg = manager.getConfig();
        if (cfg.hudX >= 0) return cfg.hudX;
        return 6;
    }

    public static int getY(EventScheduleManager manager, int sw, int sh) {
        var cfg = manager.getConfig();
        if (cfg.hudY >= 0) return cfg.hudY;
        return sh - (int)(lastPanelH * getScale(manager)) - 6;
    }

    public static float getScale(EventScheduleManager manager) {
        return Math.max(0.4f, Math.min(3.0f, manager.getConfig().hudScale));
    }

    // ── Public entry point ─────────────────────────────────────────────────

    public static void render(DrawContext ctx, MinecraftClient mc,
                              EventScheduleManager manager) {
        if (mc == null || mc.getWindow() == null) return;
        if (!manager.isHudEnabled()) return;

        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Gather data
        EventScheduleManager.ScheduledEvent current = manager.getCurrentEvent();
        List<EventScheduleManager.ScheduledEvent> upcoming = manager.getUpcomingEvents(2);
        List<EventScheduleManager.ActiveCore> cores = manager.getActiveCores();

        // Count rows
        int rows = 1; // header
        if (current != null) rows += 1;
        rows += Math.min(2, upcoming.size());
        if (current == null && upcoming.isEmpty()) rows += 1;
        if (!cores.isEmpty()) rows += 1 + cores.size(); // separator + one line per core

        int panelH = PADDING * 2 + rows * LINE_H + (rows - 1) * 2;
        lastPanelH = panelH;

        float scale = getScale(manager);
        int px = getX(manager, sw, sh);
        int py = getY(manager, sw, sh);

        var ms = ctx.getMatrices();
        ms.pushMatrix();
        ms.translate((float) px, (float) py);
        ms.scale(scale, scale);

        // Draw panel at (0,0) after translate
        drawPanel(ctx, 0, 0, PANEL_W, panelH);

        int tx = PADDING;
        int ty = PADDING;

        // ── Header ─────────────────────────────────────────────────────────
        ctx.drawTextWithShadow(tr, "§d✦ §7Events", tx, ty, TEXT_MID);
        ty += LINE_H + 2;

        // ── Current event ──────────────────────────────────────────────────
        long nowMs = System.currentTimeMillis();
        if (current != null) {
            long elapsed = nowMs - current.startMs;
            String elapsedStr = EventScheduleManager.formatCountdown(elapsed);
            ctx.drawTextWithShadow(tr,
                EventScheduleManager.eventIcon(current.type) + " "
                    + EventScheduleManager.eventName(current.type)
                    + " §a▶ §7" + elapsedStr + " ago",
                tx, ty, 0xFFFFFFFF);
            ty += LINE_H + 2;
        }

        // ── Upcoming ───────────────────────────────────────────────────────
        if (upcoming.isEmpty() && current == null) {
            ctx.drawTextWithShadow(tr, "§8No events scheduled", tx, ty, TEXT_DIM);
            ty += LINE_H + 2;
        } else {
            for (int i = 0; i < Math.min(2, upcoming.size()); i++) {
                EventScheduleManager.ScheduledEvent ev = upcoming.get(i);
                long diff = ev.startMs - nowMs;
                String countdown = EventScheduleManager.formatCountdown(diff);

                String timeColor;
                if (diff < 5 * 60 * 1000L)        timeColor = "§c";
                else if (diff < 30 * 60 * 1000L)  timeColor = "§e";
                else                              timeColor = "§7";

                String prefix = i == 0 ? "§a▸ " : "§8▸ ";
                ctx.drawTextWithShadow(tr,
                    prefix + EventScheduleManager.eventIcon(ev.type) + " "
                        + EventScheduleManager.eventName(ev.type)
                        + " §8in " + timeColor + countdown,
                    tx, ty, 0xFFFFFFFF);
                ty += LINE_H + 2;
            }
        }

        // ── Active cores (one line each) ───────────────────────────────────
        if (!cores.isEmpty()) {
            ctx.fill(tx, ty, PANEL_W - PADDING, ty + 1, BORDER);
            ty += LINE_H;

            for (EventScheduleManager.ActiveCore core : cores) {
                String where = core.name != null
                        ? "§e" + core.name
                        : "§7" + core.x + " " + core.y + " " + core.z;
                String dist = "";
                if (mc.player != null) {
                    double d = Math.sqrt(mc.player.squaredDistanceTo(
                            core.x + 0.5, core.y, core.z + 0.5));
                    dist = " §8(" + (int) d + "m)";
                }
                ctx.drawTextWithShadow(tr, "§6⚑ §fCore: " + where + dist, tx, ty, 0xFFFFFFFF);
                ty += LINE_H + 2;
            }
        }

        ms.popMatrix();
    }

    // ── Draw helpers ───────────────────────────────────────────────────────

    private static void drawPanel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, BG);
        ctx.fill(x, y, x + w, y + 1, ACCENT);
        border(ctx, x, y, w, h, BORDER);
        ctx.fill(x + 2, y + 1, x + w - 2, y + 2, 0x10FFFFFF);
    }

    private static void border(DrawContext ctx, int x, int y, int w, int h, int col) {
        ctx.fill(x,       y,       x + w, y + 1,   col);
        ctx.fill(x,       y + h-1, x + w, y + h,   col);
        ctx.fill(x,       y + 1,   x + 1, y + h-1, col);
        ctx.fill(x + w-1, y + 1,   x + w, y + h-1, col);
    }
}
