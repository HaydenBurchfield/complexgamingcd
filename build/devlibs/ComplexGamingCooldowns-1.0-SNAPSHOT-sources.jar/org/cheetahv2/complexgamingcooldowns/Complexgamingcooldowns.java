package org.cheetahv2.complexgamingcooldowns;

import net.fabricmc.api.ModInitializer;

public class Complexgamingcooldowns implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
