package org.cheetahv2.antigravity.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.cheetahv2.antigravity.client.AntigravityClient;
import org.cheetahv2.antigravity.client.detection.LarkManager;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ViewInvScreen extends Screen {
    private static final int SLOT = 18;

    private final PlayerEntity target;
    private final String targetName;
    private final ItemStack head, chest, legs, feet, mainHand, offHand;
    private ItemStack hoveredStack = ItemStack.EMPTY;

    // Liquid Glass Palette
    private static final int
            GLASS_BG       = 0xD00A0614,
            GLASS_BORDER   = 0x25FFFFFF,
            GLASS_SHEEN    = 0x15FFFFFF,
            GLASS_SHADOW   = 0x40000000,
            SLOT_BG        = 0x30FFFFFF,
            SLOT_BORDER    = 0x10FFFFFF,
            COLOR_BLUE     = 0xFF5AB4FF,
            COLOR_GREEN    = 0xFF4AE87A,
            COLOR_GOLD     = 0xFFFFD060,
            COLOR_RED      = 0xFFE84A6A,
            COLOR_WHITE    = 0xFFFFFFFF;

    public ViewInvScreen(PlayerEntity p) {
        super(Text.literal("viewinv"));
        this.target = p;
        this.targetName = p.getName().getString();
        this.head = p.getInventory().getStack(39).copy();
        this.chest = p.getInventory().getStack(38).copy();
        this.legs = p.getInventory().getStack(37).copy();
        this.feet = p.getInventory().getStack(36).copy();
        this.mainHand = p.getMainHandStack().copy();
        this.offHand = p.getOffHandStack().copy();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int pw() { return 340; }
    private int ph() { return 250; }
    private int px() { return (width - pw()) / 2; }
    private int py() { return (height - ph()) / 2; }

    private void drawGlassPanel(DrawContext ctx, int x, int y, int w, int h) {
        // Base glass dark transparent background
        ctx.fill(x, y, x + w, y + h, GLASS_BG);
        // Clean white glass border
        gborder(ctx, x, y, w, h, GLASS_BORDER);
        // Highlight sheen at top
        ctx.fill(x + 1, y + 1, x + w - 1, y + 2, GLASS_SHEEN);
        // Shadow line at bottom
        ctx.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, GLASS_SHADOW);
    }

    private void drawGlassSlot(DrawContext ctx, int x, int y) {
        // Dark translucent inset
        ctx.fill(x, y, x + SLOT, y + SLOT, 0x40000000);
        // Glassy border
        gborder(ctx, x, y, SLOT, SLOT, SLOT_BORDER);
        // Highlight top-left inset
        ctx.fill(x + 1, y + 1, x + SLOT - 1, y + 2, 0x10FFFFFF);
        ctx.fill(x + 1, y + 1, x + 2, y + SLOT - 1, 0x10FFFFFF);
    }

    private static void gborder(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x, y, x + w, y + 1, col);
        c.fill(x, y + h - 1, x + w, y + h, col);
        c.fill(x, y, x + 1, y + h, col);
        c.fill(x + w - 1, y, x + w, y + h, col);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        int px = px(), py = py(), pw = pw(), ph = ph();
        ctx.fill(0, 0, width, height, 0x70020104); // subtle background dim

        // Main Liquid Glass Dialog Card
        drawGlassPanel(ctx, px, py, pw, ph);

        // Header Slot (Frosted slot)
        ctx.fill(px + 6, py + 6, px + pw - 6, py + 24, 0x30000000);
        gborder(ctx, px + 6, py + 6, pw - 12, 18, 0x10FFFFFF);
        ctx.drawTextWithShadow(textRenderer, "\u2726 CGC \u00A78| \u00A7fViewing: \u00A7b" + targetName, px + 12, py + 11, COLOR_WHITE);

        // Lark Level Gold Badge on top right
        int larkLvl = LarkManager.getLarkLevel(mainHand);
        if (larkLvl > 0) {
            String[] R = {"", "I", "II", "III", "IV", "V"};
            String badge = "\u2694 Lark " + R[Math.min(larkLvl, 5)];
            int bw = textRenderer.getWidth(badge) + 10;
            ctx.fill(px + pw - bw - 12, py + 8, px + pw - 12, py + 22, 0x60002000);
            gborder(ctx, px + pw - bw - 12, py + 8, bw, 14, COLOR_GREEN);
            ctx.drawTextWithShadow(textRenderer, badge, px + pw - bw - 7, py + 11, 0xFF4AE87A);
        }

        int ly = py + 34;
        
        // Target stats info slot (Health & Ping)
        ctx.fill(px + 8, ly, px + pw - 8, ly + 18, 0x20FFFFFF);
        gborder(ctx, px + 8, ly, pw - 16, 18, 0x10FFFFFF);
        
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();
        String hpStr = String.format("\u00A7c\u2764 \u00A7fHealth: \u00A7e%.1f/%.1f", hp, maxHp);
        ctx.drawTextWithShadow(textRenderer, hpStr, px + 14, ly + 5, COLOR_WHITE);
        
        String pingStr = "\u00A79\u23F3 \u00A7fState: " + (target.isDead() ? "\u00A7cDead" : "\u00A7aAlive");
        int tw = textRenderer.getWidth(pingStr);
        ctx.drawTextWithShadow(textRenderer, pingStr, px + pw - tw - 14, ly + 5, COLOR_WHITE);
        
        ly += 24;

        // Section Label
        ctx.drawTextWithShadow(textRenderer, "\u00A78Target Equipment Slots:", px + 8, ly, 0xFF7860A8);
        ly += 11;

        ItemStack[] equip = {head, chest, legs, feet, mainHand, offHand};
        String[] labels = {"Head", "Chest", "Legs", "Feet", "Hand", "Off"};
        int slotY = ly, slotX = px + 8;
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            drawSlot(ctx, textRenderer, mx, my, sx, slotY, equip[i], labels[i]);
            if (!equip[i].isEmpty() && equip[i].isDamageable()) {
                int dur = equip[i].getMaxDamage() - equip[i].getDamage();
                int maxDur = equip[i].getMaxDamage();
                float pct = (float) dur / maxDur;
                int col = pct > 0.6f ? 0xFF4AE87A : pct > 0.3f ? 0xFFFFD060 : 0xFFE84A6A;
                String durStr = dur + "/" + maxDur;
                ctx.drawCenteredTextWithShadow(textRenderer, durStr, sx + SLOT / 2, slotY + SLOT + 10, col);
            }
        }
        ly += SLOT + 22; // was 14, extra 8px for durability line

        // Visual divider
        ctx.fill(px + 8, ly, px + pw - 8, ly + 1, 0x20FFFFFF);
        ly += 6;

        ctx.drawTextWithShadow(textRenderer, "\u00A78Recent Held Items Logs:", px + 8, ly, 0xFF7860A8);
        ly += 11;

        List<ItemStack> hist = AntigravityClient.PLAYER_TRACKER.getHistory(targetName);
        int histX = px + 8;
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            int sx = histX + i * (SLOT + 6);
            if (sx + SLOT > px + pw - 6) break;
            drawSlot(ctx, textRenderer, mx, my, sx, ly, hist.get(i), null);
        }
        if (hist.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, "\u00A78No logs recorded yet.", px + 8, ly + 4, 0xFF7F7F7F);
        }

        // Close instruction footer
        ctx.fill(px + 6, py + ph - 16, px + pw - 6, py + ph - 6, 0x30000000);
        gborder(ctx, px + 6, py + ph - 16, pw - 12, 10, 0x10FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "\u00A78Press ESC key to exit screen", px + pw / 2, py + ph - 15, 0xFF7F7F7F);

        super.render(ctx, mx, my, delta);

        // Tooltip rendering over everything else
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            if (mx >= sx && mx < sx + SLOT && my >= slotY && my < slotY + SLOT && !equip[i].isEmpty()) {
                ctx.drawItemTooltip(textRenderer, equip[i], mx, my);
            }
        }
        int hy2 = py + 34 + 24 + 11 + SLOT + 22 + 6 + 11; // was +14
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            int sx = histX + i * (SLOT + 6);
            if (sx + SLOT > px + pw - 6) break;
            if (mx >= sx && mx < sx + SLOT && my >= hy2 && my < hy2 + SLOT && !hist.get(i).isEmpty()) {
                ctx.drawItemTooltip(textRenderer, hist.get(i), mx, my);
            }
        }

        // Track which item the mouse is over (for Z key inspection)
        hoveredStack = ItemStack.EMPTY;
        for (int i = 0; i < 6; i++) {
            int sx = slotX + i * (SLOT + 6);
            if (mx >= sx && mx < sx + SLOT && my >= slotY && my < slotY + SLOT && !equip[i].isEmpty()) {
                hoveredStack = equip[i];
                break;
            }
        }
        if (hoveredStack.isEmpty()) {
            List<ItemStack> hist2 = AntigravityClient.PLAYER_TRACKER.getHistory(targetName);
            int histX2 = px + 8;
            hy2 = py + 34 + 24 + 11 + SLOT + 22 + 6 + 11; // updated offset (+22 instead of +14)
            for (int i = 0; i < Math.min(10, hist2.size()); i++) {
                int sx = histX2 + i * (SLOT + 6);
                if (sx + SLOT > px + pw - 6) break;
                if (mx >= sx && mx < sx + SLOT && my >= hy2 && my < hy2 + SLOT && !hist2.get(i).isEmpty()) {
                    hoveredStack = hist2.get(i);
                    break;
                }
            }
        }
    }

    private void drawSlot(DrawContext ctx, TextRenderer tr, int mx, int my, int sx, int sy, ItemStack stack, String label) {
        boolean hov = mx >= sx && mx < sx + SLOT && my >= sy && my < sy + SLOT;

        drawGlassSlot(ctx, sx, sy);

        if (hov) {
            ctx.fill(sx + 1, sy + 1, sx + SLOT - 1, sy + SLOT - 1, 0x20FFFFFF);
        }

        if (!stack.isEmpty()) {
            ctx.drawItem(stack, sx + 1, sy + 1);
            ctx.drawStackOverlay(tr, stack, sx + 1, sy + 1, null);
        }
        if (label != null) {
            ctx.drawCenteredTextWithShadow(tr, "\u00A78" + label, sx + SLOT / 2, sy + SLOT + 2, 0xFF888888);
        }
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
            MinecraftClient.getInstance().setScreen(null);
            return true;
        }
        int inspectKey = net.minecraft.client.util.InputUtil
                .fromTranslationKey(AntigravityClient.inspectItemKey.getBoundKeyTranslationKey())
                .getCode();
        if (input.key() == inspectKey && !hoveredStack.isEmpty()) {
            MinecraftClient.getInstance().setScreen(new ItemInspectScreen(hoveredStack));
            return true;
        }
        return super.keyPressed(input);
    }
}
