package org.cheetahv2.antigravity.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.cheetahv2.antigravity.client.AntigravityClient;
import org.cheetahv2.antigravity.client.cooldown.AbilityCooldownManager;
import org.cheetahv2.antigravity.client.cooldown.RuneAvailabilityHud;
import org.lwjgl.glfw.GLFW;

/**
 * HudDragScreen — pauses the game and lets the player drag + scale all HUD elements.
 *
 * Controls:
 *   • Click + drag any ghost box to reposition it.
 *   • Hover a ghost box to reveal [−] and [+] scale buttons (bottom-right corner).
 *   • Click [−] / [+] to decrease / increase that element's scale by 0.1.
 *   • ESC or [L] to close and save.
 *
 * Mouse handling: GLFW-polling pattern to avoid MC 1.21.5 Click-wrapper API.
 */
public class HudDragScreen extends Screen {

    // ── Palette ───────────────────────────────────────────────────────────
    private static final int
        ACCENT     = 0xFF5BAAFF,
        ACCENT2    = 0xFF9F6FFF,
        ACCENT3    = 0xFF55DDAA,
        TEXT_MID   = 0xFFAABBCC,
        TEXT_DIM   = 0xFF556677,
        BORDER_LIT = 0xAABBDDFF,
        BTN_MINUS  = 0xFFFF6666,
        BTN_PLUS   = 0xFF66FF99;

    // ── Ghost box base dimensions (unscaled) ──────────────────────────────
    private static final int LARK_W = 170, LARK_H = 40;
    private static final int ABILITY_W = 160, ABILITY_H = 40;

    // ── Scale button dimensions ───────────────────────────────────────────
    private static final int BTN_W = 14, BTN_H = 11;

    // ── Drag state ────────────────────────────────────────────────────────
    private enum DragTarget { NONE, LARK, ABILITY, RUNE_AVAIL }
    private DragTarget dragging = DragTarget.NONE;
    private int dragOffX, dragOffY;
    private boolean prevLmb = false;

    // Track whether the mouse was on a scale button on click-down (so we don't start drag)
    private boolean clickWasOnScaleBtn = false;

    public HudDragScreen() {
        super(Text.literal("HUD Drag Mode"));
    }

    @Override public boolean shouldPause()       { return true; }
    @Override protected void init()              {}
    @Override public boolean shouldCloseOnEsc()  { return true; }

    // ─────────────────────────────────────────────────────────────────────
    // RENDER
    // ─────────────────────────────────────────────────────────────────────
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {

        long win = MinecraftClient.getInstance().getWindow().getHandle();
        boolean lmb = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        AntigravityClient.HudSettings hs  = AntigravityClient.HUD_SETTINGS;
        AbilityCooldownManager.SavedConfig        cfg = AntigravityClient.ABILITY_COOLDOWN.getConfig();
        RuneAvailabilityHud                       rah = AntigravityClient.RUNE_AVAIL_HUD;

        // ── Compute positions ─────────────────────────────────────────────
        int lx = hs.larkHudX >= 0 ? hs.larkHudX : 10;
        int ly = hs.larkHudY >= 0 ? hs.larkHudY : (height - 50);
        int lW = (int)(LARK_W * hs.larkScale);
        int lH = (int)(LARK_H * hs.larkScale);

        float aSc  = cfg.scale;
        int   aW   = (int)(ABILITY_W * aSc);
        int   aH   = Math.max(ABILITY_H, (int)((16 + Math.max(1,
                        AntigravityClient.ABILITY_COOLDOWN.getActive().size()) * 20) * aSc));
        int   ax   = cfg.consolidatedX;
        int   ay   = cfg.consolidatedY;

        float rSc  = rah.getScale();
        int   rW   = rah.getScaledWidth();
        int   rH   = rah.estimatePanelH();
        int   rx   = rah.getX(width);
        int   ry_  = rah.getY(height);

        // ── Scale buttons: compute rects (bottom-right of each box) ───────
        // Lark scale buttons
        int lBtnY  = ly + lH - BTN_H - 3;
        int lBtnMX = lx + lW - 2*BTN_W - 6;
        int lBtnPX = lx + lW - BTN_W - 3;

        // Ability scale buttons
        int aBtnY  = ay + aH - BTN_H - 3;
        int aBtnMX = ax + aW - 2*BTN_W - 6;
        int aBtnPX = ax + aW - BTN_W - 3;

        // RuneAvail scale buttons
        int rBtnY  = ry_ + rH - BTN_H - 3;
        int rBtnMX = rx  + rW - 2*BTN_W - 6;
        int rBtnPX = rx  + rW - BTN_W  - 3;

        // ── Fresh click → scale buttons OR start drag ─────────────────────
        if (lmb && !prevLmb) {
            clickWasOnScaleBtn = false;

            // Check scale buttons first (priority over drag)
            if (isIn(mx, my, lBtnMX, lBtnY, BTN_W, BTN_H)) {
                hs.larkScale = clampScale(hs.larkScale - 0.1f); hs.save();
                clickWasOnScaleBtn = true;
            } else if (isIn(mx, my, lBtnPX, lBtnY, BTN_W, BTN_H)) {
                hs.larkScale = clampScale(hs.larkScale + 0.1f); hs.save();
                clickWasOnScaleBtn = true;
            } else if (isIn(mx, my, aBtnMX, aBtnY, BTN_W, BTN_H)) {
                cfg.scale = clampScale(cfg.scale - 0.1f);
                AntigravityClient.ABILITY_COOLDOWN.save();
                clickWasOnScaleBtn = true;
            } else if (isIn(mx, my, aBtnPX, aBtnY, BTN_W, BTN_H)) {
                cfg.scale = clampScale(cfg.scale + 0.1f);
                AntigravityClient.ABILITY_COOLDOWN.save();
                clickWasOnScaleBtn = true;
            } else if (isIn(mx, my, rBtnMX, rBtnY, BTN_W, BTN_H)) {
                rah.setScale(rah.getScale() - 0.1f); rah.save();
                clickWasOnScaleBtn = true;
            } else if (isIn(mx, my, rBtnPX, rBtnY, BTN_W, BTN_H)) {
                rah.setScale(rah.getScale() + 0.1f); rah.save();
                clickWasOnScaleBtn = true;
            }

            // Start drag if not a scale button click
            if (!clickWasOnScaleBtn) {
                if (isIn(mx, my, lx, ly, lW, lH)) {
                    dragging = DragTarget.LARK;
                    dragOffX = mx - lx; dragOffY = my - ly;
                } else if (isIn(mx, my, ax, ay, aW, aH)) {
                    dragging = DragTarget.ABILITY;
                    dragOffX = mx - ax; dragOffY = my - ay;
                } else if (isIn(mx, my, rx, ry_, rW, rH)) {
                    dragging = DragTarget.RUNE_AVAIL;
                    dragOffX = mx - rx; dragOffY = my - ry_;
                }
            }
        }

        // ── Held → move ───────────────────────────────────────────────────
        if (lmb && !clickWasOnScaleBtn) {
            if (dragging == DragTarget.LARK) {
                hs.larkHudX = clamp(mx - dragOffX, 0, width  - lW);
                hs.larkHudY = clamp(my - dragOffY, 0, height - lH);
            } else if (dragging == DragTarget.ABILITY) {
                cfg.consolidatedX = clamp(mx - dragOffX, 0, width  - aW);
                cfg.consolidatedY = clamp(my - dragOffY, 0, height - aH);
            } else if (dragging == DragTarget.RUNE_AVAIL) {
                rah.setPos(clamp(mx - dragOffX, 0, width - rW),
                           clamp(my - dragOffY, 0, height - rH));
            }
        } else if (!lmb) {
            // Released → save
            if (dragging == DragTarget.LARK)       { hs.save(); }
            else if (dragging == DragTarget.ABILITY){ AntigravityClient.ABILITY_COOLDOWN.save(); }
            else if (dragging == DragTarget.RUNE_AVAIL) { rah.save(); }
            if (!lmb) { dragging = DragTarget.NONE; clickWasOnScaleBtn = false; }
        }

        prevLmb = lmb;

        // Refresh positions after potential drag update
        lx = hs.larkHudX >= 0 ? hs.larkHudX : 10;
        ly = hs.larkHudY >= 0 ? hs.larkHudY : (height - 50);
        lW = (int)(LARK_W * hs.larkScale);
        lH = (int)(LARK_H * hs.larkScale);
        ax = cfg.consolidatedX; ay = cfg.consolidatedY;
        aW = (int)(ABILITY_W * cfg.scale);
        aH = Math.max(ABILITY_H, (int)((16 + Math.max(1,
                AntigravityClient.ABILITY_COOLDOWN.getActive().size()) * 20) * cfg.scale));
        rx  = rah.getX(width); ry_ = rah.getY(height);
        rW  = rah.getScaledWidth(); rH = rah.estimatePanelH();

        // Recompute button positions after position/size update
        lBtnY  = ly + lH - BTN_H - 3;
        lBtnMX = lx + lW - 2*BTN_W - 6;
        lBtnPX = lx + lW - BTN_W - 3;
        aBtnY  = ay + aH - BTN_H - 3;
        aBtnMX = ax + aW - 2*BTN_W - 6;
        aBtnPX = ax + aW - BTN_W - 3;
        rBtnY  = ry_ + rH - BTN_H - 3;
        rBtnMX = rx  + rW - 2*BTN_W - 6;
        rBtnPX = rx  + rW - BTN_W  - 3;

        // ── Dimmed backdrop ───────────────────────────────────────────────
        ctx.fill(0, 0, width, height, 0x88010308);

        boolean hovLark  = isIn(mx, my, lx, ly, lW, lH);
        boolean hovAbl   = isIn(mx, my, ax, ay, aW, aH);
        boolean hovRune  = isIn(mx, my, rx, ry_, rW, rH);
        boolean dLark    = dragging == DragTarget.LARK;
        boolean dAbl     = dragging == DragTarget.ABILITY;
        boolean dRune    = dragging == DragTarget.RUNE_AVAIL;

        // ── Lark ghost box ────────────────────────────────────────────────
        drawGhostBox(ctx, lx, ly, lW, lH,
                dLark    ? 0x90A060FF : (hovLark ? 0x70204060 : 0x50182838),
                dLark    ? 0xFFCC88FF : (hovLark ? BORDER_LIT : ACCENT),
                "§b✦ Lark  §8" + String.format("%.1fx", hs.larkScale), dLark);
        if (hovLark || dLark) {
            drawScaleButtons(ctx, lBtnMX, lBtnY, mx, my,
                    String.format("%.1f", hs.larkScale));
        }

        // ── Ability Cooldowns ghost box ───────────────────────────────────
        drawGhostBox(ctx, ax, ay, aW, aH,
                dAbl     ? 0x90A060FF : (hovAbl ? 0x70204060 : 0x50182838),
                dAbl     ? 0xFFCC88FF : (hovAbl ? BORDER_LIT : ACCENT2),
                "§d◆ Cooldowns  §8" + String.format("%.1fx", cfg.scale), dAbl);
        if (hovAbl || dAbl) {
            drawScaleButtons(ctx, aBtnMX, aBtnY, mx, my,
                    String.format("%.1f", cfg.scale));
        }

        // ── Rune Availability ghost box ───────────────────────────────────
        drawGhostBox(ctx, rx, ry_, rW, rH,
                dRune    ? 0x90A060FF : (hovRune ? 0x70204060 : 0x50182838),
                dRune    ? 0xFFCC88FF : (hovRune ? BORDER_LIT : ACCENT3),
                "§a✦ Rune Avail  §8" + String.format("%.1fx", rah.getScale()), dRune);
        if (hovRune || dRune) {
            drawScaleButtons(ctx, rBtnMX, rBtnY, mx, my,
                    String.format("%.1f", rah.getScale()));
        }

        // ── Instructions banner ───────────────────────────────────────────
        int bw = 430, bh = 28;
        int bx = (width - bw) / 2, by = height - 36;
        ctx.fill(bx, by, bx + bw, by + bh, 0xCC07050F);
        gborder(ctx, bx, by, bw, bh, ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§b[L]§8/§bESC §7exit  §8•  §7Drag boxes  §8•  §7Hover box → §f[−] [+] §7to scale",
                width / 2, by + (bh - 7) / 2, TEXT_MID);

        // ── Coord readout ─────────────────────────────────────────────────
        String coords = "§8Lark §fX=" + lx + " Y=" + ly
                + "  §8CD §fX=" + ax + " Y=" + ay
                + "  §8Runes §fX=" + rx + " Y=" + ry_;
        int ctw = textRenderer.getWidth(coords);
        ctx.fill(width / 2 - ctw / 2 - 6, 6, width / 2 + ctw / 2 + 6, 19, 0xAA07050F);
        ctx.drawTextWithShadow(textRenderer, coords, width / 2 - ctw / 2, 10, TEXT_DIM);

        super.render(ctx, mx, my, delta);
    }

    // ─────────────────────────────────────────────────────────────────────
    // KEYBOARD
    // ─────────────────────────────────────────────────────────────────────
    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_L) {
            onClose(); return true;
        }
        return super.keyPressed(input);
    }

    public void onClose() {
        AntigravityClient.HUD_SETTINGS.save();
        AntigravityClient.ABILITY_COOLDOWN.save();
        AntigravityClient.RUNE_AVAIL_HUD.save();
        AntigravityClient.larkDragModeActive = false;
        MinecraftClient.getInstance().setScreen(null);
    }

    // ─────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────

    private boolean isIn(int px, int py, int bx, int by, int bw, int bh) {
        return px >= bx && px < bx + bw && py >= by && py < by + bh;
    }

    private int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private float clampScale(float s) { return Math.max(0.4f, Math.min(3.0f, Math.round(s * 10) / 10.0f)); }

    /** Draw a ghost box with corner dots and centred label. */
    private void drawGhostBox(DrawContext ctx, int x, int y, int w, int h,
                               int bg, int brd, String label, boolean dragging) {
        ctx.fill(x, y, x + w, y + h, bg);
        gborder(ctx, x, y, w, h, brd);
        ctx.fill(x + 2, y + 1, x + w - 2, y + 2, 0x18FFFFFF);

        int lw = textRenderer.getWidth(label);
        ctx.drawTextWithShadow(textRenderer, label,
                x + (w - lw) / 2, y + (h - 7) / 2, 0xFFFFFFFF);

        int ds = 4;
        int dot = dragging ? 0xFFCC88FF : (brd | 0xCC000000);
        ctx.fill(x + 2,     y + 2,     x + 2 + ds, y + 2 + ds, dot);
        ctx.fill(x + w - 6, y + 2,     x + w - 2,  y + 2 + ds, dot);
        ctx.fill(x + 2,     y + h - 6, x + 2 + ds, y + h - 2,  dot);
        ctx.fill(x + w - 6, y + h - 6, x + w - 2,  y + h - 2,  dot);
    }

    /**
     * Draw [−] [+] scale buttons at (btnMX, btnY) and (btnMX+BTN_W+2, btnY).
     * btnjPX = btnMX + BTN_W + 2.
     * mx/my is current mouse position so we can highlight on hover.
     */
    private void drawScaleButtons(DrawContext ctx, int btnMX, int btnY, int mx, int my, String scaleLabel) {
        int btnPX = btnMX + BTN_W + 2;

        boolean hovM = isIn(mx, my, btnMX, btnY, BTN_W, BTN_H);
        boolean hovP = isIn(mx, my, btnPX, btnY, BTN_W, BTN_H);

        // [−] button
        ctx.fill(btnMX, btnY, btnMX + BTN_W, btnY + BTN_H,
                hovM ? 0xDDFF3333 : 0xBB882222);
        gborder(ctx, btnMX, btnY, BTN_W, BTN_H, hovM ? BTN_MINUS : 0xBBFF6666);
        int mw = textRenderer.getWidth("−");
        ctx.drawTextWithShadow(textRenderer, "−",
                btnMX + (BTN_W - mw) / 2, btnY + (BTN_H - 7) / 2, 0xFFFFDDDD);

        // [+] button
        ctx.fill(btnPX, btnY, btnPX + BTN_W, btnY + BTN_H,
                hovP ? 0xDD33FF66 : 0xBB228833);
        gborder(ctx, btnPX, btnY, BTN_W, BTN_H, hovP ? BTN_PLUS : 0xBB66FF99);
        int pw = textRenderer.getWidth("+");
        ctx.drawTextWithShadow(textRenderer, "+",
                btnPX + (BTN_W - pw) / 2, btnY + (BTN_H - 7) / 2, 0xFFDDFFDD);

        // Scale label above buttons
        int lw = textRenderer.getWidth(scaleLabel);
        ctx.drawTextWithShadow(textRenderer, "§7" + scaleLabel,
                btnMX + (2*BTN_W + 2 - lw) / 2, btnY - 9, 0xFFCCCCCC);
    }

    private void gborder(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x,         y,         x + w, y + 1,     col);
        c.fill(x,         y + h - 1, x + w, y + h,     col);
        c.fill(x,         y,         x + 1, y + h,     col);
        c.fill(x + w - 1, y,         x + w, y + h,     col);
    }
}
