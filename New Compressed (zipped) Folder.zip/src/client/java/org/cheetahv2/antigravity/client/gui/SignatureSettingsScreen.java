package org.cheetahv2.antigravity.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.cheetahv2.antigravity.client.util.SignatureManager;
import org.lwjgl.glfw.GLFW;

/**
 * In-game screen for editing the /sign signature.
 *
 * Open it with the /signsettings client command:
 *
 *   ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
 *       dispatcher.register(ClientCommandManager.literal("signsettings")
 *           .executes(ctx -> {
 *               MinecraftClient.getInstance().send(() ->
 *                   MinecraftClient.getInstance().setScreen(new SignatureSettingsScreen()));
 *               return 1;
 *           })));
 *
 * The screen is also navigable from any other CGC settings screen.
 */
public class SignatureSettingsScreen extends Screen {

    // ── layout constants ─────────────────────────────────────────────────
    private static final int PW = 380;
    private static final int PH = 200;

    // Liquid Glass palette — matches ViewInvScreen / FrozenPlayerTracker
    private static final int
            GLASS_BG     = 0xD00A0614,
            GLASS_BORDER = 0x25FFFFFF,
            GLASS_SHEEN  = 0x15FFFFFF,
            GLASS_SHADOW = 0x40000000,
            COLOR_BLUE   = 0xFF5AB4FF,
            COLOR_GREEN  = 0xFF4AE87A,
            COLOR_WHITE  = 0xFFFFFFFF,
            COLOR_GREY   = 0xFF888888;

    // ── widgets ───────────────────────────────────────────────────────────
    private TextFieldWidget signatureField;
    private ButtonWidget    saveButton;
    private ButtonWidget    resetButton;
    private ButtonWidget    closeButton;

    /** Preview of what /sign would actually send (first 80 chars of the command). */
    private String previewText = "";

    public SignatureSettingsScreen() {
        super(Text.literal("CGC — Signature Settings"));
    }

    @Override
    public boolean shouldPause() { return false; }

    // ── helpers ───────────────────────────────────────────────────────────

    private int px() { return (width  - PW) / 2; }
    private int py() { return (height - PH) / 2; }

    private void drawGlassPanel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, GLASS_BG);
        gborder(ctx, x, y, w, h, GLASS_BORDER);
        ctx.fill(x + 1, y + 1, x + w - 1, y + 2,     GLASS_SHEEN);
        ctx.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, GLASS_SHADOW);
    }

    private static void gborder(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x,         y,         x + w,     y + 1,     col);
        c.fill(x,         y + h - 1, x + w,     y + h,     col);
        c.fill(x,         y,         x + 1,     y + h,     col);
        c.fill(x + w - 1, y,         x + w,     y + h,     col);
    }

    // ── lifecycle ─────────────────────────────────────────────────────────

    @Override
    protected void init() {
        int x = px(), y = py();

        // ── Signature text field ──────────────────────────────────────────
        // Positioned below the title header, full panel width with padding.
        signatureField = new TextFieldWidget(
                textRenderer,
                x + 10, y + 48,
                PW - 20, 20,
                Text.literal("Signature command"));
        signatureField.setMaxLength(512);
        signatureField.setText(SignatureManager.getSignature());
        signatureField.setChangedListener(this::onFieldChanged);
        signatureField.setPlaceholder(Text.literal("e.g. sll 1 &#FFBCE2 ☆ ...").formatted(net.minecraft.util.Formatting.DARK_GRAY));
        addDrawableChild(signatureField);

        onFieldChanged(signatureField.getText()); // seed preview

        // ── Buttons ───────────────────────────────────────────────────────
        int btnY  = y + PH - 40;
        int btnW  = 90;
        int btnH  = 20;
        int gap   = 8;
        // Centre the three buttons
        int totalW = btnW * 3 + gap * 2;
        int btnX  = x + (PW - totalW) / 2;

        saveButton = ButtonWidget.builder(
                Text.literal("✔ Save"),
                b -> onSave()
        ).dimensions(btnX, btnY, btnW, btnH).build();
        addDrawableChild(saveButton);

        resetButton = ButtonWidget.builder(
                Text.literal("↺ Reset"),
                b -> onReset()
        ).dimensions(btnX + btnW + gap, btnY, btnW, btnH).build();
        addDrawableChild(resetButton);

        closeButton = ButtonWidget.builder(
                Text.literal("✕ Close"),
                b -> onClose()
        ).dimensions(btnX + (btnW + gap) * 2, btnY, btnW, btnH).build();
        addDrawableChild(closeButton);
    }

    /** Called whenever the text field changes — updates live preview. */
    private void onFieldChanged(String text) {
        if (text == null || text.isBlank()) {
            previewText = "§8(empty — will use default on save)";
        } else {
            // Show the first ~60 chars of the command for a quick sanity check
            String display = text.length() > 60 ? text.substring(0, 57) + "…" : text;
            previewText = "§7/" + display;
        }
    }

    private void onSave() {
        String value = signatureField.getText().strip();
        SignatureManager.setSignature(value.isEmpty() ? null : value);
        // Brief flash — button label temporarily changes
        saveButton.setMessage(Text.literal("§a✔ Saved!"));
        // Re-seed in case it was blank and got default
        signatureField.setText(SignatureManager.getSignature());
        onFieldChanged(signatureField.getText());
    }

    private void onReset() {
        signatureField.setText(SignatureManager.getDefaultSignature());
        onFieldChanged(signatureField.getText());
        resetButton.setMessage(Text.literal("§e↺ Reset!"));
    }

    public void onClose() {
        MinecraftClient.getInstance().setScreen(null);
    }

    // ── rendering ─────────────────────────────────────────────────────────

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Dim backdrop
        ctx.fill(0, 0, width, height, 0x70020104);

        int x = px(), y = py();

        // Glass card
        drawGlassPanel(ctx, x, y, PW, PH);

        // ── Header bar ────────────────────────────────────────────────────
        ctx.fill(x + 6, y + 6, x + PW - 6, y + 24, 0x30000000);
        gborder(ctx, x + 6, y + 6, PW - 12, 18, 0x10FFFFFF);
        ctx.drawTextWithShadow(textRenderer,
                "✦ CGC §8| §fSignature Settings",
                x + 12, y + 11, COLOR_WHITE);

        // ── Field label ───────────────────────────────────────────────────
        ctx.drawTextWithShadow(textRenderer,
                "§8Command sent by §f/sign§8:",
                x + 10, y + 38, COLOR_GREY);

        // ── Hint ──────────────────────────────────────────────────────────
        ctx.drawTextWithShadow(textRenderer,
                "§8Tip: paste your full §f/sll§8 or §f/sign§8 command here.",
                x + 10, y + 76, COLOR_GREY);

        // ── Live preview ──────────────────────────────────────────────────
        ctx.drawTextWithShadow(textRenderer,
                "§8Preview:",
                x + 10, y + 94, COLOR_GREY);
        ctx.drawTextWithShadow(textRenderer,
                previewText,
                x + 10, y + 106, COLOR_BLUE);

        // ── Divider ───────────────────────────────────────────────────────
        ctx.fill(x + 8, y + 120, x + PW - 8, y + 121, 0x20FFFFFF);

        // ── Keybind hint ──────────────────────────────────────────────────
        ctx.fill(x + 6, y + PH - 16, x + PW - 6, y + PH - 6, 0x30000000);
        gborder(ctx, x + 6, y + PH - 16, PW - 12, 10, 0x10FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§8Press ESC to close without saving",
                x + PW / 2, y + PH - 15, COLOR_GREY);

        // Draw widgets on top
        super.render(ctx, mx, my, delta);
    }

    // ── keyboard ──────────────────────────────────────────────────────────

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        if (input.key() == GLFW.GLFW_KEY_ENTER || input.key() == GLFW.GLFW_KEY_KP_ENTER) {
            onSave();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}