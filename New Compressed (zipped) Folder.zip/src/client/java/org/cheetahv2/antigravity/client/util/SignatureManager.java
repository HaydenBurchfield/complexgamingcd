package org.cheetahv2.antigravity.client.util;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Persists a single "signature" string used by the /sign client command.
 * Stored in config/antigravity/signature.json.
 *
 * Usage:
 *   SignatureManager.load();           // call once during mod init
 *   SignatureManager.getSignature();   // returns the saved command string
 *   SignatureManager.setSignature(s);  // saves immediately to disk
 */
public class SignatureManager {

    private static final Path FILE =
            Paths.get("config", "antigravity", "signature.json");

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Default signature — the original hardcoded value. */
    private static final String DEFAULT_SIGNATURE =
            "sll 1 &#FFBCE2 ☆ &#FEC7DDᴄ&#FDCCDAʜ&#FDD2D8ᴇ&#FCD7D5ᴇ&#FCDDD3ᴛ&#FBE2D0ᴀ&#FBE8CEʜ&#FAEDCBᴠ&#F7E9CF² &#F0E2D7&lX&#ECDFDB&lX &7(&#E2D4E8+&#DED1EC3&7)";

    // ── in-memory state ───────────────────────────────────────────────────
    private static String signature = DEFAULT_SIGNATURE;

    // ── serialization holder ──────────────────────────────────────────────
    private static class SavedSignature {
        public String value = DEFAULT_SIGNATURE;
    }

    // ── public API ────────────────────────────────────────────────────────

    public static String getSignature() {
        return signature;
    }

    public static void setSignature(String value) {
        signature = (value == null || value.isBlank()) ? DEFAULT_SIGNATURE : value.strip();
        save();
    }

    public static String getDefaultSignature() {
        return DEFAULT_SIGNATURE;
    }

    // ── persistence ───────────────────────────────────────────────────────

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            SavedSignature s = GSON.fromJson(Files.readString(FILE), SavedSignature.class);
            if (s != null && s.value != null && !s.value.isBlank()) {
                signature = s.value;
            }
        } catch (IOException e) {
            System.err.println("[CGC] Failed to load signature: " + e.getMessage());
        }
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            SavedSignature holder = new SavedSignature();
            holder.value = signature;
            Files.writeString(FILE, GSON.toJson(holder));
        } catch (IOException e) {
            System.err.println("[CGC] Failed to save signature: " + e.getMessage());
        }
    }
}