package org.cheetahv2.antigravity.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.cheetahv2.antigravity.client.cooldown.AbilityCooldownManager;
import org.cheetahv2.antigravity.client.utility.AutoCookieModule;
import org.cheetahv2.antigravity.client.utility.AutoJackOfHeartsModule;
import org.cheetahv2.antigravity.client.utility.AutoSacredShieldModule;
import org.cheetahv2.antigravity.client.utility.AutoTropicalShieldModule;
import org.cheetahv2.antigravity.client.utility.UtilityModule;
import org.cheetahv2.antigravity.client.utility.UtilityModuleManager;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * CGC Settings Screen — /ccsettings
 *
 * Two tabs: HUD | Cooldowns
 * All buttons are custom-drawn (no ButtonWidget) — fully GLFW-polled.
 */
public class AntigravityClient extends Screen {

    // ── Palette ───────────────────────────────────────────────────────────
    private static final int
        BG          = 0xEA07050F,   // deep navy/purple base
        PANEL       = 0x55101830,   // section panel
        PANEL_LIT   = 0x7018243C,   // hovered panel
        BORDER      = 0x40AABBDD,   // subtle blue border
        BORDER_LIT  = 0xAABBDDFF,   // bright on hover
        ACCENT      = 0xFF5BAAFF,   // blue accent
        ACCENT2     = 0xFF9F6FFF,   // purple accent
        TEXT_HI     = 0xFFEEF4FF,   // bright text
        TEXT_MID    = 0xFFAABBCC,   // mid text
        TEXT_DIM    = 0xFF556677,   // dim text
        GREEN       = 0xFF3DDA6E,
        GREEN_DIM   = 0x3033AA55,
        RED         = 0xFFDD4444,
        RED_DIM     = 0x30AA2222,
        YELLOW      = 0xFFFFCC44,
        TAB_ACTIVE  = 0xFF1A2E4A,
        TAB_IDLE    = 0x00000000,
        DRAG_IDLE   = 0x30182838,
        DRAG_HOV    = 0x508090B0,
        DRAG_ACTIVE = 0x70A060FF;

    // ── Layout ────────────────────────────────────────────────────────────
    private static final int PW = 460, PH = 370;
    private static final int TAB_H = 20;
    private static final int HDR_H = 26;
    private static final int CONTENT_TOP = HDR_H + TAB_H + 2; // y offset inside panel

    private int px() { return (width  - PW) / 2; }
    private int py() { return (height - PH) / 2; }

    // ── Tabs ──────────────────────────────────────────────────────────────
    private int activeTab = 0;
    private static final String[] TABS = { "\u25A3  HUD", "\u25CE  Cooldowns", "\u2699  Utility" };

    // ── GLFW mouse state ──────────────────────────────────────────────────
    private boolean prevLmb = false;
    private double  gx, gy; // cursor in gui-pixels (updated every render)

    // ── Drag handle ───────────────────────────────────────────────────────
    private boolean dragging = false;
    private int dragOffX, dragOffY;

    // ── Custom button registry ────────────────────────────────────────────
    // Each entry: { x, y, w, h, tag }  — tag is an opaque int we switch on
    private static final class Btn {
        int x, y, w, h, tag;
        String label;
        boolean toggled; // visual state
        Btn(int x, int y, int w, int h, int tag, String label) {
            this.x=x; this.y=y; this.w=w; this.h=h; this.tag=tag; this.label=label;
        }
    }
    private final List<Btn> buttons = new ArrayList<>();

    // ── Button tags ───────────────────────────────────────────────────────
    // HUD tab
    private static final int
        BTN_CLOSE           = 0,
        BTN_TAB_0           = 10,
        BTN_TAB_1           = 11,
        BTN_STATUS_TOGGLE   = 20,
        BTN_CRATE_TOGGLE    = 21,
        BTN_EVENT_HUD_TOGGLE = 22,
        BTN_LARK_SCALE_DN   = 30,
        BTN_LARK_SCALE_UP   = 31,
        BTN_LARK_HEIGHT_DN  = 32,
        BTN_LARK_HEIGHT_UP  = 33,
        BTN_GLOW_SCALE_DN   = 34,
        BTN_GLOW_SCALE_UP   = 35,
        BTN_LARK_RESET_POS  = 36,
        // Cooldowns tab
        BTN_SCALE_DN        = 50,
        BTN_SCALE_UP        = 51,
        BTN_LAYOUT          = 52,
        BTN_RESET_POS       = 53,
        BTN_NUDGE_L         = 54,
        BTN_NUDGE_R         = 55,
        BTN_NUDGE_U         = 56,
        BTN_NUDGE_D         = 57,
        // ability toggles start at 100 + index
        BTN_ABILITY_BASE    = 100;

    // Utility tab button tags — base 200
    private static final int
        BTN_TAB_2                   = 12,
        BTN_UTIL_BASE               = 200,   // 200 + moduleIndex = module enable toggle
        // Cookie settings     (module index 0)
        BTN_COOKIE_DELAY_DN         = 210,
        BTN_COOKIE_DELAY_UP         = 211,
        BTN_COOKIE_CD_DN            = 212,
        BTN_COOKIE_CD_UP            = 213,
        // Jack of Hearts settings (module index 1)
        BTN_JACK_DELAY_DN           = 214,
        BTN_JACK_DELAY_UP           = 215,
        BTN_JACK_CD_DN              = 216,
        BTN_JACK_CD_UP              = 217,
        // Sacred shield settings  (module index 2)
        BTN_SACRED_HP_DN            = 220,
        BTN_SACRED_HP_UP            = 221,
        // Tropical shield settings (module index 3)
        BTN_TROPICAL_HP_DN          = 230,
        BTN_TROPICAL_HP_UP          = 231,
        // Totem settings          (module index 4) — no extra steppers needed
        BTN_TOTEM_DUMMY             = 240;

    public AntigravityClient() {
        super(Text.literal("CGC Settings"));
    }

    @Override public boolean shouldPause() { return false; }

    // ─────────────────────────────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────────────────────────────
    @Override
    protected void init() {
        // no Minecraft widgets needed — all custom
    }

    // ─────────────────────────────────────────────────────────────────────
    // DRAW HELPERS
    // ─────────────────────────────────────────────────────────────────────

    /** Filled rectangle */
    private static void fill(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x, y, x + w, y + h, col);
    }

    /** 1-px border */
    private static void border(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x,         y,         x+w,   y+1,   col);
        c.fill(x,         y+h-1,     x+w,   y+h,   col);
        c.fill(x,         y+1,       x+1,   y+h-1, col);
        c.fill(x+w-1,     y+1,       x+w,   y+h-1, col);
    }

    /** Top sheen highlight (glass look) */
    private static void sheen(DrawContext c, int x, int y, int w) {
        c.fill(x+2, y+1, x+w-2, y+2, 0x18FFFFFF);
    }

    /**
     * Custom button: dark glass pill.
     * Returns true if the cursor is hovering.
     */
    private boolean drawBtn(DrawContext ctx, Btn b, boolean pressed) {
        boolean hov = gx >= b.x && gx < b.x+b.w && gy >= b.y && gy < b.y+b.h;
        int bg  = pressed ? 0x60305070 : hov ? 0x50203550 : 0x30101828;
        int brd = pressed ? BORDER_LIT  : hov ? ACCENT      : BORDER;
        fill(ctx, b.x, b.y, b.w, b.h, bg);
        border(ctx, b.x, b.y, b.w, b.h, brd);
        sheen(ctx, b.x, b.y, b.w);
        if (!b.label.isEmpty()) {
            int tw = textRenderer.getWidth(b.label);
            ctx.drawTextWithShadow(textRenderer, b.label,
                    b.x + (b.w - tw) / 2, b.y + (b.h - 7) / 2, hov ? TEXT_HI : TEXT_MID);
        }
        return hov;
    }

    /** Toggle button (ON/OFF style) */
    private void drawToggleBtn(DrawContext ctx, Btn b, boolean on) {
        boolean hov = gx >= b.x && gx < b.x+b.w && gy >= b.y && gy < b.y+b.h;
        int bg  = on  ? (hov ? 0x80206030 : GREEN_DIM)
                      : (hov ? 0x80602020 : RED_DIM);
        int brd = on  ? (hov ? 0xFF55EE88 : GREEN) : (hov ? 0xFFEE5555 : RED);
        fill(ctx, b.x, b.y, b.w, b.h, bg);
        border(ctx, b.x, b.y, b.w, b.h, brd);
        sheen(ctx, b.x, b.y, b.w);
        String lbl = on ? "\u00A7aON" : "\u00A7cOFF";
        int tw = textRenderer.getWidth(lbl);
        ctx.drawTextWithShadow(textRenderer, lbl, b.x + (b.w - tw)/2, b.y + (b.h - 7)/2, 0xFFFFFFFF);
    }

    /** Small +/- stepper button */
    private void drawStepBtn(DrawContext ctx, Btn b, boolean isPlus) {
        boolean hov = gx >= b.x && gx < b.x+b.w && gy >= b.y && gy < b.y+b.h;
        int col = isPlus ? (hov ? 0xFF55EE88 : 0xFF33AA55) : (hov ? 0xFFEE6655 : 0xFFAA3333);
        fill(ctx, b.x, b.y, b.w, b.h, hov ? 0x40FFFFFF : 0x20FFFFFF);
        border(ctx, b.x, b.y, b.w, b.h, col);
        String sym = isPlus ? "\u002B" : "\u2212";
        int tw = textRenderer.getWidth(sym);
        ctx.drawTextWithShadow(textRenderer, sym, b.x+(b.w-tw)/2, b.y+(b.h-7)/2, col);
    }

    /** Section header label */
    private void sectionLabel(DrawContext ctx, String text, int x, int y) {
        fill(ctx, x, y, PW - 20, 1, 0x30AABBDD);
        ctx.drawTextWithShadow(textRenderer, text, x + 2, y - 8, ACCENT);
    }

    // ─────────────────────────────────────────────────────────────────────
    // RENDER  (everything lives here — no init widgets)
    // ─────────────────────────────────────────────────────────────────────
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        pollGlfw();  // update gx/gy, handle clicks & drag

        buttons.clear();

        int x = px(), y = py();
        org.cheetahv2.antigravity.client.AntigravityClient.HudSettings hs = org.cheetahv2.antigravity.client.AntigravityClient.HUD_SETTINGS;
        AbilityCooldownManager acm = org.cheetahv2.antigravity.client.AntigravityClient.ABILITY_COOLDOWN;
        AbilityCooldownManager.SavedConfig cfg = acm.getConfig();

        // ── Backdrop ──────────────────────────────────────────────────────
        fill(ctx, 0, 0, width, height, 0x88010308);

        // ── Main card ─────────────────────────────────────────────────────
        fill(ctx, x, y, PW, PH, BG);
        // top accent stripe
        fill(ctx, x, y, PW, 2, ACCENT);
        fill(ctx, x, y+2, PW, 1, 0x30AACCFF);
        border(ctx, x, y, PW, PH, BORDER);
        sheen(ctx, x, y, PW);
        // subtle inner shadow at bottom
        fill(ctx, x+1, y+PH-3, PW-2, 2, 0x30000000);

        // ── Header ────────────────────────────────────────────────────────
        fill(ctx, x, y+2, PW, HDR_H-2, 0x20101828);
        // logo mark
        ctx.drawTextWithShadow(textRenderer, "\u25C6", x+10, y+9, ACCENT2);
        ctx.drawTextWithShadow(textRenderer, "CGC", x+22, y+9, TEXT_HI);
        ctx.drawTextWithShadow(textRenderer, "\u00A78\u2502\u00A7r Settings", x+42, y+9, TEXT_MID);
        // close button
        registerAndDraw(ctx, new Btn(x+PW-20, y+7, 13, 13, BTN_CLOSE, "\u00D7"), false);

        // ── Tabs ──────────────────────────────────────────────────────────
        int tabY = y + HDR_H;
        int tabW = PW / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            boolean active = i == activeTab;
            int tx = x + i * tabW;
            fill(ctx, tx, tabY, tabW, TAB_H, active ? TAB_ACTIVE : TAB_IDLE);
            if (active) {
                fill(ctx, tx, tabY, tabW, 1, ACCENT);        // top line
                fill(ctx, tx, tabY+TAB_H-1, tabW, 1, BG);   // merge with content
            } else {
                fill(ctx, tx, tabY+TAB_H-1, tabW, 1, BORDER);
            }
            boolean hovTab = gx >= tx && gx < tx+tabW && gy >= tabY && gy < tabY+TAB_H;
            int tw = textRenderer.getWidth(TABS[i]);
            ctx.drawTextWithShadow(textRenderer, TABS[i],
                    tx + (tabW - tw)/2, tabY + (TAB_H - 7)/2,
                    active ? ACCENT : (hovTab ? TEXT_MID : TEXT_DIM));
            registerBtn(tx, tabY, tabW, TAB_H, BTN_TAB_0 + i, "");
        }
        // right border of tab area
        border(ctx, x, tabY, PW, TAB_H, 0x20AABBDD);

        // ── Content area ──────────────────────────────────────────────────
        int cy = y + CONTENT_TOP + 6;

        if (activeTab == 0) renderHudTab(ctx, x, cy, hs);
        else if (activeTab == 1) renderCooldownsTab(ctx, x, cy, cfg, acm);
        else                renderUtilityTab(ctx, x, cy);

        // ── Footer ────────────────────────────────────────────────────────
        fill(ctx, x+1, y+PH-16, PW-2, 15, 0x20000000);
        fill(ctx, x+1, y+PH-16, PW-2, 1, 0x20AABBDD);
        ctx.drawCenteredTextWithShadow(textRenderer,
                "\u00A78ESC to close  \u2022  Changes save automatically",
                x + PW/2, y + PH - 11, TEXT_DIM);
    }

    // ─────────────────────────────────────────────────────────────────────
    // TAB 0 — HUD
    // ─────────────────────────────────────────────────────────────────────
    private void renderHudTab(DrawContext ctx, int x, int cy,
                              org.cheetahv2.antigravity.client.AntigravityClient.HudSettings hs) {

        // ── Visibility toggles ────────────────────────────────────────────
        sectionLabel(ctx, "VISIBILITY", x + 10, cy);
        cy += 10;

        drawRow(ctx, x + 10, cy, "Status Bar HUD",
                new Btn(x + PW - 80, cy - 3, 62, 16, BTN_STATUS_TOGGLE, ""), hs.showStatusBar);
        cy += 22;
        drawRow(ctx, x + 10, cy, "Crate Puller Overlay",
                new Btn(x + PW - 80, cy - 3, 62, 16, BTN_CRATE_TOGGLE, ""), hs.showCratePuller);
        cy += 22;
        drawRow(ctx, x + 10, cy, "Event Schedule HUD",
                new Btn(x + PW - 80, cy - 3, 62, 16, BTN_EVENT_HUD_TOGGLE, ""),
                org.cheetahv2.antigravity.client.AntigravityClient.EVENT_SCHEDULE.isHudEnabled());
        cy += 30;

        // ── Scale controls ────────────────────────────────────────────────
        sectionLabel(ctx, "LABEL SCALES", x + 10, cy);
        cy += 12;

        drawStepper(ctx, x + 10, cy, "Lark Label Scale",
                String.format("%.1f", hs.larkLabelScale),
                new Btn(x+180, cy, 18, 14, BTN_LARK_SCALE_DN, ""),
                new Btn(x+202, cy, 18, 14, BTN_LARK_SCALE_UP, ""));
        cy += 20;

        drawStepper(ctx, x + 10, cy, "Lark Height Offset",
                String.format("%.2f", hs.labelHeightOffset),
                new Btn(x+180, cy, 18, 14, BTN_LARK_HEIGHT_DN, ""),
                new Btn(x+202, cy, 18, 14, BTN_LARK_HEIGHT_UP, ""));
        cy += 20;

        drawStepper(ctx, x + 10, cy, "Glow Label Scale",
                String.format("%.1f", hs.labelScale),
                new Btn(x+180, cy, 18, 14, BTN_GLOW_SCALE_DN, ""),
                new Btn(x+202, cy, 18, 14, BTN_GLOW_SCALE_UP, ""));
        cy += 28;

        // ── Position ──────────────────────────────────────────────────────
        sectionLabel(ctx, "LARK HUD POSITION", x + 10, cy);
        cy += 14;

        // Coord display badge
        String coordStr = "§8X=§f" + hs.larkHudX + "  §8Y=§f" + hs.larkHudY;
        int coordW = textRenderer.getWidth(coordStr) + 16;
        fill(ctx, x + 10, cy - 3, coordW, 17, PANEL);
        border(ctx, x + 10, cy - 3, coordW, 17, BORDER);
        ctx.drawTextWithShadow(textRenderer, coordStr, x + 18, cy + 1, TEXT_MID);

        Btn resetLark = new Btn(x + PW - 120, cy - 3, 102, 16, BTN_LARK_RESET_POS, "Reset Position");
        registerAndDraw(ctx, resetLark, false);
        cy += 26;

        // Drag-mode status pill
        boolean dragActive = org.cheetahv2.antigravity.client.AntigravityClient.larkDragModeActive;
        int pillBg  = dragActive ? 0x7020603A : 0x30182838;
        int pillBrd = dragActive ? 0xFF3DDA6E  : BORDER;
        fill(ctx, x + 10, cy - 2, PW - 20, 18, pillBg);
        border(ctx, x + 10, cy - 2, PW - 20, 18, pillBrd);
        String dragTip = "§8✦ Press §7[L] §8in-game to open HUD drag mode (pauses game)";
        ctx.drawTextWithShadow(textRenderer, dragTip, x + 18, cy + 2, TEXT_DIM);
        cy += 24;

        ctx.drawTextWithShadow(textRenderer,
                "§8↳ Drag both Lark and Ability Cooldown boxes freely",
                x + 10, cy, TEXT_DIM);
    }

    /** Label + value + two stepper buttons on one row */
    private void drawStepper(DrawContext ctx, int x, int y,
                              String label, String value,
                              Btn btnDn, Btn btnUp) {
        ctx.drawTextWithShadow(textRenderer, label, x, y + 3, TEXT_MID);
        // value badge
        int vw = textRenderer.getWidth(value) + 10;
        fill(ctx, x + 148, y - 1, vw, 15, PANEL);
        border(ctx, x + 148, y - 1, vw, 15, BORDER);
        ctx.drawTextWithShadow(textRenderer, value, x + 153, y + 3, ACCENT);
        // stepper buttons
        drawStepBtn(ctx, btnDn, false);
        drawStepBtn(ctx, btnUp, true);
        buttons.add(btnDn);
        buttons.add(btnUp);
    }

    /** Label + toggle button on one row */
    private void drawRow(DrawContext ctx, int x, int y, String label, Btn btn, boolean on) {
        ctx.drawTextWithShadow(textRenderer, label, x, y + 4, TEXT_MID);
        drawToggleBtn(ctx, btn, on);
        buttons.add(btn);
    }

    // ─────────────────────────────────────────────────────────────────────
    // TAB 1 — COOLDOWNS
    // ─────────────────────────────────────────────────────────────────────
    private void renderCooldownsTab(DrawContext ctx, int x, int cy,
                                    AbilityCooldownManager.SavedConfig cfg,
                                    AbilityCooldownManager acm) {

        // ── Scale + Layout ────────────────────────────────────────────────
        sectionLabel(ctx, "HUD DISPLAY", x + 10, cy);
        cy += 12;

        // Scale stepper
        drawStepper(ctx, x + 10, cy, "HUD Scale",
                String.format("%.1f", cfg.scale),
                new Btn(x+180, cy, 18, 14, BTN_SCALE_DN, ""),
                new Btn(x+202, cy, 18, 14, BTN_SCALE_UP, ""));

        // Layout toggle button (right side)
        String layoutLabel = cfg.layoutMode == AbilityCooldownManager.LayoutMode.CONSOLIDATED
                ? "\u00A7bConsolidated" : "\u00A7eIndividual";
        Btn btnLayout = new Btn(x + PW - 120, cy - 3, 102, 16, BTN_LAYOUT, layoutLabel);
        registerAndDraw(ctx, btnLayout, false);
        cy += 24;

        // ── Position controls ─────────────────────────────────────────────
        sectionLabel(ctx, "HUD POSITION", x + 10, cy);
        cy += 12;

        // Coords display
        fill(ctx, x + 10, cy - 2, 130, 16, PANEL);
        border(ctx, x + 10, cy - 2, 130, 16, BORDER);
        ctx.drawTextWithShadow(textRenderer,
                "\u00A78X=\u00A7f" + cfg.consolidatedX + "  \u00A78Y=\u00A7f" + cfg.consolidatedY,
                x + 16, cy + 2, TEXT_MID);

        // Reset button
        Btn btnReset = new Btn(x + 148, cy - 2, 80, 16, BTN_RESET_POS, "Reset");
        registerAndDraw(ctx, btnReset, false);
        cy += 22;

        // D-pad nudge
        ctx.drawTextWithShadow(textRenderer, "Nudge (5px):", x + 10, cy + 3, TEXT_DIM);
        int dp = x + 110;
        registerAndDraw(ctx, new Btn(dp,    cy, 20, 16, BTN_NUDGE_L, "\u25C4"), false);
        registerAndDraw(ctx, new Btn(dp+22, cy, 20, 16, BTN_NUDGE_R, "\u25BA"), false);
        registerAndDraw(ctx, new Btn(dp+44, cy, 20, 16, BTN_NUDGE_U, "\u25B2"), false);
        registerAndDraw(ctx, new Btn(dp+66, cy, 20, 16, BTN_NUDGE_D, "\u25BC"), false);
        cy += 26;

        // ── Drag handle ───────────────────────────────────────────────────
        sectionLabel(ctx, "DRAG TO REPOSITION", x + 10, cy);
        cy += 8;

        int phX = x + 10, phY = cy, phW = PW - 20, phH = 38;
        boolean hovHandle = gx >= phX && gx < phX+phW && gy >= phY && gy < phY+phH;
        int handleBg  = dragging ? DRAG_ACTIVE : hovHandle ? DRAG_HOV : DRAG_IDLE;
        int handleBrd = dragging ? 0xFFAA77FF  : hovHandle ? ACCENT   : BORDER;

        fill(ctx, phX, phY, phW, phH, handleBg);
        border(ctx, phX, phY, phW, phH, handleBrd);
        // dashed inner border for visual interest
        if (!dragging) {
            for (int dx2 = phX+4; dx2 < phX+phW-4; dx2 += 6)
                ctx.fill(dx2, phY+2, dx2+3, phY+3, 0x20AABBDD);
        }

        String handleText = dragging
                ? "\u00A7d\u25A0 Dragging...  release to set"
                : (hovHandle ? "\u00A77Click & drag to reposition the cooldown HUD"
                             : "\u00A78\u2630  Drag Handle  \u2014  \u00A77click & drag");
        int htw = textRenderer.getWidth(handleText);
        ctx.drawTextWithShadow(textRenderer, handleText,
                phX + (phW - htw)/2, phY + (phH - 7)/2,
                dragging ? 0xFFCC88FF : (hovHandle ? TEXT_MID : TEXT_DIM));
        cy += phH + 8;

        // ── Tip ───────────────────────────────────────────────────────────
        ctx.drawTextWithShadow(textRenderer,
                "§8✦  Cooldowns appear in-game and auto-update from chat.",
                x + 14, cy + 2, TEXT_DIM);
    }

    // ─────────────────────────────────────────────────────────────────────
    // BUTTON HELPERS
    // ─────────────────────────────────────────────────────────────────────

    /** Register a button AND draw it immediately */
    private void registerAndDraw(DrawContext ctx, Btn b, boolean pressed) {
        drawBtn(ctx, b, pressed);
        buttons.add(b);
    }

    /** Register without drawing (used for toggle/stepper which draw themselves) */
    private void registerBtn(int bx, int by, int bw, int bh, int tag, String label) {
        buttons.add(new Btn(bx, by, bw, bh, tag, label));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GLFW POLLING  (replaces all mousePressed/Dragged/Released overrides)
    // ─────────────────────────────────────────────────────────────────────
    private void pollGlfw() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null) return;

        long win = mc.getWindow().getHandle();
        double sf = mc.getWindow().getScaleFactor();
        double[] rx = new double[1], ry = new double[1];
        GLFW.glfwGetCursorPos(win, rx, ry);
        gx = rx[0] / sf;
        gy = ry[0] / sf;
        boolean lmb = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        org.cheetahv2.antigravity.client.AntigravityClient.HudSettings hs = org.cheetahv2.antigravity.client.AntigravityClient.HUD_SETTINGS;
        AbilityCooldownManager acm = org.cheetahv2.antigravity.client.AntigravityClient.ABILITY_COOLDOWN;
        AbilityCooldownManager.SavedConfig cfg = acm.getConfig();

        // ── Drag handle (cooldowns tab) ───────────────────────────────────
        if (activeTab == 1) {
            // Recalculate handle bounds (must match renderCooldownsTab layout)
            // The handle is the large drag strip. We detect it by checking a
            // broad region; exact Y depends on layout so we use a generous zone.
            int phX = px() + 10;
            int phW = PW - 20;
            // Approximate phY: HDR + TAB + content + 3 sections worth of height
            int approxPhY = py() + CONTENT_TOP + 6 + 12 + 24 + 12 + 22 + 26 + 8;
            int phH = 38;

            if (lmb && !prevLmb && !dragging
                    && gx >= phX && gx < phX + phW
                    && gy >= approxPhY && gy < approxPhY + phH) {
                dragging = true;
                dragOffX = (int)(gx - cfg.consolidatedX);
                dragOffY = (int)(gy - cfg.consolidatedY);
            }
            if (dragging && lmb) {
                int sw = mc.getWindow().getScaledWidth();
                int sh = mc.getWindow().getScaledHeight();
                cfg.consolidatedX = Math.max(0, Math.min(sw - 160, (int)(gx - dragOffX)));
                cfg.consolidatedY = Math.max(0, Math.min(sh -  60, (int)(gy - dragOffY)));
            }
            if (dragging && !lmb) {
                dragging = false;
                acm.save();
            }
        }

        // ── Button clicks (fresh press only) ─────────────────────────────
        if (lmb && !prevLmb) {
            for (Btn b : buttons) {
                if (gx >= b.x && gx < b.x+b.w && gy >= b.y && gy < b.y+b.h) {
                    handleClick(b.tag, hs, acm, cfg);
                    break;
                }
            }
        }

        prevLmb = lmb;
    }

    private void handleClick(int tag,
                             org.cheetahv2.antigravity.client.AntigravityClient.HudSettings hs,
                             AbilityCooldownManager acm,
                             AbilityCooldownManager.SavedConfig cfg) {
        switch (tag) {
            case BTN_CLOSE         -> onClose();
            case BTN_TAB_0         -> { activeTab = 0; dragging = false; }
            case BTN_TAB_1         -> { activeTab = 1; dragging = false; }
            case BTN_TAB_2         -> { activeTab = 2; dragging = false; }
            // HUD tab
            case BTN_STATUS_TOGGLE -> { hs.showStatusBar   ^= true; hs.save(); }
            case BTN_CRATE_TOGGLE  -> { hs.showCratePuller ^= true; hs.save(); }
            case BTN_EVENT_HUD_TOGGLE -> {
                org.cheetahv2.antigravity.client.AntigravityClient.EVENT_SCHEDULE.setHudEnabled(
                    !org.cheetahv2.antigravity.client.AntigravityClient.EVENT_SCHEDULE.isHudEnabled());
            }
            case BTN_LARK_SCALE_DN -> { hs.larkLabelScale   = Math.max(0.5f,  hs.larkLabelScale   - 0.5f);  hs.save(); }
            case BTN_LARK_SCALE_UP -> { hs.larkLabelScale   = Math.min(8.0f,  hs.larkLabelScale   + 0.5f);  hs.save(); }
            case BTN_LARK_HEIGHT_DN-> { hs.labelHeightOffset= Math.max(-2f,   hs.labelHeightOffset- 0.25f); hs.save(); }
            case BTN_LARK_HEIGHT_UP-> { hs.labelHeightOffset= Math.min(4f,    hs.labelHeightOffset+ 0.25f); hs.save(); }
            case BTN_GLOW_SCALE_DN -> { hs.labelScale       = Math.max(0.5f,  hs.labelScale       - 0.5f);  hs.save(); }
            case BTN_GLOW_SCALE_UP -> { hs.labelScale       = Math.min(8.0f,  hs.labelScale       + 0.5f);  hs.save(); }
            case BTN_LARK_RESET_POS-> { hs.larkHudX = 10; hs.larkHudY = 220; hs.save(); }
            // Cooldowns tab
            case BTN_SCALE_DN      -> { cfg.scale = Math.max(0.4f, cfg.scale - 0.1f); acm.save(); }
            case BTN_SCALE_UP      -> { cfg.scale = Math.min(3.0f, cfg.scale + 0.1f); acm.save(); }
            case BTN_LAYOUT        -> {
                cfg.layoutMode = cfg.layoutMode == AbilityCooldownManager.LayoutMode.CONSOLIDATED
                        ? AbilityCooldownManager.LayoutMode.INDIVIDUAL
                        : AbilityCooldownManager.LayoutMode.CONSOLIDATED;
                acm.save();
            }
            case BTN_RESET_POS     -> { cfg.consolidatedX = 10; cfg.consolidatedY = 50; acm.save(); }
            case BTN_NUDGE_L       -> { cfg.consolidatedX -= 5; acm.save(); }
            case BTN_NUDGE_R       -> { cfg.consolidatedX += 5; acm.save(); }
            case BTN_NUDGE_U       -> { cfg.consolidatedY -= 5; acm.save(); }
            case BTN_NUDGE_D       -> { cfg.consolidatedY += 5; acm.save(); }
            default -> {
                // Ability toggles (cooldown tab)
                if (tag >= BTN_ABILITY_BASE && tag < BTN_UTIL_BASE) {
                    int idx = tag - BTN_ABILITY_BASE;
                    List<AbilityCooldownManager.AbilityDef> defs = AbilityCooldownManager.getDefs();
                    if (idx < defs.size()) {
                        AbilityCooldownManager.AbilitySetting s =
                                cfg.settings.computeIfAbsent(defs.get(idx).id,
                                        k -> new AbilityCooldownManager.AbilitySetting());
                        s.enabled ^= true;
                        acm.save();
                    }
                }
                // Utility module enable toggles
                else if (tag >= BTN_UTIL_BASE && tag < BTN_COOKIE_DELAY_DN) {
                    int idx = tag - BTN_UTIL_BASE;
                    UtilityModuleManager mgr = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES;
                    if (idx < mgr.modules.size()) {
                        UtilityModule m = mgr.modules.get(idx);
                        m.setEnabled(!m.isEnabled());
                    }
                }
                // Cookie settings (index 0)
                else if (tag == BTN_COOKIE_DELAY_DN || tag == BTN_COOKIE_DELAY_UP) {
                    AutoCookieModule.Config cc = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_COOKIE.getConfig();
                    cc.triggerDelayMs = Math.max(0, Math.min(5000,
                            cc.triggerDelayMs + (tag == BTN_COOKIE_DELAY_UP ? 50 : -50)));
                    org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_COOKIE.save();
                }
                else if (tag == BTN_COOKIE_CD_DN || tag == BTN_COOKIE_CD_UP) {
                    AutoCookieModule.Config cc = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_COOKIE.getConfig();
                    cc.cookieCooldownMs = Math.max(0, Math.min(5000,
                            cc.cookieCooldownMs + (tag == BTN_COOKIE_CD_UP ? 250 : -250)));
                    org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_COOKIE.save();
                }
                // Jack of Hearts settings (index 1)
                else if (tag == BTN_JACK_DELAY_DN || tag == BTN_JACK_DELAY_UP) {
                    AutoJackOfHeartsModule.Config jc = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_JACK_OF_HEARTS.getConfig();
                    jc.triggerDelayMs = Math.max(0, Math.min(5000,
                            jc.triggerDelayMs + (tag == BTN_JACK_DELAY_UP ? 50 : -50)));
                    org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_JACK_OF_HEARTS.save();
                }
                else if (tag == BTN_JACK_CD_DN || tag == BTN_JACK_CD_UP) {
                    AutoJackOfHeartsModule.Config jc = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_JACK_OF_HEARTS.getConfig();
                    jc.useCooldownMs = Math.max(0, Math.min(10000,
                            jc.useCooldownMs + (tag == BTN_JACK_CD_UP ? 250 : -250)));
                    org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_JACK_OF_HEARTS.save();
                }
                // Sacred shield HP threshold (index 2)
                else if (tag == BTN_SACRED_HP_DN || tag == BTN_SACRED_HP_UP) {
                    AutoSacredShieldModule.Config sc = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_SACRED_SHIELD.getConfig();
                    sc.triggerHealth = Math.max(2f, Math.min(20f,
                            sc.triggerHealth + (tag == BTN_SACRED_HP_UP ? 1f : -1f)));
                    org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_SACRED_SHIELD.save();
                }
                // Tropical shield HP threshold (index 3)
                else if (tag == BTN_TROPICAL_HP_DN || tag == BTN_TROPICAL_HP_UP) {
                    AutoTropicalShieldModule.Config tc = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_TROPICAL_SHIELD.getConfig();
                    tc.triggerHealth = Math.max(2f, Math.min(20f,
                            tc.triggerHealth + (tag == BTN_TROPICAL_HP_UP ? 1f : -1f)));
                    org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES.AUTO_TROPICAL_SHIELD.save();
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // TAB 2 — UTILITY MODULES
    // ─────────────────────────────────────────────────────────────────────
    private void renderUtilityTab(DrawContext ctx, int x, int cy) {
        UtilityModuleManager mgr = org.cheetahv2.antigravity.client.AntigravityClient.UTILITY_MODULES;
        AutoCookieModule.Config       cc = mgr.AUTO_COOKIE.getConfig();
        AutoJackOfHeartsModule.Config jc = mgr.AUTO_JACK_OF_HEARTS.getConfig();
        AutoSacredShieldModule.Config sc = mgr.AUTO_SACRED_SHIELD.getConfig();
        AutoTropicalShieldModule.Config tc = mgr.AUTO_TROPICAL_SHIELD.getConfig();

        // ── Header hint ───────────────────────────────────────────────────
        ctx.drawTextWithShadow(textRenderer,
                "\u00A78\u2714 Automation modules run while in-game. Toggle each independently.",
                x + 10, cy, TEXT_DIM);
        cy += 14;

        // ── MODULE 0: Auto Cookie ─────────────────────────────────────────
        cy = renderModuleHeader(ctx, x, cy, 0, mgr.AUTO_COOKIE);
        if (mgr.AUTO_COOKIE.isEnabled()) {
            drawStepper(ctx, x + 18, cy, "Trigger Delay",
                    cc.triggerDelayMs + " ms",
                    new Btn(x + 200, cy, 18, 14, BTN_COOKIE_DELAY_DN, ""),
                    new Btn(x + 222, cy, 18, 14, BTN_COOKIE_DELAY_UP, ""));
            cy += 20;
            drawStepper(ctx, x + 18, cy, "Cookie Cooldown",
                    (cc.cookieCooldownMs / 1000.0f) + "s",
                    new Btn(x + 200, cy, 18, 14, BTN_COOKIE_CD_DN, ""),
                    new Btn(x + 222, cy, 18, 14, BTN_COOKIE_CD_UP, ""));
            cy += 20;
            ctx.drawTextWithShadow(textRenderer,
                    "\u00A78\u2937 Searches inventory for Santa's Cookie \u2192 slot 8",
                    x + 18, cy, TEXT_DIM);
            cy += 14;
        }
        cy += 4;

        // ── MODULE 1: Auto Jack of Hearts ─────────────────────────────────
        cy = renderModuleHeader(ctx, x, cy, 1, mgr.AUTO_JACK_OF_HEARTS);
        if (mgr.AUTO_JACK_OF_HEARTS.isEnabled()) {
            drawStepper(ctx, x + 18, cy, "Trigger Delay",
                    jc.triggerDelayMs + " ms",
                    new Btn(x + 200, cy, 18, 14, BTN_JACK_DELAY_DN, ""),
                    new Btn(x + 222, cy, 18, 14, BTN_JACK_DELAY_UP, ""));
            cy += 20;
            drawStepper(ctx, x + 18, cy, "Use Cooldown",
                    (jc.useCooldownMs / 1000.0f) + "s",
                    new Btn(x + 200, cy, 18, 14, BTN_JACK_CD_DN, ""),
                    new Btn(x + 222, cy, 18, 14, BTN_JACK_CD_UP, ""));
            cy += 20;
            ctx.drawTextWithShadow(textRenderer,
                    "\u00A78\u2937 Uses Jack of Hearts (paper) when runiced",
                    x + 18, cy, TEXT_DIM);
            cy += 14;
        }
        cy += 4;

        // ── MODULE 2: Auto Sacred Shield ──────────────────────────────────
        cy = renderModuleHeader(ctx, x, cy, 2, mgr.AUTO_SACRED_SHIELD);
        if (mgr.AUTO_SACRED_SHIELD.isEnabled()) {
            String hpLabel = String.format("%.0f HP (%.1f\u2665)", sc.triggerHealth, sc.triggerHealth / 2f);
            drawStepper(ctx, x + 18, cy, "Equip Below",
                    hpLabel,
                    new Btn(x + 200, cy, 18, 14, BTN_SACRED_HP_DN, ""),
                    new Btn(x + 222, cy, 18, 14, BTN_SACRED_HP_UP, ""));
            cy += 20;
            ctx.drawTextWithShadow(textRenderer,
                    "\u00A78\u2937 Needs: item named \"Sacred\" with Divine Intervention lore",
                    x + 18, cy, TEXT_DIM);
            cy += 14;
        }
        cy += 4;

        // ── MODULE 3: Auto Tropical Shield ────────────────────────────────
        cy = renderModuleHeader(ctx, x, cy, 3, mgr.AUTO_TROPICAL_SHIELD);
        if (mgr.AUTO_TROPICAL_SHIELD.isEnabled()) {
            String hpLabel = String.format("%.0f HP (%.1f\u2665)", tc.triggerHealth, tc.triggerHealth / 2f);
            drawStepper(ctx, x + 18, cy, "Equip Below",
                    hpLabel,
                    new Btn(x + 200, cy, 18, 14, BTN_TROPICAL_HP_DN, ""),
                    new Btn(x + 222, cy, 18, 14, BTN_TROPICAL_HP_UP, ""));
            cy += 20;
            ctx.drawTextWithShadow(textRenderer,
                    "\u00A78\u2937 Needs: item named \"Tropical\" anywhere in inventory",
                    x + 18, cy, TEXT_DIM);
            cy += 14;
        }
        cy += 4;

        // ── MODULE 4: Auto Totem ──────────────────────────────────────────
        cy = renderModuleHeader(ctx, x, cy, 4, mgr.AUTO_TOTEM);
        if (mgr.AUTO_TOTEM.isEnabled()) {
            ctx.drawTextWithShadow(textRenderer,
                    "\u00A78\u2937 Keeps Totem of Undying in offhand. Re-equips after use.",
                    x + 18, cy, TEXT_DIM);
            cy += 14;
        }
    }

    /**
     * Renders a module header row: coloured pill background, module name,
     * description, and an ON/OFF toggle button. Returns updated cy.
     */
    private int renderModuleHeader(DrawContext ctx, int x, int cy, int moduleIndex, UtilityModule module) {
        boolean on = module.isEnabled();

        // Pill background
        int pillBg  = on ? 0x40103020 : 0x20101828;
        int pillBrd = on ? GREEN      : BORDER;
        fill(ctx,   x + 8, cy - 2, PW - 16, 18, pillBg);
        border(ctx, x + 8, cy - 2, PW - 16, 18, pillBrd);

        // Module name
        ctx.drawTextWithShadow(textRenderer,
                (on ? "\u00A7a" : "\u00A77") + module.getName(),
                x + 14, cy + 2, TEXT_HI);

        // Description
        int descX = x + 14 + textRenderer.getWidth(module.getName()) + 10;
        ctx.drawTextWithShadow(textRenderer,
                "\u00A78\u2014 " + module.getDescription(),
                descX, cy + 2, TEXT_DIM);

        // Toggle button (right side)
        Btn toggleBtn = new Btn(x + PW - 80, cy - 1, 62, 16, BTN_UTIL_BASE + moduleIndex, "");
        drawToggleBtn(ctx, toggleBtn, on);
        buttons.add(toggleBtn);

        cy += 20;
        return cy;
    }

    // ─────────────────────────────────────────────────────────────────────
    // KEYBOARD
    // ─────────────────────────────────────────────────────────────────────
    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    public void onClose() {
        org.cheetahv2.antigravity.client.AntigravityClient.HUD_SETTINGS.save();
        org.cheetahv2.antigravity.client.AntigravityClient.ABILITY_COOLDOWN.save();
        MinecraftClient.getInstance().setScreen(null);
    }
}
