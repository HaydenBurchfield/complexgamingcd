package org.cheetahv2.antigravity.client.cooldown;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.cheetahv2.antigravity.client.AntigravityClient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * RuneAvailabilityHud
 *
 * Shows a side panel listing which runes are currently AVAILABLE — meaning:
 *   1. They are in the player's inventory (item name contains the rune keyword), AND
 *   2. They are not currently on cooldown, AND
 *   3. Their ID is in ALWAYS_SHOW_IDS  (always listed if not on CD, regardless of inv)
 *      OR their item was found in inventory.
 *
 * Edit ALWAYS_SHOW_IDS to control which runes show regardless of inventory.
 * Each CustomEnchant already has a displayName — this class matches inventory items
 * by checking if the item name contains the enchant's keyword (lower-case displayName words).
 *
 * INV_KEYWORDS maps enchant ID → word(s) that must appear in the item name to count
 * as "that rune being in inventory". If an ID isn't in INV_KEYWORDS, it is inventory-
 * checked using the enchant's displayName words.
 */
public class RuneAvailabilityHud {

    // ── Always show these rune IDs regardless of inventory ───────────────
    // These will appear whenever they are NOT on cooldown.
    public static final Set<String> ALWAYS_SHOW_IDS = new LinkedHashSet<>(Arrays.asList(
        // Add rune IDs here that you always want visible when available:
            "shuffle_deck",
            "lifebuoy",
            "lifeforce",
            "dasher",
            "toxic_forcefield",
            "power_pylon",
            "rain_dance",
            "lovestruck"
    ));

    // ── Inventory keyword overrides ───────────────────────────────────────
    // Maps rune ID → keyword that must appear in item display name.
    // If not listed, the rune's displayName is split into words and all must match.
    public static final Map<String, String> INV_KEYWORDS = new HashMap<>();
    static {
        INV_KEYWORDS.put("shuffle_deck",    "shuffle deck");
        INV_KEYWORDS.put("invocation",      "invocation");
        INV_KEYWORDS.put("swift_strike",    "swift strike");
        INV_KEYWORDS.put("circus_cannon",   "circus cannon");
        INV_KEYWORDS.put("illusion",        "illusion");
        INV_KEYWORDS.put("snake_eyes",      "snake eyes");
        INV_KEYWORDS.put("beeswax",         "beeswax");
        INV_KEYWORDS.put("lifebuoy",        "lifebuoy");
        INV_KEYWORDS.put("light_speed",     "light speed");
        INV_KEYWORDS.put("overhead_spin",   "overhead spin");
        INV_KEYWORDS.put("deep_freeze",     "deep freeze");
        INV_KEYWORDS.put("lifeforce",       "lifeforce");
        INV_KEYWORDS.put("dasher",          "dasher");
        INV_KEYWORDS.put("plaugeweaver",    "plagueweaver");
        INV_KEYWORDS.put("raging_smash",    "raging smash");
        INV_KEYWORDS.put("toxic_forcefield","toxic forcefield");
        INV_KEYWORDS.put("ascent",          "ascent");
        INV_KEYWORDS.put("power_pylon",     "power pylon");
        INV_KEYWORDS.put("rain_dance",      "rain dance");
        INV_KEYWORDS.put("squirting_flower","squirting flower");
        INV_KEYWORDS.put("love_birds",      "love birds");
        INV_KEYWORDS.put("lovestruck",      "lovestruck");
    }

    // ── Position persistence ─────────────────────────────────────────────
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = Paths.get("config", "antigravity", "hud_rune_avail.json");

    public static class SavedPos {
        public int x = -1;  // -1 = use default (right side)
        public int y = -1;
        public float scale = 1.0f;
    }

    private SavedPos pos = new SavedPos();

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(pos));
        } catch (IOException ignored) {}
    }

    public void load() {
        if (!Files.exists(FILE)) return;
        try {
            SavedPos p = GSON.fromJson(Files.readString(FILE), SavedPos.class);
            if (p != null) pos = p;
        } catch (IOException ignored) {}
    }

    public int getX(int screenWidth) {
        if (pos.x >= 0) return pos.x;
        return screenWidth - PANEL_W - 4;
    }

    public int getY(int screenHeight) {
        if (pos.y >= 0) return pos.y;
        return screenHeight / 2 - 40;
    }

    public float getScale() { return Math.max(0.4f, Math.min(3.0f, pos.scale)); }
    public void setScale(float s) { pos.scale = Math.max(0.4f, Math.min(3.0f, s)); }

    public void setPos(int x, int y) {
        pos.x = x;
        pos.y = y;
    }

    // ── Panel dimensions (unscaled) ──────────────────────────────────────
    public static final int PANEL_W  = 115;
    private static final int ENTRY_H  = 13;
    private static final int HEADER_H = 13;

    // ── Drag state (used from HudDragScreen) ─────────────────────────────
    public boolean dragging = false;
    public int dragOffX, dragOffY;

    // ── Alpha helper ─────────────────────────────────────────────────────
    private static int applyAlpha(int argb, int alpha) {
        int baseA = (argb >>> 24) & 0xFF;
        int finalA = baseA * alpha / 255;
        return (finalA << 24) | (argb & 0x00FFFFFF);
    }

    /** Vertical gradient: colorTop at y, colorBottom at y+h. */
    public static void fillGradientV(DrawContext ctx, int x, int y, int w, int h,
                                      int colorTop, int colorBottom) {
        int at = (colorTop   >>> 24) & 0xFF, rt = (colorTop   >> 16) & 0xFF;
        int gt = (colorTop   >>  8) & 0xFF,  bt = (colorTop        ) & 0xFF;
        int ab = (colorBottom >>> 24) & 0xFF, rb = (colorBottom >> 16) & 0xFF;
        int gb = (colorBottom >>  8) & 0xFF,  bb = (colorBottom      ) & 0xFF;
        for (int row = 0; row < h; row++) {
            float t = (h <= 1) ? 0f : (float) row / (h - 1);
            int a = at + (int)((ab - at) * t);
            int r = rt + (int)((rb - rt) * t);
            int g = gt + (int)((gb - gt) * t);
            int b = bt + (int)((bb - bt) * t);
            ctx.fill(x, y + row, x + w, y + row + 1, (a << 24) | (r << 16) | (g << 8) | b);
        }
    }

    // ── Inventory check ───────────────────────────────────────────────────

    /**
     * Returns true if the player has an item matching this rune in their inventory
     * (hotbar + main inv + offhand). Checks if the item display name contains
     * the keyword from INV_KEYWORDS (or the enchant displayName words if not mapped).
     */
    private static boolean isRuneInInventory(MinecraftClient mc,
                                              CustomCooldownSystem.CustomEnchant enchant) {
        if (mc == null || mc.player == null) return false;

        String keyword = INV_KEYWORDS.get(enchant.id);
        if (keyword == null) keyword = enchant.displayName.toLowerCase();
        final String kw = keyword.toLowerCase();

        // Check all inventory slots (0–35) + offhand (40)
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty()) {
                String name = stack.getName().getString().toLowerCase();
                if (name.contains(kw)) return true;
            }
        }
        // Offhand
        ItemStack offhand = mc.player.getOffHandStack();
        if (!offhand.isEmpty()) {
            String name = offhand.getName().getString().toLowerCase();
            if (name.contains(kw)) return true;
        }
        return false;
    }

    // ── Render ────────────────────────────────────────────────────────────

    public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc == null || mc.getWindow() == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        TextRenderer tr = mc.textRenderer;
        float scale = getScale();

        Map<String, AbilityCooldownManager.CooldownInstance> active =
                AntigravityClient.ABILITY_COOLDOWN.getActive();

        // Build the list: rune must be (ALWAYS_SHOW or in inv) AND not on cooldown
        List<CustomCooldownSystem.CustomEnchant> available = new ArrayList<>();
        for (CustomCooldownSystem.CustomEnchant e : CustomCooldownSystem.REGISTRY) {
            if (active.containsKey(e.id)) continue; // on cooldown — skip

            boolean alwaysShow = ALWAYS_SHOW_IDS.contains(e.id);
            boolean inInv      = isRuneInInventory(mc, e);

            if (alwaysShow || inInv) {
                available.add(e);
            }
        }

        if (available.isEmpty()) return;

        int px = getX(sw);
        int py = getY(sh);
        int panelH = HEADER_H + available.size() * ENTRY_H + 3;

        var ms = ctx.getMatrices();
        ms.pushMatrix();
        ms.translate((float) px, (float) py);
        ms.scale(scale, scale);

        int pw = PANEL_W;

        // ── Background ────────────────────────────────────────────────────
        ctx.fill(0, 0, pw, panelH, 0xBB050508);
        gborder(ctx, 0, 0, pw, panelH, 0x55AADDFF);
        ctx.fill(1, 1, pw - 1, 2, 0x12FFFFFF); // top glass highlight

        // ── Header ────────────────────────────────────────────────────────
        ctx.drawTextWithShadow(tr, "§b✦ Available", 5, 3, 0xFF88CCFF);
        ctx.fill(1, HEADER_H - 1, pw - 1, HEADER_H, 0x44AADDFF); // separator

        // ── Entries ───────────────────────────────────────────────────────
        int ey = HEADER_H + 1;
        for (CustomCooldownSystem.CustomEnchant e : available) {
            int runeColor = e.color | 0xFF000000;

            // Left gradient bar
            fillGradientV(ctx, 1, ey, 2, ENTRY_H - 1, runeColor, 0xFF000000);

            // Checkmark
            ctx.drawTextWithShadow(tr, "§a✔", 5, ey + 2, 0xFF55FF55);

            // Rune icon
            ctx.drawTextWithShadow(tr, e.iconChar, 16, ey + 2, e.color);

            // Name (truncated)
            String name = e.displayName;
            int maxW = pw - 30;
            while (tr.getWidth(name) > maxW && name.length() > 3)
                name = name.substring(0, name.length() - 1);
            if (!name.equals(e.displayName)) name += "…";
            ctx.drawTextWithShadow(tr, name, 27, ey + 2, 0xFFDDEEFF);

            ey += ENTRY_H;
        }

        ms.popMatrix();
    }

    private void gborder(DrawContext ctx, int x, int y, int w, int h, int col) {
        ctx.fill(x, y, x + w, y + 1, col);
        ctx.fill(x, y + h - 1, x + w, y + h, col);
        ctx.fill(x, y, x + 1, y + h, col);
        ctx.fill(x + w - 1, y, x + w, y + h, col);
    }

    /** Estimated panel height for ghost box sizing in HudDragScreen. */
    public int estimatePanelH() {
        // Use a rough upper bound (all ALWAYS_SHOW + potential inv items)
        // Real count requires MC player access; just use ALWAYS_SHOW count as floor.
        int estimate = Math.max(ALWAYS_SHOW_IDS.size(), 4);
        return (int)((HEADER_H + estimate * ENTRY_H + 3) * getScale());
    }

    public int getScaledWidth() { return (int)(PANEL_W * getScale()); }
}
