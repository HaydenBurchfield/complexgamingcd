package org.cheetahv2.antigravity.client.tracker;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import java.util.*;

public class PlayerTracker {
    private final Map<String, ArrayDeque<ItemStack>> heldHistory = new LinkedHashMap<>();

    public void tick(MinecraftClient mc) {
        if (mc == null || mc.world == null) return;
        for (PlayerEntity p : mc.world.getPlayers()) {
            String name = p.getName().getString();
            ItemStack hand = p.getMainHandStack();
            ArrayDeque<ItemStack> hist = heldHistory.computeIfAbsent(name, k -> new ArrayDeque<>());
            ItemStack last = hist.isEmpty() ? ItemStack.EMPTY : hist.peekFirst();
            if (!ItemStack.areItemsEqual(hand, last)) {
                if (!hand.isEmpty()) {
                    hist.addFirst(hand.copy());
                    while (hist.size() > 10) hist.pollLast();
                }
            }
        }
    }

    public List<ItemStack> getHistory(String playerName) {
        ArrayDeque<ItemStack> hist = heldHistory.get(playerName);
        return hist == null ? Collections.emptyList() : new ArrayList<>(hist);
    }
}
