package org.cheetahv2.antigravity.client.utility;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.sync.ItemStackHash;
import net.minecraft.text.Text;
import org.cheetahv2.antigravity.client.util.ConfigHelper;
import org.cheetahv2.antigravity.client.util.RomanHelper;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * AutoSellSoulModule
 *
 * Keybind-triggered (not threshold-triggered, unlike Sacred/Tropical Shield).
 * On key press: finds the "Sell Soul" leggings anywhere in the inventory,
 * swaps them into the held hotbar slot (or uses the swap-hands button if the
 * held slot IS slot 0), taps the vanilla swap-hands key twice to open the
 * server's custom sell menu, presses "1" to confirm the sale, then restores
 * the leggings (if anything is left of them) back to their original slot.
 *
 * Item detection: lore contains "Sell Soul" (color-code/format independent —
 * matched on the stripped string), with the level read from the trailing
 * roman numeral in the lore line.
 *
 * Tick-delay state machine — one action per tick so the server has time to
 * process each step before the next is sent:
 *
 *  IDLE → (keybind pressed) → MOVE_TO_SLOT → [swap leggings into target slot]
 *        → OPEN_MENU_1 → tap swap-hands (1st press)
 *        → OPEN_MENU_2 → tap swap-hands (2nd press, opens menu)
 *        → CONFIRM_SELL → tap "1" key (confirms sale)
 *        → RESTORE → [swap leggings back to original slot, if present]
 *        → IDLE
 */
public class AutoSellSoulModule implements UtilityModule {

    // ── Config ────────────────────────────────────────────────────────────
    public static class Config {
        public boolean enabled          = false;
        /** Minimum ms between state transitions. */
        public int     actionCooldownMs = 150;
    }

    private Config config = new Config();
    private static final Path FILE = Paths.get("config", "antigravity", "module_sell_soul.json");

    // ── State machine ─────────────────────────────────────────────────────
    private enum Phase { IDLE, MOVE_TO_SLOT, OPEN_MENU_1, OPEN_MENU_1_RELEASE,
                          OPEN_MENU_2, OPEN_MENU_2_RELEASE,
                          CONFIRM_SELL, CONFIRM_SELL_RELEASE, RESTORE }
    private Phase phase        = Phase.IDLE;
    private long  lastActionMs = 0L;

    // Set during MOVE_TO_SLOT, used during RESTORE
    private int   legsInvSlot  = -1;   // original 0-35 inventory slot
    private int   legsScrSlot  = -1;   // screen-handler slot for legsInvSlot
    private int   workingSlot  = -1;   // hotbar slot used to perform the sell (0-8)
    private boolean usedSwapButton = false; // true if we used button 40 (offhand) instead of a hotbar slot swap

    // ── UtilityModule impl ────────────────────────────────────────────────
    @Override public String getName()           { return "Auto Sell Soul"; }
    @Override public String getDescription()    { return "Sells Sell Soul leggings via keybind"; }
    @Override public boolean isEnabled()        { return config.enabled; }
    @Override public void setEnabled(boolean v) { config.enabled = v; save(); }

    /**
     * Called from AntigravityClient's tick loop. The caller is
     * responsible for checking KeyBinding.wasPressed() and invoking trigger()
     * only when phase == IDLE (handled internally here too, defensively).
     */
    public void trigger(MinecraftClient mc) {
        if (!config.enabled || phase != Phase.IDLE) return;
        if (mc.player == null || mc.world == null) return;

        int slot = findSellSoulLeggings(mc);
        if (slot < 0) {
            mc.player.sendMessage(Text.literal("§c[CGC] §fNo Sell Soul leggings found in inventory."), true);
            return;
        }

        legsInvSlot = slot;
        legsScrSlot = slot < 9 ? 36 + slot : slot;
        phase = Phase.MOVE_TO_SLOT;
        lastActionMs = 0L; // force-allow immediate first tick
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (!config.enabled || mc.player == null || mc.world == null) {
            if (phase != Phase.IDLE) reset();
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastActionMs < config.actionCooldownMs) return;

        switch (phase) {

            case IDLE:
                break;

            case MOVE_TO_SLOT: {
                int heldSlot = mc.player.getInventory().getSelectedSlot();

                if (legsInvSlot == heldSlot) {
                    // Leggings already sitting in the currently-held slot —
                    // nothing to swap, go straight to the menu.
                    workingSlot = heldSlot;
                    usedSwapButton = false;
                    phase = Phase.OPEN_MENU_1;
                    lastActionMs = now;
                    break;
                }

                if (heldSlot == 0) {
                    // Held slot is hotbar slot 0 — per spec, use the offhand
                    // swap button (40) to bring the leggings in instead of
                    // overwriting the held slot.
                    sendSwap(mc, (short) legsScrSlot, (byte) 40);
                    workingSlot = -1;
                    usedSwapButton = true;
                } else {
                    // Swap leggings into the currently held hotbar slot.
                    byte heldButton = (byte) heldSlot;
                    sendSwap(mc, (short) legsScrSlot, heldButton);
                    workingSlot = heldSlot;
                    usedSwapButton = false;
                }
                phase = Phase.OPEN_MENU_1;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_1: {
                setKeyPressed(mc.options.swapHandsKey, true);
                phase = Phase.OPEN_MENU_1_RELEASE;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_1_RELEASE: {
                setKeyPressed(mc.options.swapHandsKey, false);
                phase = Phase.OPEN_MENU_2;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_2: {
                setKeyPressed(mc.options.swapHandsKey, true);
                phase = Phase.OPEN_MENU_2_RELEASE;
                lastActionMs = now;
                break;
            }

            case OPEN_MENU_2_RELEASE: {
                setKeyPressed(mc.options.swapHandsKey, false);
                phase = Phase.CONFIRM_SELL;
                lastActionMs = now;
                break;
            }

            case CONFIRM_SELL: {
                setKeyPressed(mc.options.hotbarKeys[0], true); // "1" key
                phase = Phase.CONFIRM_SELL_RELEASE;
                lastActionMs = now;
                break;
            }

            case CONFIRM_SELL_RELEASE: {
                setKeyPressed(mc.options.hotbarKeys[0], false);
                phase = Phase.RESTORE;
                lastActionMs = now;
                break;
            }

            case RESTORE: {
                // Move whatever ended up in the working location back to the
                // leggings' original slot, if it's still there to move.
                if (usedSwapButton) {
                    // Came in via offhand button — swap offhand back out to original slot.
                    if (isSellSoul(mc.player.getOffHandStack())) {
                        sendSwap(mc, (short) legsScrSlot, (byte) 40);
                    }
                } else if (workingSlot >= 0 && workingSlot != legsInvSlot) {
                    ItemStack working = mc.player.getInventory().getStack(workingSlot);
                    if (isSellSoul(working)) {
                        byte button = (byte) workingSlot;
                        sendSwap(mc, (short) legsScrSlot, button);
                    }
                }
                mc.player.sendMessage(Text.literal("§a[CGC] §fSell Soul sale complete."), true);
                reset();
                lastActionMs = now;
                break;
            }
        }
    }

    private void reset() {
        phase          = Phase.IDLE;
        legsInvSlot    = -1;
        legsScrSlot    = -1;
        workingSlot    = -1;
        usedSwapButton = false;
    }

    // ── Item detection ────────────────────────────────────────────────────

    private int findSellSoulLeggings(MinecraftClient mc) {
        if (mc.player == null) return -1;
        for (int i = 9; i < 36; i++) {
            if (isSellSoul(mc.player.getInventory().getStack(i))) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (isSellSoul(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    private boolean isSellSoul(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        return hasLoreContaining(stack, "sell soul") || hasLoreContaining(stack, "&#881334🌶&#9A1D39 &#AC273ES&#BF3143e&#D13B47l&#E3454Cl&#F54F51 &#E3454CS&#D13B47o&#BF3143u&#AC273El&#9A1D39");
    }

    /** Extracts the level (1-10) from the Sell Soul lore line's trailing roman numeral, or -1 if not found. */
    public int getSellSoulLevel(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return -1;
        var lore = stack.get(DataComponentTypes.LORE);
        if (lore == null) return -1;
        for (Text line : lore.lines()) {
            String stripped = stripFormatting(line.getString()).trim();
            String siblingsAppended = stripped;
            for (Text sib : line.getSiblings()) {
                siblingsAppended += stripFormatting(sib.getString());
            }
            String lower = siblingsAppended.toLowerCase();
            if (lower.contains("sell soul")) {
                // pull the trailing token (roman numeral) off the line
                String[] parts = siblingsAppended.trim().split("\\s+");
                if (parts.length > 0) {
                    String last = parts[parts.length - 1];
                    int lvl = RomanHelper.fromRoman(last);
                    if (lvl > 0) return lvl;
                }
            }
        }
        return -1;
    }

    private boolean hasLoreContaining(ItemStack stack, String keyword) {
        var lore = stack.get(DataComponentTypes.LORE);
        if (lore == null) return false;
        for (Text line : lore.lines()) {
            String combined = stripFormatting(line.getString());
            for (Text sib : line.getSiblings()) {
                combined += stripFormatting(sib.getString());
            }
            if (combined.toLowerCase().contains(keyword)) return true;
        }
        return false;
    }

    /** Strips legacy (&x) and hex (&#RRGGBB) color codes so lore can be matched on plain text. */
    private String stripFormatting(String s) {
        if (s == null) return "";
        // Remove &#RRGGBB hex codes
        String noHex = s.replaceAll("&#[0-9A-Fa-f]{6}", "");
        // Remove legacy &x codes (color + formatting)
        return noHex.replaceAll("&[0-9a-fk-orA-FK-OR]", "");
    }

    // ── Key simulation helper ─────────────────────────────────────────────

    /**
     * Sets a vanilla KeyBinding's pressed state for one tick, mirroring how
     * MinecraftClient's own input handler would process a real key press —
     * no mixin required. Caller is responsible for releasing it on a
     * subsequent tick (handled by the *_RELEASE phases above).
     */
    private void setKeyPressed(KeyBinding key, boolean pressed) {
        net.minecraft.client.util.InputUtil.Key inputKey =
                net.minecraft.client.util.InputUtil.fromTranslationKey(key.getBoundKeyTranslationKey());
        KeyBinding.setKeyPressed(inputKey, pressed);
    }

    // ── Packet helper ─────────────────────────────────────────────────────

    private void sendSwap(MinecraftClient mc, short screenSlot, byte button) {
        if (mc.player == null) return;
        mc.player.networkHandler.sendPacket(new ClickSlotC2SPacket(
                mc.player.currentScreenHandler.syncId,
                mc.player.currentScreenHandler.getRevision(),
                screenSlot,
                button,
                SlotActionType.SWAP,
                new Int2ObjectOpenHashMap<>(),
                ItemStackHash.EMPTY
        ));
    }

    // ── Config persistence ────────────────────────────────────────────────
    @Override public void save() { ConfigHelper.save(FILE, config); }
    @Override public void load() {
        Config c = ConfigHelper.load(FILE, Config.class);
        if (c != null) config = c;
    }

    public Config getConfig() { return config; }
}
