package org.cheetahv2.antigravity.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.cheetahv2.antigravity.client.cooldown.AbilityCooldownManager;
import org.cheetahv2.antigravity.client.cooldown.CustomCooldownSystem;
import org.cheetahv2.antigravity.client.cooldown.RuneAvailabilityHud;
import org.cheetahv2.antigravity.client.detection.RunicObstructionManager;
import org.cheetahv2.antigravity.client.gui.ItemInspectScreen;
import org.cheetahv2.antigravity.client.gui.SignatureSettingsScreen;
import org.cheetahv2.antigravity.client.mixin.HandledScreenAccessor;
import org.cheetahv2.antigravity.client.tracker.EventScheduleManager;
import org.cheetahv2.antigravity.client.tracker.EventScheduleHud;
import org.cheetahv2.antigravity.client.tracker.FrozenPlayerTracker;
import org.cheetahv2.antigravity.client.tracker.PlayerTracker;
import org.cheetahv2.antigravity.client.detection.LarkManager;
import org.cheetahv2.antigravity.client.detection.CustomGlowManager;
import org.cheetahv2.antigravity.client.detection.CustomHeadLabelManager;
import org.cheetahv2.antigravity.client.gui.ViewInvScreen;
import org.cheetahv2.antigravity.client.util.SignatureManager;
import org.cheetahv2.antigravity.client.detection.TargetManager;
import org.cheetahv2.antigravity.client.gui.TargetListScreen;
import org.cheetahv2.antigravity.client.utility.UtilityModuleManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class AntigravityClient implements ClientModInitializer {


    public static String USER = "CheetahV2";


    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("antigravity", "main"));

    // Keybindings
    public static KeyBinding invseeKey;
    public static KeyBinding toggleHudKey;
    public static KeyBinding inspectItemKey;
    public static KeyBinding toggleCratePullerKey;   // show/hide crate puller on hover tooltip

    private static boolean prevInspectKeyDown = false;

    // Singletons
    public static final PlayerTracker PLAYER_TRACKER = new PlayerTracker();
    public static final LarkManager LARK_MANAGER = new LarkManager();
    public static final FrozenPlayerTracker FROZEN_TRACKER = new FrozenPlayerTracker();
    public static final AbilityCooldownManager ABILITY_COOLDOWN = new AbilityCooldownManager();
    public static final NotifManager NOTIF_MANAGER = new NotifManager();
    public static final HudSettings HUD_SETTINGS = new HudSettings();
    public static final EventScheduleManager EVENT_SCHEDULE = new EventScheduleManager();
    public static final UtilityModuleManager UTILITY_MODULES = UtilityModuleManager.INSTANCE;
    public static final RuneAvailabilityHud  RUNE_AVAIL_HUD  = new RuneAvailabilityHud();

    // Drag states
    public static boolean larkHudDragging = false;
    private static int larkDragOffX = 0, larkDragOffY = 0;

    /** Toggle key: press once to enter Lark drag mode, press again to exit. */
    public static KeyBinding larkDragModeKey;
    public static KeyBinding autoClickKey;
    public static KeyBinding sellSoulKey;
    /** True when the player has pressed the drag-mode key and we show the ghost box. */
    public static boolean larkDragModeActive = false;
    private static boolean prevLarkDragKeyDown = false;

    // Auto-fix state
    /** Set true when combat-tag-expired is detected in chat; consumed next tick. */
    private boolean pendingFixCommand = false;
    /** Set true on death so we send /fix the moment the player respawns. */
    private boolean waitingRespawnFix = false;
    /** Set true when a kill is detected in chat; consumed next tick. */
    private boolean pendingKillFix = false;

    // ============================================================
    //  HudSettings
    // ============================================================
    public static class HudSettings {
        public boolean showStatusBar = true;
        public boolean showCratePuller = true;   // toggle: show who pulled from crate on hover
        public int larkHudX = 10;
        public int larkHudY = 220;
        public float larkScale = 1.0f;
        public float labelScale = 3f;
        public float larkLabelScale = 5.0f;
        public float labelHeightOffset = 1f;

        private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
        private static final Path FILE = Paths.get("config", "antigravity", "hud.json");

        public void save() {
            try {
                Files.createDirectories(FILE.getParent());
                Files.writeString(FILE, GSON.toJson(this));
            } catch (IOException ignored) {}
        }

        public void load() {
            if (!Files.exists(FILE)) return;
            try {
                HudSettings s = GSON.fromJson(Files.readString(FILE), HudSettings.class);
                if (s == null) return;
                showStatusBar = s.showStatusBar;
                showCratePuller = s.showCratePuller;
                larkHudX = s.larkHudX;
                larkHudY = s.larkHudY;
                if (s.larkScale > 0) larkScale = s.larkScale;
                if (s.labelScale > 0) labelScale = s.labelScale;
                if (s.larkLabelScale > 0) larkLabelScale = s.larkLabelScale;
                labelHeightOffset = s.labelHeightOffset;
            } catch (IOException ignored) {}
        }
    }




    // ============================================================
    //  NotifManager
    // ============================================================
    // ============================================================
    //  NotifManager  — drop-in replacement for the inner class in
    //  AntigravityClient.java
    //
    //  Changes vs original:
    //   • anchorX / anchorY stored and persisted (default -1 = top-right corner)
    //   • saveAnchor() / loadAnchor()
    //   • getQueue() accessor so AntigravityClient can list active toasts
    //   • tickDrag() — Shift+LMB drag in-game (no screen needed)
    //   • render() now uses anchorX/anchorY if set, otherwise falls back to
    //     top-right corner behaviour identical to before
    // ============================================================
    // ============================================================
    //  NotifManager  — drop-in replacement for the inner class in
    //  AntigravityClient.java
    //
    //  Changes vs original:
    //   • anchorX / anchorY stored and persisted (default -1 = top-right corner)
    //   • saveAnchor() / loadAnchor()
    //   • getQueue() accessor so AntigravityClient can list active toasts
    //   • tickDrag() — Shift+LMB drag in-game (no screen needed)
    //   • render() now uses anchorX/anchorY if set, otherwise falls back to
    //     top-right corner behaviour identical to before
    // ============================================================
    public static class NotifManager {
        public static class Notif {
            public String text;
            public int color;
            public long expiresAt;
            public Notif(String t, int col, long dur) {
                text = t; color = col;
                expiresAt = System.currentTimeMillis() + dur;
            }
        }

        private final java.util.concurrent.CopyOnWriteArrayList<Notif> queue =
                new java.util.concurrent.CopyOnWriteArrayList<>();

        /** Drag anchor. -1 = use default top-right corner. */
        public int anchorX = -1;
        public int anchorY = -1;

        // drag state
        private boolean dragging = false;
        private int dragOffX, dragOffY;
        private static final int TOAST_W = 200; // approximate max width

        // persistence
        private static final java.nio.file.Path ANCHOR_FILE =
                java.nio.file.Paths.get("config", "antigravity", "notif_anchor.json");

        public void saveAnchor() {
            try {
                var obj = new com.google.gson.JsonObject();
                obj.addProperty("anchorX", anchorX);
                obj.addProperty("anchorY", anchorY);
                java.nio.file.Files.createDirectories(ANCHOR_FILE.getParent());
                java.nio.file.Files.writeString(ANCHOR_FILE,
                        new com.google.gson.GsonBuilder().create().toJson(obj));
            } catch (Exception ignored) {}
        }

        public void loadAnchor() {
            if (!java.nio.file.Files.exists(ANCHOR_FILE)) return;
            try {
                var obj = new com.google.gson.JsonParser().parse(
                        java.nio.file.Files.readString(ANCHOR_FILE)).getAsJsonObject();
                anchorX = obj.get("anchorX").getAsInt();
                anchorY = obj.get("anchorY").getAsInt();
            } catch (Exception ignored) {}
        }

        public java.util.List<Notif> getQueue() {
            return java.util.Collections.unmodifiableList(queue);
        }

        public void push(String text, int color, long durationMs) {
            // Notifications disabled — suppressed
        }

        public void push(String text, int color) { push(text, color, 4000); }

        public void tick() {
            queue.removeIf(n -> n.expiresAt <= System.currentTimeMillis());
        }

        /**
         * Shift+LMB drag in-game (no screen).
         * Call from ClientTickEvents.END_CLIENT_TICK.
         */
        public void tickDrag(net.minecraft.client.MinecraftClient mc) {
            if (mc == null || mc.currentScreen != null || mc.getWindow() == null) return;

            long win    = mc.getWindow().getHandle();
            double[] mx = new double[1], my = new double[1];
            org.lwjgl.glfw.GLFW.glfwGetCursorPos(win, mx, my);
            double gx = mx[0] / mc.getWindow().getScaleFactor();
            double gy = my[0] / mc.getWindow().getScaleFactor();

            boolean lmb   = org.lwjgl.glfw.GLFW.glfwGetMouseButton(win, org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            boolean shift  = org.lwjgl.glfw.GLFW.glfwGetKey(win, org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT)  == org.lwjgl.glfw.GLFW.GLFW_PRESS
                    || org.lwjgl.glfw.GLFW.glfwGetKey(win, org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;

            int sw = mc.getWindow().getScaledWidth();
            int bx = (anchorX >= 0) ? anchorX : (sw - TOAST_W - 10);
            int by = (anchorY >= 0) ? anchorY : 10;
            int bh = Math.max(12, queue.size() * 14);

            if (lmb && shift && !dragging && gx >= bx - 4 && gx <= bx + TOAST_W + 4
                    && gy >= by && gy <= by + bh) {
                dragging  = true;
                dragOffX  = (int)(gx - bx);
                dragOffY  = (int)(gy - by);
            }

            if (dragging) {
                if (lmb) {
                    anchorX = (int)(gx - dragOffX);
                    anchorY = (int)(gy - dragOffY);
                } else {
                    dragging = false;
                    saveAnchor();
                }
            }
        }

        public void render(net.minecraft.client.gui.DrawContext ctx, net.minecraft.client.MinecraftClient mc) {
            if (queue.isEmpty()) return;
            net.minecraft.client.font.TextRenderer tr = mc.textRenderer;
            int sh = mc.getWindow().getScaledHeight();
            int sw = mc.getWindow().getScaledWidth();
            long now = System.currentTimeMillis();

            // Determine anchor: custom if set, else top-right corner
            boolean customAnchor = anchorX >= 0 && anchorY >= 0;
            int baseY = customAnchor ? anchorY : 10;
            int y = baseY;

            int i = 0;
            for (Notif n : queue) {
                if (n.expiresAt <= now) continue;
                long rem   = n.expiresAt - now;
                int alpha  = (rem < 500) ? (int)(rem * 255 / 500) : 255;
                String text = colorize(n.text);
                int tw2 = tr.getWidth(text);
                // Anchor x: custom or snap to right edge
                int x = customAnchor ? anchorX : (sw - tw2 - 18);

                ctx.fill(x - 4, y - 2, x + tw2 + 6, y + 10, (alpha << 24) | 0x0A0614);
                gborder(ctx, x - 4, y - 2, tw2 + 10, 12, (alpha << 24) | 0x25FFFFFF);
                // Dragging indicator
                if (dragging && i == 0) {
                    gborder(ctx, x - 4, y - 2, tw2 + 10, 12, 0xCCFFD060);
                }
                ctx.drawTextWithShadow(tr, text, x, y, (n.color & 0x00FFFFFF) | (alpha << 24));
                y += 14;
                if (y > sh - 20) break;
                i++;
            }
        }

        private void gborder(net.minecraft.client.gui.DrawContext c, int x, int y, int w, int h, int col) {
            c.fill(x, y, x + w, y + 1, col);
            c.fill(x, y + h - 1, x + w, y + h, col);
            c.fill(x, y, x + 1, y + h, col);
            c.fill(x + w - 1, y, x + w, y + h, col);
        }
    }

    private static boolean checkedUser = false;
    private static final String ALLOWED_USER = "CheetahV2";

    @Override
    public void onInitializeClient() {

        ModAuth.beginCheck();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            String username = client.player.getGameProfile().name();

            if (!username.equals(ALLOWED_USER)) {
                client.scheduleStop();
            }
        });


        invseeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.invsee", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_I, CATEGORY
        ));
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, CATEGORY
        ));
        inspectItemKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.inspect_item",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_Z,          // default: Z — change freely in Controls screen
                CATEGORY
        ));
        toggleCratePullerKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.toggle_crate_puller",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,          // default: G — rebind freely in Controls screen
                CATEGORY
        ));
        larkDragModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.lark_drag_mode",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_L,          // default: L — toggle Lark HUD drag mode
                CATEGORY
        ));
        autoClickKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.auto_click",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F8,         // default: F8 — toggle AutoClick
                CATEGORY
        ));
        sellSoulKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.sell_soul",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,    // unbound by default — set in Controls screen
                CATEGORY
        ));


        KeyBinding cookieToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.antigravity.cookie_toggle",
                GLFW.GLFW_KEY_F9,
                CATEGORY
        ));
        // Load configs
        HUD_SETTINGS.load();
        LARK_MANAGER.load();
        FROZEN_TRACKER.load();
        ABILITY_COOLDOWN.load();
        EVENT_SCHEDULE.load();
        RUNE_AVAIL_HUD.load();
        TargetManager.load();
        UTILITY_MODULES.load();



        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {

            // /sign — sends the saved signature as a chat command
            dispatcher.register(ClientCommandManager.literal("sign")
                    .executes(ctx -> {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc == null || mc.player == null) return 0;

                        String sig = SignatureManager.getSignature();
                        mc.player.networkHandler.sendChatCommand(sig);
                        return 1;
                    }));

            // /signsettings — opens the signature editor GUI
            dispatcher.register(ClientCommandManager.literal("signsettings")
                    .executes(ctx -> {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc == null) return 0;
                        mc.send(() -> mc.setScreen(new SignatureSettingsScreen()));
                        return 1;
                    }));

            // /ccsettings — opens the main CGC settings GUI
            dispatcher.register(ClientCommandManager.literal("ccsettings")
                    .executes(ctx -> {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc == null) return 0;
                        mc.send(() -> mc.setScreen(new org.cheetahv2.antigravity.client.gui.AntigravityClient()));
                        return 1;
                    }));

            // /target — open target list GUI
            dispatcher.register(ClientCommandManager.literal("target")
                .executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc == null) return 0;
                    mc.send(() -> mc.setScreen(new TargetListScreen()));
                    return 1;
                })
                // /target add <player> [color]
                .then(ClientCommandManager.literal("add")
                    .then(ClientCommandManager.argument("player", StringArgumentType.word())
                        .executes(ctx -> {
                            String player = StringArgumentType.getString(ctx, "player");
                            TargetManager.addTarget(player, TargetManager.DEFAULT_COLOR);
                            MinecraftClient mc = MinecraftClient.getInstance();
                            if (mc != null && mc.player != null)
                                mc.player.sendMessage(Text.literal("\u00A7aTarget added: \u00A7f" + player + " \u00A77(glow: \u00A7cred\u00A77)"), false);
                            return 1;
                        })
                        .then(ClientCommandManager.argument("color", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String player   = StringArgumentType.getString(ctx, "player");
                                String colorStr = StringArgumentType.getString(ctx, "color");
                                int color = TargetManager.parseColor(colorStr);
                                TargetManager.addTarget(player, color);
                                MinecraftClient mc = MinecraftClient.getInstance();
                                if (mc != null && mc.player != null) {
                                    String hex = String.format("#%06X", color & 0xFFFFFF);
                                    mc.player.sendMessage(Text.literal("\u00A7aTarget added: \u00A7f" + player + " \u00A77(glow: \u00A7f" + hex + "\u00A77)"), false);
                                }
                                return 1;
                            })
                        )
                    )
                )
                // /target remove <player>
                .then(ClientCommandManager.literal("remove")
                    .then(ClientCommandManager.argument("player", StringArgumentType.word())
                        .executes(ctx -> {
                            String player = StringArgumentType.getString(ctx, "player");
                            boolean removed = TargetManager.removeTarget(player);
                            MinecraftClient mc = MinecraftClient.getInstance();
                            if (mc != null && mc.player != null)
                                mc.player.sendMessage(removed
                                    ? Text.literal("\u00A7cTarget removed: \u00A7f" + player)
                                    : Text.literal("\u00A77" + player + " was not a target."), false);
                            return 1;
                        })
                    )
                )
            );

            // /toggleclick — hold LMB with random releases; releases cursor without pause screen
            dispatcher.register(ClientCommandManager.literal("toggleclick")
                .executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc == null || mc.player == null) return 0;
                    boolean on = AutoClickManager.toggle();
                    if (on && mc.mouse != null) {
                        mc.mouse.unlockCursor();
                    }
                    mc.player.sendMessage(Text.literal(
                        on  ? "\u00A7a[CGC] AutoClick \u00A7lON \u00A7r\u00A77(cursor released \u2014 /toggleclick or F8 to stop)"
                            : "\u00A7c[CGC] AutoClick \u00A7lOFF"), false);
                    return 1;
                }));

            // /lockcam — toggle camera lock snapped to nearest cardinal yaw (0/90/180/-90), pitch 0
            dispatcher.register(ClientCommandManager.literal("lockcam")
                .executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc == null || mc.player == null) return 0;
                    LockCamManager.toggle(mc.player.getYaw(), mc.player.getPitch());
                    boolean now = LockCamManager.isLocked();
                    String msg = now
                        ? String.format("\u00A7bCamera locked \u00A77(yaw: \u00A7f%.0f\u00A77, pitch: \u00A7f0\u00A77)", LockCamManager.getLockedYaw())
                        : "\u00A77Camera unlocked.";
                    mc.player.sendMessage(Text.literal(msg), false);
                    return 1;
                })
            );

        });




        // Listen to Chat messages
        ClientReceiveMessageEvents.GAME.register((message, receptionTimestamp) -> {
            handleChatMessage(message.getString());
        });
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            handleChatMessage(message.getString());
        });

        // Tick loop
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null || client.player == null) return;

            // ── AutoClick ────────────────────────────────────────────────────
            AutoClickManager.tick(); // drives random-pause timer
            // LMB injection is handled by MinecraftClientAutoClickMixin (fires
            // inside tick() before handleInputEvents, works focused + background)
            // ─────────────────────────────────────────────────────────────────

            // ── Auto /fix ────────────────────────────────────────────────────
            // Trigger 1: combat-tag expiry detected in chat (pendingFixCommand)
            if (pendingFixCommand) {
                client.player.networkHandler.sendChatCommand("fix all");
                pendingFixCommand = false;
            }
            // Trigger 2: player death → wait for respawn so the server receives it
            boolean isDead = client.player.isDead() || client.player.getHealth() <= 0f;
            if (isDead) {
                waitingRespawnFix = true;
            } else if (waitingRespawnFix) {
                // Player has respawned — fire /fix
                client.player.networkHandler.sendChatCommand("fix all");
                waitingRespawnFix = false;
            }
            // Trigger 3: kill detected in chat
            if (pendingKillFix) {
                client.player.networkHandler.sendChatCommand("fix all");
                pendingKillFix = false;
            }
            // ─────────────────────────────────────────────────────────────────

            PLAYER_TRACKER.tick(client);
            LARK_MANAGER.tick(client);
            FROZEN_TRACKER.tick(client);
            NOTIF_MANAGER.tick();
            ABILITY_COOLDOWN.tickDrag(client);
            // NOTE: tickKeys removed — ability cooldowns are chat-triggered only.
            CustomGlowManager.tick(client);
            TargetManager.tick(client);
            CustomHeadLabelManager.tick();
            RunicObstructionManager.tick(client);
            UTILITY_MODULES.tick(client);

            if (sellSoulKey.wasPressed() && client.currentScreen == null) {
                UTILITY_MODULES.AUTO_SELL_SOUL.trigger(client);
            }


            // Raycast target player inspector hotkey (I key)
            if (invseeKey.wasPressed() && client.currentScreen == null) {
                PlayerEntity target = raycastPlayer(client, 50.0);
                if (target != null) {
                    client.setScreen(new ViewInvScreen(target));
                } else {

                }
            }

            while (inspectItemKey.wasPressed()) {
                ItemStack toInspect = resolveHoveredItem(client);
                if (toInspect != null && !toInspect.isEmpty()) {
                    client.setScreen(new ItemInspectScreen(toInspect));
                }
            }

            if (client.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?>) {
                long win = client.getWindow().getHandle();
                int keyCode = InputUtil.fromTranslationKey(inspectItemKey.getBoundKeyTranslationKey()).getCode();
                boolean down = GLFW.glfwGetKey(win, keyCode) == GLFW.GLFW_PRESS;
                if (down && !prevInspectKeyDown) {
                    ItemStack toInspect = resolveHoveredItem(client);
                    if (toInspect != null && !toInspect.isEmpty()) {
                        client.setScreen(new ItemInspectScreen(toInspect));
                    }
                }
                prevInspectKeyDown = down;
            } else {
                prevInspectKeyDown = false;
            }


            // Toggle HUD view
            if (toggleHudKey.wasPressed()) {
                HUD_SETTINGS.showStatusBar ^= true;
                HUD_SETTINGS.save();
                client.player.sendMessage(Text.literal("§7[CGC] HUD layout visibility toggled."), false);
            }

            // Toggle crate puller overlay
            if (toggleCratePullerKey.wasPressed()) {
                HUD_SETTINGS.showCratePuller ^= true;
                HUD_SETTINGS.save();
                client.player.sendMessage(Text.literal(
                        "§7[CGC] Crate puller overlay: " + (HUD_SETTINGS.showCratePuller ? "§aON" : "§cOFF")), false);
            }

            // AutoClick toggle (F8 keybind)
            if (autoClickKey.wasPressed()) {
                boolean on = AutoClickManager.toggle();
                if (on && client.mouse != null) {
                    client.mouse.unlockCursor();
                }
                client.player.sendMessage(Text.literal(
                    on  ? "\u00A7a[CGC] AutoClick \u00A7lON \u00A7r\u00A77(cursor released)"
                        : "\u00A7c[CGC] AutoClick \u00A7lOFF"), false);
            }

            // Toggle Lark HUD drag mode — opens pause screen
            if (larkDragModeKey.wasPressed()) {
                if (client.currentScreen == null) {
                    larkDragModeActive = true;
                    client.setScreen(new org.cheetahv2.antigravity.client.gui.HudDragScreen());
                }
            }

            // Dragging Lark HUD in-game (only when Lark is active, no drag mode screen open)
            // Drag mode with screen open is handled by HudDragScreen
            boolean canDragLark = !larkDragModeActive && LARK_MANAGER.state != LarkManager.State.IDLE;
            if (client.currentScreen == null && client.getWindow() != null && canDragLark) {
                long win = client.getWindow().getHandle();
                double[] mx = new double[1], my = new double[1];
                GLFW.glfwGetCursorPos(win, mx, my);
                double gx = mx[0] / client.getWindow().getScaleFactor();
                double gy = my[0] / client.getWindow().getScaleFactor();
                boolean lmb = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
                boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                        || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
                int pw = 160, ph = 34;
                int px2 = (HUD_SETTINGS.larkHudX >= 0) ? HUD_SETTINGS.larkHudX : 10;
                int py2 = (HUD_SETTINGS.larkHudY >= 0) ? HUD_SETTINGS.larkHudY : (client.getWindow().getScaledHeight() - 40);

                if (lmb && shift && !larkHudDragging && gx >= px2 && gx <= px2 + pw && gy >= py2 && gy <= py2 + ph) {
                    larkHudDragging = true;
                    larkDragOffX = (int) (gx - px2);
                    larkDragOffY = (int) (gy - py2);
                }
                if (larkHudDragging) {
                    if (lmb) {
                        HUD_SETTINGS.larkHudX = (int) (gx - larkDragOffX);
                        HUD_SETTINGS.larkHudY = (int) (gy - larkDragOffY);
                    } else {
                        larkHudDragging = false;
                        HUD_SETTINGS.save();
                    }
                }
            } else if (larkHudDragging) {
                larkHudDragging = false;
                HUD_SETTINGS.save();
            }
        });



        // 2D HUD Overlays
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.getWindow() == null) return;
            TextRenderer tr = mc.textRenderer;
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();

            // Render Event Schedule HUD (independent — has its own toggle in /ccsettings)
            EventScheduleHud.render(ctx, mc, EVENT_SCHEDULE);

            if (!HUD_SETTINGS.showStatusBar) return;

            // Render Ability Cooldowns HUD
            ABILITY_COOLDOWN.renderHud(ctx, mc);

            // Render Rune Availability sidebar
            RUNE_AVAIL_HUD.render(ctx, mc);

            // Render Frozen player HUD
            FROZEN_TRACKER.renderHud(ctx, mc);


            // Render Lark Status HUD
            if (LARK_MANAGER.state != LarkManager.State.IDLE) {
                LARK_MANAGER.renderHud(ctx, tr, mc, sw, sh);
            }

            // Drag hint (only when in-game Shift+LMB drag is active for Lark)
            if (larkHudDragging) {
                String hint = "§eDragging Lark HUD";
                int tw = tr.getWidth(hint);
                ctx.drawTextWithShadow(tr, hint, sw / 2 - tw / 2, 8, 0xFFFFD060);
            }

            // Notifications are disabled — no render
        });

        // ── Crate Puller Tooltip Injection ─────────────────────────────────
        net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT.register(
                (stack, tooltipContext, tooltipType, lines) -> {
                    if (!HUD_SETTINGS.showCratePuller) return;
                    String puller = extractCratePuller(stack);
                    if (puller == null) return;
                    long ts = extractPullTimestamp(stack);
                    String datePart = ts > 0 ? " §8(§7" + formatPullDate(ts) + "§8)" : "";
                    lines.add(Text.empty());
                    lines.add(Text.literal(
                            "§8[§6Crate Pull§8] §7Pulled by: §e" + puller + datePart));
                });

        // 3D above-head entity labels
        net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.world == null || mc.player == null) return;

            net.minecraft.client.util.math.MatrixStack matrices = context.matrices();
            net.minecraft.client.render.Camera camera = context.gameRenderer().getCamera();
            if (matrices == null || camera == null) return;

            long now = System.currentTimeMillis();
            TextRenderer tr = mc.textRenderer;

            // 1. Scan for active Lark Threat above-head labels
            Map<PlayerEntity, Integer> larkThreats = LARK_MANAGER.getLarkThreats(mc);
            if (!larkThreats.isEmpty()) {
                float scale = Math.max(0.5f, Math.min(8.0f, HUD_SETTINGS.larkLabelScale));
                float height = HUD_SETTINGS.labelHeightOffset;
                float ds = 0.025f * scale;
                net.minecraft.client.render.VertexConsumerProvider.Immediate imm = mc.getBufferBuilders().getEntityVertexConsumers();

                for (Map.Entry<PlayerEntity, Integer> entry : larkThreats.entrySet()) {
                    PlayerEntity player = entry.getKey();
                    int lvl = entry.getValue();
                    boolean pulse = (now / 500) % 2 == 0;
                    String text = (pulse ? "§c" : "§4") + LARK_MANAGER.buildHeadLabel(lvl);
                    int col = pulse ? 0xFF3333 : 0xFF7777;
                    int width = tr.getWidth(text);

                    matrices.push();
                    matrices.translate(player.getX() - camera.getCameraPos().x,
                            player.getY() + player.getHeight() + height - camera.getCameraPos().y,
                            player.getZ() - camera.getCameraPos().z);
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                    matrices.scale(-ds, -ds, ds);

                    tr.draw(Text.literal(text),
                            -width / 2f,
                            0f,
                            col | 0xFF000000,
                            false,
                            matrices.peek().getPositionMatrix(),
                            imm,
                            TextRenderer.TextLayerType.SEE_THROUGH,
                            0x20000000,
                            15728880);
                    matrices.pop();
                }
                imm.draw();
            }

            // 2. Render Frozen Player above-head tags
            FROZEN_TRACKER.renderHeadLabels(matrices, camera, mc);

            // 3. Render custom enchant head labels (Love Birds stun, etc.)
            CustomHeadLabelManager.renderHeadLabels(matrices, camera, mc);
            RunicObstructionManager.renderHeadLabels(matrices, camera, mc);

            // 4. Render custom glow outlines for affected players
            if (!CustomGlowManager.activeGlowIds.isEmpty()) {
                for (net.minecraft.entity.player.PlayerEntity p : mc.world.getPlayers()) {
                    if (!CustomGlowManager.activeGlowIds.contains(p.getId())) continue;
                    if (p == mc.player) continue;

                    // Pulse between two pinks to create a heartbeat glow effect
                    boolean pulse = (System.currentTimeMillis() / 400) % 2 == 0;
                    String glowText = pulse ? "\u00A7d\u2764" : "\u00A7c\u2764";
                    int glowCol = pulse ? 0xFFE84A6A : 0xFFFF69B4;
                    int width = tr.getWidth(glowText);
                    float scale = Math.max(0.5f, Math.min(4.0f, HUD_SETTINGS.labelScale));
                    float ds = 0.025f * scale;
                    float ht = HUD_SETTINGS.labelHeightOffset + 1.2f;

                    net.minecraft.client.render.VertexConsumerProvider.Immediate gImm =
                            mc.getBufferBuilders().getEntityVertexConsumers();

                    matrices.push();
                    matrices.translate(
                            p.getX() - camera.getCameraPos().x,
                            p.getY() + p.getHeight() + ht - camera.getCameraPos().y,
                            p.getZ() - camera.getCameraPos().z);
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                    matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                    matrices.scale(-ds, -ds, ds);
                    tr.draw(Text.literal(glowText), -width / 2f, 0f,
                            glowCol | 0xFF000000, false,
                            matrices.peek().getPositionMatrix(), gImm,
                            TextRenderer.TextLayerType.SEE_THROUGH,
                            0x20000000, 15728880);
                    matrices.pop();
                    gImm.draw();
                }
            }
        });
    }

    private static ItemStack resolveHoveredItem(MinecraftClient mc) {
        if (mc == null || mc.player == null) return null;

        if (mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?> hs) {
            ItemStack cursor = mc.player.currentScreenHandler.getCursorStack();
            if (!cursor.isEmpty()) return cursor;

            net.minecraft.screen.slot.Slot focused = ((HandledScreenAccessor) hs).getFocusedSlot();
            if (focused != null && focused.hasStack()) return focused.getStack();

            return null; // screen open but nothing hovered — don't fall back to held item
        }

        ItemStack held = mc.player.getMainHandStack();
        if (!held.isEmpty()) return held;
        ItemStack offHand = mc.player.getOffHandStack();
        if (!offHand.isEmpty()) return offHand;
        return null;
    }

    private void handleChatMessage(String plain) {
        String stripped = plain.replaceAll("\u00A7[0-9a-fk-orA-FK-OR]", "").trim();
        String lo = stripped.toLowerCase();

        // Pass to ability cooldowns
        ABILITY_COOLDOWN.onChat(stripped);

        // Pass to frozen player tracker
        FROZEN_TRACKER.onChat(stripped);

        // Pass to custom enchant system (Shuffle Deck, Squirting Flower, Love Birds, etc.)
        CustomCooldownSystem.onChat(stripped);

        // Pass to event schedule manager (DestroyTheCore spawn detection)
        EVENT_SCHEDULE.onChat(stripped);

        // ── Combat tag expiry ─────────────────────────────────────────────
        // Auto-send /fix after the fight ends (no notification shown).
        if (lo.contains("combat tag has expired")) {
            pendingFixCommand = true;
        }

        // ── Kill detection ────────────────────────────────────────────────
        // Server typically sends "You killed <player>" or "<player> was killed by <you>"
        String localName = MinecraftClient.getInstance() != null &&
                MinecraftClient.getInstance().player != null
                ? MinecraftClient.getInstance().player.getName().getString().toLowerCase()
                : "";
        if (!localName.isEmpty()) {
            boolean youKilledSomeone = lo.startsWith("you killed ") ||
                    (lo.contains("killed") && lo.contains("you") && lo.contains("killed by you")) ||
                    (lo.contains("✗") && lo.contains(localName) && lo.contains("kill")) ||
                    (lo.contains("was killed by " + localName));
            if (youKilledSomeone) {
                pendingKillFix = true;
            }
        }

        // ── Jack of Hearts — start 1:30 cooldown HUD tile on use ─────────
        // Detects server confirmation messages when the card is played.
        // The AutoJackOfHeartsModule also calls triggerJackOfHearts() when
        // it auto-uses the card, so manual use is covered here too.
        if ((lo.contains("jack") && lo.contains("heart"))
                && (lo.contains("used") || lo.contains("activated") || lo.contains("played"))) {
            ABILITY_COOLDOWN.triggerJackOfHearts();
        }

        // Lark status transitions parser
        if (lo.contains("lark") && lo.contains("activated") && lo.contains("50% more")) {
            LARK_MANAGER.onChatBuff();
        } else if (lo.contains("lark") && lo.contains("50% less")) {
            LARK_MANAGER.onChatDebuff();
        } else if (lo.contains("lark") && lo.contains("cooldown")) {
            LARK_MANAGER.onChatCooldown();
        }
    }

    private PlayerEntity raycastPlayer(MinecraftClient mc, double distance) {
        Entity cameraEntity = mc.getCameraEntity();
        if (cameraEntity == null || mc.world == null) return null;

        Vec3d eyePos = cameraEntity.getCameraPosVec(1.0F);
        Vec3d lookVec = cameraEntity.getRotationVec(1.0F);
        Vec3d endPos = eyePos.add(lookVec.x * distance, lookVec.y * distance, lookVec.z * distance);
        Box box = cameraEntity.getBoundingBox().expand(lookVec.x * distance, lookVec.y * distance, lookVec.z * distance).expand(1.0D, 1.0D, 1.0D);

        EntityHitResult hit = ProjectileUtil.raycast(cameraEntity, eyePos, endPos, box,
                entity -> entity instanceof PlayerEntity && entity != mc.player && !entity.isSpectator() && entity.canHit(),
                distance * distance);

        if (hit != null && hit.getType() == HitResult.Type.ENTITY) {
            return (PlayerEntity) hit.getEntity();
        }
        return null;
    }

    public static String colorize(String s) {
        if (s == null) return "";
        return s.replace("&0", "§0").replace("&1", "§1").replace("&2", "§2").replace("&3", "§3")
                .replace("&4", "§4").replace("&5", "§5").replace("&6", "§6").replace("&7", "§7")
                .replace("&8", "§8").replace("&9", "§9").replace("&a", "§a").replace("&b", "§b")
                .replace("&c", "§c").replace("&d", "§d").replace("&e", "§e").replace("&f", "§f")
                .replace("&k", "§k").replace("&l", "§l").replace("&m", "§m").replace("&n", "§n")
                .replace("&o", "§o").replace("&r", "§r");
    }

    // ── Crate Puller NBT Helpers ────────────────────────────────────────

    /**
     * Extracts the player name who pulled this item from a crate.
     *
     * Reads {@code PublicBukkitValues.scrptr:dupe_uuid} whose value is formatted as
     * {@code "playerName-unixTimestampSec:itemUUID"}.  Also checks several other
     * common puller-key names in case the server changes format.
     *
     * @return the player name string, or {@code null} if not found.
     */
    public static String extractCratePuller(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;

        var customData = stack.get(net.minecraft.component.DataComponentTypes.CUSTOM_DATA);
        if (customData == null) return null;

        net.minecraft.nbt.NbtCompound tag = customData.copyNbt();

        net.minecraft.nbt.NbtCompound pbv =
                tag.getCompound("PublicBukkitValues").orElse(null);

        if (pbv == null) return null;

        String raw = pbv.getString("scrptr:dupe_uuid").orElse(null);

        if (raw == null || raw.isEmpty()) {
            return null;
        }

        // Remove anything after :
        int colon = raw.indexOf(':');
        String firstPart = colon == -1 ? raw : raw.substring(0, colon);

        // Return everything before the first dash
        int dash = firstPart.indexOf('-');

        if (dash > 0) {
            return firstPart.substring(0, dash);
        }

        return firstPart;
    }

    /**
     * Returns the Unix epoch-second timestamp embedded in {@code scrptr:dupe_uuid},
     * or {@code 0} if it cannot be parsed.
     */
    public static long extractPullTimestamp(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return 0;
        net.minecraft.component.type.NbtComponent customData =
                stack.get(net.minecraft.component.DataComponentTypes.CUSTOM_DATA);
        if (customData == null) return 0;
        net.minecraft.nbt.NbtCompound tag = customData.copyNbt();
        net.minecraft.nbt.NbtCompound pbv = tag.getCompound("PublicBukkitValues").orElse(null);
        if (pbv == null) return 0;

        String raw = pbv.getString("scrptr:dupe_uuid").orElse(null);
        if (raw == null || raw.isEmpty()) return 0;
        int colonIdx = raw.indexOf(':');
        if (colonIdx <= 0) return 0;
        String playerPart = raw.substring(0, colonIdx);
        int lastDash = playerPart.lastIndexOf('-');
        if (lastDash < 0) return 0;
        String possibleTs = playerPart.substring(lastDash + 1);
        try {
            long ts = Long.parseLong(possibleTs);
            return (possibleTs.length() >= 8) ? ts : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** Formats an epoch-second timestamp as {@code "MMM d, yyyy"} in the system locale. */
    public static String formatPullDate(long epochSeconds) {
        java.time.LocalDate date = java.time.Instant.ofEpochSecond(epochSeconds)
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();
        return date.getMonth().getDisplayName(
                java.time.format.TextStyle.SHORT, java.util.Locale.US)
                + " " + date.getDayOfMonth() + ", " + date.getYear();
    }
}