package org.cheetahv2.antigravity.client.cooldown;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.cheetahv2.antigravity.client.AntigravityClient;
import org.cheetahv2.antigravity.client.detection.CustomGlowManager;
import org.cheetahv2.antigravity.client.detection.CustomHeadLabelManager;
import org.cheetahv2.antigravity.client.detection.RunicObstructionManager;
import org.cheetahv2.antigravity.client.util.RomanHelper;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * =====================================================================
 *  CUSTOM COOLDOWN SYSTEM  —  How to add a new enchant
 * =====================================================================
 *
 *  Every enchant is registered in the static block at the bottom of
 *  this file.  Pick the right builder methods for your use-case:
 *
 *  TRIGGER TYPES
 *  ─────────────
 *  .chatTrigger(keyword)
 *      Fires when YOUR ability goes off.  The chat line must contain
 *      the keyword AND "RUNES ✔".
 *      Example: "RUNES ✔ ... Your Shuffle Deck V has activated!"
 *
 *  .chatTriggerOnSelf(keyword)
 *      Same as chatTrigger, but marks the enchant as self-only so no
 *      target effects are applied even if a player name is extracted.
 *
 *  .enemyChatTrigger(keyword)
 *      Fires when an ENEMY'S ability goes off (e.g. Ra's Wrath warning).
 *      The chat line must contain the keyword AND "RUNES ⚠".
 *      No cooldown is started for you; you get a warning notification,
 *      self-effects (affectsSelf), AND target-effects on the attacker
 *      (affectsTarget) — so glow + label appear above their head.
 *
 *  .noCooldown()
 *      Enchant has no cooldown — it just fires a notification + effects
 *      every time it triggers.  Good for chance-based procs.
 *
 *  COOLDOWN LEVELS  (only needed if not .noCooldown())
 *  ─────────────────────────────────────────────────────
 *  .cooldowns(600, 480, 360, 300, 240)
 *      Pass one long per level (in seconds).  Level 1 = first value.
 *      If you pass fewer values than maxLevel the last value repeats.
 *
 *  COLOR FORMAT
 *  ────────────
 *  Colors can be written in any of these formats:
 *      "&#FA202B"       — 6-digit web hex (alpha is always FF / fully opaque)
 *      "#FA202B"        — same without the ampersand
 *      "&#FA202B80"     — 8-digit web hex (includes alpha channel)
 *      "#FA202B80"      — same without the ampersand
 *      0xFFFA202B       — classic Java int literal (still works fine)
 *      0xFA202B         — also accepted (alpha forced to FF)
 *
 *  Use CustomCooldownSystem.color("&#FA202B") anywhere a color int is needed.
 *
 *  TARGET EFFECTS  (applied to whoever was targeted / whoever attacked you)
 *  ──────────────────────────────────────────────────────────────────────────
 *  .affectsTarget(headText, glow, durationMs)
 *      Show text above the target's head and optionally make them glow (white).
 *      Fixed duration in milliseconds.
 *
 *  .affectsTarget(headText, glow, glowColor, durationMs)
 *      Same, but with a custom glow colour (e.g. color("&#4AE87A") for lime-green).
 *
 *  .affectsTargetPerLevel(headText, glow, msPerLevel)
 *      Duration = level * msPerLevel.  e.g. msPerLevel=1000 → L1=1s, L2=2s …
 *
 *  .affectsTargetPerLevel(headText, glow, glowColor, msPerLevel)
 *      Same with custom colour.
 *
 *  Head text supports {roman} and {level} placeholders.
 *  e.g. "§a🛡 RA'S WRATH {roman}" → "§a🛡 RA'S WRATH III" at level 3.
 *
 *  SELF EFFECTS  (applied to you when the enchant fires)
 *  ───────────────────────────────────────────────────────
 *  .affectsSelf(headText, glow, durationMs)
 *      Show text above YOUR head / glow yourself.  Fixed duration.
 *
 *  .affectsSelfPerLevel(headText, glow, msPerLevel)
 *      Same, but duration = level * msPerLevel.
 *
 *  ICONS & COLOUR
 *  ──────────────
 *  .icon(charOrEmoji, colorInt)           — classic int literal
 *  .icon(charOrEmoji, "&#RRGGBB")         — hex string  ← NEW
 *
 *  NOTIFICATION TEXT OVERRIDE
 *  ───────────────────────────
 *  .selfNotif("§cYou were hit by {enchant}!")
 *  .enemyNotif("§e{player} triggered {enchant}!")
 *      Use {enchant}, {player}, {level}, {roman} as placeholders.
 * =====================================================================
 */
public class CustomCooldownSystem {

    // =========================================================================
    //  COLOR HELPER  —  parse "&#RRGGBB", "#RRGGBB", "&#RRGGBBAA", or int
    // =========================================================================

    /**
     * Parse a hex color string into a packed ARGB int (0xFFRRGGBB format).
     *
     * Accepted formats:
     *   "&#FA202B"     → 0xFFFA202B  (alpha forced to FF)
     *   "#FA202B"      → 0xFFFA202B
     *   "&#FA202B80"   → 0x80FA202B  (8-digit: includes alpha)
     *   "#FA202B80"    → 0x80FA202B
     *
     * You can also just pass a plain int literal in the normal Java way
     * (e.g. 0xFFFA202B) — this method is only needed for the string form.
     */
    public static int color(String hex) {
        // Strip optional leading &
        if (hex.startsWith("&")) hex = hex.substring(1);
        // Strip #
        if (hex.startsWith("#")) hex = hex.substring(1);

        hex = hex.trim();

        try {
            if (hex.length() == 6) {
                // RGB only — force alpha to FF
                return (int)(0xFF000000L | Long.parseLong(hex, 16));
            } else if (hex.length() == 8) {
                // RRGGBBAA — rearrange to AARRGGBB
                int rgb   = (int) Long.parseLong(hex.substring(0, 6), 16);
                int alpha = (int) Long.parseLong(hex.substring(6, 8), 16);
                return (alpha << 24) | rgb;
            }
        } catch (NumberFormatException ignored) {}

        throw new IllegalArgumentException("Invalid color string: \"" + hex + "\" — expected &#RRGGBB or &#RRGGBBAA");
    }

    // =========================================================================
    //  ENCHANT DESCRIPTOR
    // =========================================================================

    public enum TriggerType {
        /** "RUNES ✔" line — YOUR enchant fired, YOU may have a cooldown. */
        SELF_CHAT,
        /** "RUNES ⚠" line — an ENEMY's enchant fired, no cooldown for you. */
        ENEMY_CHAT,
        /** Both self and enemy lines. */
        BOTH_CHAT
    }

    public static class CustomEnchant {
        // Identity
        public final String id;
        public final String displayName;
        public final int    maxLevel;

        // Trigger
        public TriggerType triggerType         = TriggerType.SELF_CHAT;
        public String      chatTriggerKeyword  = null;   // keyword for SELF_CHAT / BOTH_CHAT
        public String      enemyTriggerKeyword = null;   // keyword for ENEMY_CHAT / BOTH_CHAT

        /** When true, this enchant never reads a target name from chat. */
        public boolean selfOnly = false;

        /**
         * When true, this enchant has completely custom trigger logic and
         * the normal triggerSelf / triggerEnemy pipelines are skipped.
         * The onChat handler dispatches to the enchant's custom handler instead.
         */
        public boolean customDispatch = false;

        // Cooldown
        public boolean hasCooldown              = true;
        public long[]  cooldownsByLevelMs;               // ms, indexed 0 = level 1

        // Icon / colour shown in the HUD tile
        public String iconChar = "\u2726";
        public int    color    = 0xFFFFFFFF;

        // Effects on the TARGET (someone you hit / debuffed)
        public boolean affectsTarget                  = false;
        public String  targetAboveHeadText            = "";
        public boolean makeTargetGlow                 = false;
        public int     targetGlowColor                = 0xFFFFFF;  // RGB, default white
        public long    targetEffectDurationMs         = 4_000;
        // If > 0, duration = level * this value (overrides targetEffectDurationMs)
        public long    targetEffectDurationPerLevelMs = 0;

        // Effects on SELF (e.g. Ra's Wrath — enemy triggers it, but you get the debuff)
        public boolean affectsSelf                  = false;
        public String  selfAboveHeadText            = "";
        public boolean makeSelfGlow                 = false;
        public long    selfEffectDurationMs         = 4_000;
        // If > 0, duration = level * this value (overrides selfEffectDurationMs)
        public long    selfEffectDurationPerLevelMs = 0;

        // Notification text overrides  ({enchant} {player} {level} {roman} are replaced)
        public String selfNotifTemplate  = null;   // null = auto-generated
        public String enemyNotifTemplate = null;

        // ── Constructor ──────────────────────────────────────────────────────

        public CustomEnchant(String id, String displayName, int maxLevel) {
            this.id          = id;
            this.displayName = displayName;
            this.maxLevel    = maxLevel;
            this.cooldownsByLevelMs = new long[maxLevel];
            Arrays.fill(this.cooldownsByLevelMs, 30_000L);
        }

        // ── Builder methods ──────────────────────────────────────────────────

        /** Fires when YOUR enchant triggers ("RUNES ✔" line). */
        public CustomEnchant chatTrigger(String keyword) {
            this.triggerType        = TriggerType.SELF_CHAT;
            this.chatTriggerKeyword = keyword;
            return this;
        }

        /**
         * Like chatTrigger, but marks the enchant as self-only.
         * No target effects will be applied even if a player name appears in chat.
         */
        public CustomEnchant chatTriggerOnSelf(String keyword) {
            chatTrigger(keyword);
            this.selfOnly = true;
            return this;
        }

        /** Fires when an ENEMY's enchant triggers ("RUNES ⚠" line). */
        public CustomEnchant enemyChatTrigger(String keyword) {
            this.triggerType         = TriggerType.ENEMY_CHAT;
            this.enemyTriggerKeyword = keyword;
            return this;
        }

        /**
         * Fires on BOTH lines — useful when the enchant can appear in either
         * context (e.g. an enchant that notifies both attacker and defender).
         */
        public CustomEnchant bothChatTriggers(String selfKeyword, String enemyKeyword) {
            this.triggerType         = TriggerType.BOTH_CHAT;
            this.chatTriggerKeyword  = selfKeyword;
            this.enemyTriggerKeyword = enemyKeyword;
            return this;
        }

        /** Marks this enchant as using custom dispatch logic (skips normal pipeline). */
        public CustomEnchant useCustomDispatch() {
            this.customDispatch = true;
            return this;
        }

        /** Enchant has no cooldown — just fires a notification every proc. */
        public CustomEnchant noCooldown() {
            this.hasCooldown = false;
            Arrays.fill(this.cooldownsByLevelMs, 0L);
            return this;
        }

        /**
         * Set per-level cooldowns in SECONDS.
         * Pass values for levels 1..N.  Trailing levels reuse the last value.
         */
        public CustomEnchant cooldowns(long... secondsPerLevel) {
            for (int i = 0; i < maxLevel; i++) {
                int src = Math.min(i, secondsPerLevel.length - 1);
                this.cooldownsByLevelMs[i] = secondsPerLevel[src] * 1_000L;
            }
            return this;
        }

        /** Set icon and color using a classic int literal (e.g. 0xFFFA202B). */
        public CustomEnchant icon(String icon, int color) {
            this.iconChar = icon;
            this.color    = color;
            return this;
        }

        /** Set icon and color using a hex string (e.g. "&#FA202B" or "#FA202B"). */
        public CustomEnchant icon(String icon, String hexColor) {
            return icon(icon, CustomCooldownSystem.color(hexColor));
        }

        // ── affectsTarget ────────────────────────────────────────────────────

        /** Apply effects to whoever you hit / your target.  White glow. */
        public CustomEnchant affectsTarget(String headText, boolean glow, long durationMs) {
            return affectsTarget(headText, glow, 0xFFFFFF, durationMs);
        }

        /** Apply effects to whoever you hit / your target with a custom glow colour (int). */
        public CustomEnchant affectsTarget(String headText, boolean glow, int glowColor, long durationMs) {
            this.affectsTarget          = true;
            this.targetAboveHeadText    = headText;
            this.makeTargetGlow         = glow;
            this.targetGlowColor        = glowColor & 0x00FFFFFF;
            this.targetEffectDurationMs = durationMs;
            return this;
        }

        /** Apply effects to whoever you hit / your target with a custom glow colour (hex string). */
        public CustomEnchant affectsTarget(String headText, boolean glow, String glowHex, long durationMs) {
            return affectsTarget(headText, glow, CustomCooldownSystem.color(glowHex), durationMs);
        }

        /**
         * Like affectsTarget, but duration scales with level.
         * e.g. .affectsTargetPerLevel("§aRES", true, 1000) → level 3 = 3000ms.
         * White glow.
         */
        public CustomEnchant affectsTargetPerLevel(String headText, boolean glow, long msPerLevel) {
            return affectsTargetPerLevel(headText, glow, 0xFFFFFF, msPerLevel);
        }

        /**
         * Like affectsTargetPerLevel, but with a custom glow colour (int).
         * Head text supports {roman} and {level} — e.g. "§a🛡 RA'S WRATH {roman}".
         */
        public CustomEnchant affectsTargetPerLevel(String headText, boolean glow, int glowColor, long msPerLevel) {
            this.affectsTarget                  = true;
            this.targetAboveHeadText            = headText;
            this.makeTargetGlow                 = glow;
            this.targetGlowColor                = glowColor & 0x00FFFFFF;
            this.targetEffectDurationPerLevelMs = msPerLevel;
            return this;
        }

        /**
         * Like affectsTargetPerLevel, but with a custom glow colour (hex string).
         * e.g. .affectsTargetPerLevel("§a🛡 RA'S WRATH {roman}", true, "&#4AE87A", 1_000)
         */
        public CustomEnchant affectsTargetPerLevel(String headText, boolean glow, String glowHex, long msPerLevel) {
            return affectsTargetPerLevel(headText, glow, CustomCooldownSystem.color(glowHex), msPerLevel);
        }

        // ── affectsSelf ──────────────────────────────────────────────────────

        /** Apply effects to YOURSELF (useful for enemy-triggered enchants that debuff you). */
        public CustomEnchant affectsSelf(String headText, boolean glow, long durationMs) {
            this.affectsSelf          = true;
            this.selfAboveHeadText    = headText;
            this.makeSelfGlow         = glow;
            this.selfEffectDurationMs = durationMs;
            return this;
        }

        /**
         * Like affectsSelf, but duration scales with level.
         * e.g. .affectsSelfPerLevel("§cDEBUFFED", false, 1000) → level 3 = 3000ms
         */
        public CustomEnchant affectsSelfPerLevel(String headText, boolean glow, long msPerLevel) {
            this.affectsSelf                  = true;
            this.selfAboveHeadText            = headText;
            this.makeSelfGlow                 = glow;
            this.selfEffectDurationPerLevelMs = msPerLevel;
            return this;
        }

        /** Override the notification shown when YOUR enchant fires. */
        public CustomEnchant selfNotif(String template) {
            this.selfNotifTemplate = template;
            return this;
        }

        /** Override the notification shown when an ENEMY's enchant fires. */
        public CustomEnchant enemyNotif(String template) {
            this.enemyNotifTemplate = template;
            return this;
        }

        // ── Helpers ──────────────────────────────────────────────────────────

        public long getCooldownMs(int level) {
            int idx = Math.max(0, Math.min(level - 1, maxLevel - 1));
            return cooldownsByLevelMs[idx];
        }

        /** Returns the actual target effect duration for the given level. */
        public long resolveTargetDuration(int level) {
            if (targetEffectDurationPerLevelMs > 0) return level * targetEffectDurationPerLevelMs;
            return targetEffectDurationMs;
        }

        /** Returns the actual self effect duration for the given level. */
        public long resolveSelfDuration(int level) {
            if (selfEffectDurationPerLevelMs > 0) return level * selfEffectDurationPerLevelMs;
            return selfEffectDurationMs;
        }

        /** Returns the glow colour to use for the target at the given level. */
        public int resolveTargetGlowColor(int level) {
            return targetGlowColor;
        }

        /**
         * Expands {roman} and {level} placeholders in a head-label template.
         * Call this before passing text to CustomHeadLabelManager.
         */
        public String buildLabelText(String template, int level) {
            return template
                    .replace("{roman}", RomanHelper.toRoman(level))
                    .replace("{level}", String.valueOf(level));
        }

        public String buildSelfNotif(int level, String targetName) {
            if (selfNotifTemplate != null) {
                return fillTemplate(selfNotifTemplate, level, targetName);
            }
            String base = "\u00A7b" + displayName + " L" + level;
            if (hasCooldown) {
                base += " \u00A7fCD: \u00A7e" + AbilityCooldownManager.fmt(getCooldownMs(level));
            }
            return base;
        }

        public String buildEnemyNotif(int level, String attackerName) {
            if (enemyNotifTemplate != null) {
                return fillTemplate(enemyNotifTemplate, level, attackerName);
            }
            return "\u00A7c\u26A0 " + (attackerName != null ? attackerName : "Someone")
                    + " triggered \u00A7e" + displayName + " " + RomanHelper.toRoman(level)
                    + "\u00A7c on you!";
        }

        private String fillTemplate(String tpl, int level, String playerName) {
            return tpl
                    .replace("{enchant}", displayName)
                    .replace("{level}",   String.valueOf(level))
                    .replace("{roman}",   RomanHelper.toRoman(level))
                    .replace("{player}",  playerName != null ? playerName : "?")
                    .replace("{cd}",      hasCooldown ? AbilityCooldownManager.fmt(getCooldownMs(level)) : "none");
        }
    }

    // =========================================================================
    //  REGISTRY
    // =========================================================================

    public static final List<CustomEnchant>        REGISTRY = new ArrayList<>();
    private static final Map<String, CustomEnchant> BY_ID   = new LinkedHashMap<>();

    public static void register(CustomEnchant enchant) {
        REGISTRY.add(enchant);
        BY_ID.put(enchant.id, enchant);
    }

    static {

        // ─────────────────────────────────────────────────────────────────────
        //  SHUFFLE DECK  (Boots)
        //  Removes all other rune cooldowns.
        //  Chat: "RUNES ✔ ... Your Shuffle Deck V has activated!"
        //  Cooldown: L5=4m  L4=5m  L3=6m  L2=8m  L1=10m
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("shuffle_deck", "Shuffle Deck", 5)
                .chatTrigger("shuffle deck")
                .cooldowns(600, 480, 360, 300, 240) // L1→L5 in seconds
                .icon("\uD83C\uDCCF", "&#FA202B")
                .selfNotif("\u00A7b\uD83C\uDCCF Shuffle Deck L{level} \u00A7factivated! CD: \u00A7e{cd}")
        );

        // ─────────────────────────────────────────────────────────────────────
        //  INVOCATION
        //  Chat: "RUNES ✔ ... Invocation ..."
        //  Flat 60s cooldown all levels
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("invocation", "Invocation", 5)
                .chatTrigger("Invocation")
                .cooldowns(60)
                .icon("\u26A1", "&#F939AE")
        );

        register(new CustomEnchant("swift_strike", "Swift Strike", 5)
                .chatTrigger("Swift Strike")
                .cooldowns(40)
                .icon("⚛", "&#289452")
        );

        register(new CustomEnchant("circus_cannon", "Circus Cannon", 5)
                .chatTrigger("Circus Cannon")
                .cooldowns(90)
                .icon("\uD83E\uDD21", "&#FFED2C")
        );

        register(new CustomEnchant("illusion", "Illusion", 5)
                .chatTrigger("is deceiving your foes!")
                .cooldowns(180)
                .icon("\uD83E\uDD87", "&#994C64")
        );

        register(new CustomEnchant("snake_eyes", "Snake Eyes", 5)
                .chatTrigger("Snake Eyes")
                .cooldowns(15)
                .icon("\uD83C\uDCA1", "&#FA202B")
        );

        register(new CustomEnchant("beeswax", "Beeswax", 5)
                .chatTrigger("Beeswax")
                .cooldowns(8)
                .icon("\uD83D\uDC1D", "&#FED730")
        );

        register(new CustomEnchant("lifebuoy", "Lifebuoy", 5)
                .chatTrigger("Lifebuoy")
                .cooldowns(120)
                .icon("\uD83C\uDF34", "&#B2FD4A")
        );

        register(new CustomEnchant("light_speed", "Light Speed", 5)
                .chatTrigger("Light Speed")
                .cooldowns(60)
                .icon("⟁", "&#FF3AB2")
        );

        register(new CustomEnchant("overhead_spin", "Overhead Spin", 5)
                .chatTrigger("Overhead Spin")
                .cooldowns(30, 50, 70, 90, 110)
                .icon("\uD83C\uDF34", "&#B2FD4A")
        );

        register(new CustomEnchant("deep_freeze", "Deep Freeze", 5)
                .chatTrigger("Deep Freeze")
                .cooldowns(15)
                .icon("⧩", "&#B3EFFF")
        );

        register(new CustomEnchant("lifeforce", "Lifeforce", 6)
                .chatTrigger("Lifeforce")
                .cooldowns(5)
                .icon("◆", "&#FF2929")
        );


        register(new CustomEnchant("dasher", "Dasher", 3)
                .chatTrigger("is usable again")
                .cooldowns(9)
                .icon("◆", "&#AC43F7")
        );

        register(new CustomEnchant("plaugeweaver", "Plaugeweaver", 5)
                .chatTrigger("has been activated, saving")
                .cooldowns(600)
                .icon("◆", "&#FFD700")
        );

        register(new CustomEnchant("raging_smash", "Raging Smash", 5)
                .chatTrigger("Raging Smash")
                .cooldowns(140, 130, 120, 110, 100)
                .icon("◆", "&#AC43F7")
        );


        register(new CustomEnchant("toxic_forcefield", "Toxic Forcefield", 5)
                .chatTrigger("Toxic Forcefield")
                .cooldowns(300, 285, 270, 255, 240)
                .icon("☠", "&#FB7800")
        );


        register(new CustomEnchant("ascent", "Ascent", 5)
                .chatTrigger("Ascent")
                .cooldowns(150, 120, 90, 60, 30)
                .icon("\uD83C\uDF1F", "&#FFBE49")
        );

        register(new CustomEnchant("power_pylon", "Power Pylon", 5)
                .chatTrigger("Power Pylon")
                .cooldowns(180)
                .icon("\u26A1", "&#33CCFF")
        );

        register(new CustomEnchant("rain_dance", "Rain Dance", 5)
                .chatTrigger("Rain Dance")
                .cooldowns(180)
                .icon("\uD83D\uDC7A", "&#9FFB09")
        );

        // ─────────────────────────────────────────────────────────────────────
        //  SQUIRTING FLOWER  (chance proc — no cooldown, just a notification)
        //  Chat: "RUNES ✔ ... squirting flower ..."
        //  Effect on attacker: show "💧 DROWNING" above head, make them glow
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("squirting_flower", "Squirting Flower", 5)
                .chatTrigger("squirting flower")
                .noCooldown()
                .affectsTarget("\u00A77\uD83D\uDCA7 DROWNING", true, "&#33CCFF", 10_000)
                .icon("\uD83D\uDCA6", "&#33CCFF")
                .selfNotif("\u00A77\uD83D\uDCA6 Squirting Flower proc'd on \u00A7b{player}\u00A77!")
        );

        // ─────────────────────────────────────────────────────────────────────
        //  LOVE BIRDS  (chance proc — stun target)
        //  Chat: "RUNES ✔ ... love birds ..."
        //  Shows "❤ STUNNED ❤" above target's head, makes them glow pink
        //  Flat 20s cooldown all levels
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("love_birds", "Love Birds", 5)
                .chatTrigger("love birds")
                .cooldowns(20)
                .affectsTarget("\u00A7d\u2764 STUNNED \u2764", true, "&#E84A6A", 4_000)
                .icon("\u2764", "&#E84A6A")
                .selfNotif("\u00A7d\u2764 Love Birds stunned \u00A7b{player}\u00A7d! CD: \u00A7e{cd}")
        );


        // ─────────────────────────────────────────────────────────────────────
        //  LOVESTRUCK  (stun variant)
        //  Cooldown: L5=40s  L4=60s  L3=80s  L2=100s  L1=120s
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("lovestruck", "Lovestruck", 5)
                .chatTrigger("lovestruck")
                .cooldowns(120, 100, 80, 60, 40)
                .affectsTarget("\u00A7d\u2764 Lovestruck \u2764", true, "&#E84A6A", 2_000)
                .icon("\uD83D\uDC98", "&#FF5B9B")
        );

        // ─────────────────────────────────────────────────────────────────────
        //  RA'S WRATH  (Helmet, Ancient Crate Exclusive)
        //  When someone combos YOU, 10% chance you gain Resistance and THEY
        //  get Blindness + Mining Fatigue + Slowness.
        //  Duration = 1 second per level (L1=1s, L2=2s ... L5=5s).
        //
        //  YOUR enchant fires  → "RUNES ✔ ... Your Ra's Wrath III has activated!"
        //    → attacker glows green + label "RA'S WRATH III" above their head
        //
        //  ENEMY's enchant fires → "RUNES ⚠ Your combo on X activated their Ra's Wrath III!"
        //    → attacker ALSO glows green + label above head  (bug fix: was missing)
        //    → you get a warning notification + "⚠ DEBUFFED" above your own head
        //
        //  To change the glow colour, edit the 3rd argument of affectsTargetPerLevel().
        //  To change the duration scaling, edit the 4th argument (ms per level).
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("raswrath", "Ra's Wrath", 5)
                .bothChatTriggers("ra's wrath", "ra's wrath")
                .useCustomDispatch()
                .noCooldown()
                .affectsTargetPerLevel("\u00A7a\uD83D\uDEE1 RA'S WRATH {roman}", true, "&#4AE87A", 1_000)
                .affectsSelf("\u00A7c\u26A0 DEBUFFED", false, 5_000)
                .icon("\uD83D\uDEE1", "&#4AE87A")
                .selfNotif("\u00A7a\uD83D\uDEE1 Ra's Wrath {roman} fired! \u00A7f{player} glowing for {level}s!")
                .enemyNotif("\u00A7c\u26A0 {player}'s Ra's Wrath {roman} activated! \u00A7fDebuffed for {level}s!")
        );

        // ─────────────────────────────────────────────────────────────────────
        //  RUNIC OBSTRUCTION  (disables the target's custom enchants)
        //
        //  YOUR enchant fires (RUNES ✔):
        //    Chat contains: "You have disabled the rune effects of %PLAYER% with your
        //                    Runic Obstruction %LEVEL% for %SECONDS% seconds."
        //    → Target gets yellow glow + "⛔ RUNICED" above head
        //    → Cooldown is tracked (L1=30s … L6=15s, tune as needed)
        //
        //  ENEMY's enchant fires (RUNES ⚠):
        //    Chat contains: "%ATTACKER% has prevented your custom enchants from working
        //                    for %SECONDS% seconds with their Runic Obstruction %LEVEL%."
        //    → Title "⛔ RUNICED!" is shown to YOU
        //    → Sound plays
        //    → Suppression state set in RunicObstructionManager
        //
        //  Both sides are parsed in onChat() below via custom dispatch.
        // ─────────────────────────────────────────────────────────────────────
        register(new CustomEnchant("runic_obstruction", "Runic Obstruction", 6)
                .bothChatTriggers("runic obstruction", "runic obstruction")
                .useCustomDispatch()
                .cooldowns(30, 27, 24, 21, 18, 15)   // L1→L6 in seconds
                .icon("\u26D4", "&#FFD700")           // ⛔ in gold
        );

        // ─────────────────────────────────────────────────────────────────────
        //  ADD YOUR OWN ENCHANTS BELOW THIS LINE
        //
        //  Template — copy, uncomment, and fill in:
        //
        //  register(new CustomEnchant("my_enchant_id", "My Enchant Name", /*maxLevel*/ 5)
        //          .chatTrigger("keyword in chat")   // or .enemyChatTrigger / .bothChatTriggers
        //          .cooldowns(60)                    // or .noCooldown()
        //          .affectsTarget("§eSTUNNED", true, "&#FFAA00", 4_000)  // hex color string
        //          .affectsSelf("§aRES ACTIVE", false, 5_000)             // optional
        //          .icon("⚡", "&#33CCFF")                                // hex color string
        //          .selfNotif("§bMy Enchant fired! CD: §e{cd}")
        //          .enemyNotif("§c{player} triggered My Enchant {roman} on you!")
        //  );
        // ─────────────────────────────────────────────────────────────────────

    }

    // =========================================================================
    //  CHAT HANDLER  —  called by AntigravityClient on every chat msg
    // =========================================================================

    private static final Pattern LEVEL_PATTERN = Pattern.compile("\\b([IVX]{1,5})\\b");

    // Parses the seconds value from Runic Obstruction messages.
    // Matches "for X seconds" or "for X second".
    private static final Pattern SECONDS_PATTERN = Pattern.compile("\\bfor\\s+(\\d+)\\s+seconds?\\b",
            Pattern.CASE_INSENSITIVE);

    // Dedicated pattern: finds the Roman numeral immediately after "Runic Obstruction"
    private static final Pattern RUNIC_LEVEL_PATTERN = Pattern.compile(
            "Runic\\s+Obstruction\\s+([IVX]{1,6})", Pattern.CASE_INSENSITIVE);

    /** Extracts the Runic Obstruction level from a message (looks specifically after "Runic Obstruction"). */
    private static int extractRunicLevel(String plain) {
        Matcher m = RUNIC_LEVEL_PATTERN.matcher(plain);
        if (m.find()) {
            int level = RomanHelper.fromRoman(m.group(1));
            if (level > 0) return level;
        }
        return 1;
    }

    /**
     * Pass in the raw chat string (with or without § codes).
     * This method checks both "RUNES ✔" (self) and "RUNES ⚠" (enemy) lines.
     */
    public static void onChat(String plain) {
        boolean isSelfLine  = plain.contains("RUNES \u2714"); // ✔
        boolean isEnemyLine = plain.contains("RUNES \u26A0"); // ⚠

        if (!isSelfLine && !isEnemyLine) return;

        String lo = plain.toLowerCase();

        for (CustomEnchant enchant : REGISTRY) {
            boolean matchesSelf  = isSelfLine
                    && enchant.chatTriggerKeyword  != null
                    && (enchant.triggerType == TriggerType.SELF_CHAT || enchant.triggerType == TriggerType.BOTH_CHAT)
                    && lo.contains(enchant.chatTriggerKeyword.toLowerCase());

            boolean matchesEnemy = isEnemyLine
                    && enchant.enemyTriggerKeyword != null
                    && (enchant.triggerType == TriggerType.ENEMY_CHAT || enchant.triggerType == TriggerType.BOTH_CHAT)
                    && lo.contains(enchant.enemyTriggerKeyword.toLowerCase());

            if (!matchesSelf && !matchesEnemy) continue;

            int level = extractLevel(plain);

            // ── Custom dispatch: Runic Obstruction / Ra's Wrath ─────────────
            if (enchant.customDispatch) {
                if (enchant.id.equals("raswrath")) {
                    if (matchesSelf) {
                        handleRasWrathSelf(enchant, level, plain);
                    } else if (matchesEnemy) {
                        handleRasWrathEnemy(enchant, level, plain);
                    }
                } else {
                    // Runic Obstruction (and any future custom-dispatch enchants)
                    int runicLevel = extractRunicLevel(plain);
                    if (matchesSelf) {
                        handleRunicObstructionSelf(enchant, runicLevel, plain);
                    } else {
                        handleRunicObstructionEnemy(runicLevel, plain);
                    }
                }
                break;
            }

            // ── Normal dispatch ──────────────────────────────────────────────
            if (matchesSelf) {
                // selfOnly enchants never read a target name
                String target = enchant.selfOnly ? null : extractPlayerName(plain, false);
                triggerSelf(enchant, level, target);
            } else {
                // matchesEnemy — the player named in chat attacked/targeted us
                String attacker = extractPlayerName(plain, true);
                triggerEnemy(enchant, level, attacker);
            }

            break; // one enchant per message
        }
    }

    // =========================================================================
    //  RA'S WRATH — custom dispatch handlers
    // =========================================================================

    /**
     * YOUR Ra's Wrath fired (RUNES ✔ line).
     *
     * Message: "RUNES ✔ <ATTACKER> has a combo of N on you! Your Ra's Wrath <ROMAN> has activated!"
     *
     * Guard: must contain "your ra's wrath" — distinguishes it from the enemy line
     * which would say "activated their ra's wrath".
     *
     * The person named in the message (Deafs, etc.) is the one who comboed you —
     * they ARE the target that Ra's Wrath retaliates against.
     */
    private static void handleRasWrathSelf(CustomEnchant enchant, int level, String plain) {
        String lo = plain.toLowerCase();

        // Guard: only fire on the self message
        if (!lo.contains("your ra's wrath") && !lo.contains("your ra\u2019s wrath")) return;

        // The combo attacker is the target Ra's Wrath hits
        String target = extractPlayerName(plain, false);

        // Apply glow + label to the attacker (they got debuffed)
        if (target != null && !target.isEmpty()) {
            long dur = enchant.resolveTargetDuration(level);
            if (enchant.makeTargetGlow) {
                CustomGlowManager.registerGlow(target, dur, enchant.resolveTargetGlowColor(level));
            }
            if (!enchant.targetAboveHeadText.isEmpty()) {
                String labelText = enchant.buildLabelText(enchant.targetAboveHeadText, level);
                CustomHeadLabelManager.registerLabel(target, labelText, dur);
            }
        }
    }

    /**
     * An ENEMY's Ra's Wrath fired against YOU (RUNES ⚠ line).
     *
     * Message: "RUNES ⚠ Your combo on <TARGET> activated their Ra's Wrath <ROMAN>!"
     *  or similar server phrasing.
     *
     * Guard: must contain "their ra's wrath" — distinguishes it from your own.
     */
    private static void handleRasWrathEnemy(CustomEnchant enchant, int level, String plain) {
        String lo = plain.toLowerCase();

        // Guard: only fire on the enemy message
        if (!lo.contains("their ra's wrath") && !lo.contains("their ra\u2019s wrath")
                && !lo.contains("activated their")) return;

        // The attacker is the player whose Ra's Wrath fired (they had the enchant)
        String attacker = extractPlayerName(plain, true);

        // Glow the attacker (whose Ra's Wrath fired) above their head
        if (attacker != null && !attacker.isEmpty()) {
            long dur = enchant.resolveTargetDuration(level);
            if (enchant.makeTargetGlow) {
                CustomGlowManager.registerGlow(attacker, dur, enchant.resolveTargetGlowColor(level));
            }
            if (!enchant.targetAboveHeadText.isEmpty()) {
                String labelText = enchant.buildLabelText(enchant.targetAboveHeadText, level);
                CustomHeadLabelManager.registerLabel(attacker, labelText, dur);
            }
        }

        // Apply debuff label above YOUR OWN head
        if (enchant.affectsSelf) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                String myName = mc.player.getName().getString();
                long dur = enchant.resolveSelfDuration(level);
                if (!enchant.selfAboveHeadText.isEmpty()) {
                    CustomHeadLabelManager.registerLabel(myName, enchant.selfAboveHeadText, dur);
                }
            }
        }
    }

    // =========================================================================
    //  RUNIC OBSTRUCTION — custom dispatch handlers
    // =========================================================================

    /**
     * YOUR Runic Obstruction fired (RUNES ✔ line).
     *
     * Expected message pattern (after stripping § codes):
     *   "RUNES ✔ ... You have disabled the rune effects of PLAYER with your
     *    Runic Obstruction ROMAN for SECONDS seconds."
     *
     * Guard: if the message does NOT contain "you have disabled" or "with your runic",
     * it is not a self-fired runic line — skip to avoid false triggers.
     */
    private static void handleRunicObstructionSelf(CustomEnchant enchant, int level, String plain) {
        String lo = plain.toLowerCase();

        // Safety guard: ensure this is the self-fired message, not a false match
        boolean isSelfFireMessage = lo.contains("you have disabled") || lo.contains("with your runic");
        if (!isSelfFireMessage) return;

        // Extract target player name (the person YOU runiced)
        String target = extractPlayerName(plain, false);

        // Extract duration (seconds) from "for X seconds"
        int seconds = extractSeconds(plain);
        if (seconds <= 0) seconds = level; // fallback: 1s per level
        long durationMs = seconds * 1_000L;

        // Register cooldown tile on the HUD
        if (enchant.hasCooldown) {
            AbilityCooldownManager.CooldownInstance inst = new AbilityCooldownManager.CooldownInstance(
                    enchant.id,
                    enchant.displayName + " " + RomanHelper.toRoman(level),
                    enchant.getCooldownMs(level),
                    enchant.iconChar,
                    enchant.color
            );
            AntigravityClient.ABILITY_COOLDOWN.getConfig().settings
                    .computeIfAbsent(enchant.id, k -> new AbilityCooldownManager.AbilitySetting());
            AntigravityClient.ABILITY_COOLDOWN.getActive().put(enchant.id, inst);
        }

        // Apply yellow glow + head label to target via RunicObstructionManager
        if (target != null && !target.isEmpty()) {
            RunicObstructionManager.applyTargetDebuff(target, level, durationMs);
        }

        // Show a title + subtitle so you know you successfully runiced someone
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            final String finalTarget = (target != null && !target.isEmpty()) ? target : "them";
            final int finalSecs = seconds;
            mc.send(() -> {
                mc.inGameHud.setTitle(Text.literal("§e⛔ RUNICED!"));
                mc.inGameHud.setSubtitle(Text.literal(
                        "§7Disabled §e" + finalTarget + "§7's runes for §c" + finalSecs + "s"
                ));
                mc.inGameHud.setTitleTicks(5, 40, 10);
            });
        }
    }

    /**
     * An ENEMY's Runic Obstruction suppressed YOU (RUNES ⚠ line).
     *
     * Expected message pattern (after stripping § codes):
     *   "RUNES ⚠ ... ATTACKER has prevented your custom enchants from working
     *    for SECONDS seconds with their Runic Obstruction ROMAN."
     *
     * Guard: must contain "prevented your" or "with their runic".
     */
    private static void handleRunicObstructionEnemy(int level, String plain) {
        String lo = plain.toLowerCase();

        // Safety guard: only fire on the correct enemy message
        boolean isEnemyFireMessage = lo.contains("prevented your") || lo.contains("with their runic");
        if (!isEnemyFireMessage) return;

        // Extract attacker name
        String attacker = extractPlayerName(plain, true);

        // Extract duration from the message
        int seconds = extractSeconds(plain);
        if (seconds <= 0) seconds = level; // fallback: 1s per level
        long durationMs = seconds * 1_000L;

        // Apply self-debuff: title, sound, suppression state
        RunicObstructionManager.applySelfDebuff(attacker, level, durationMs);
    }

    /** Extracts the first integer from a "for N seconds" phrase in the message. */
    private static int extractSeconds(String plain) {
        Matcher m = SECONDS_PATTERN.matcher(plain);
        if (m.find()) {
            try { return Integer.parseInt(m.group(1)); } catch (NumberFormatException ignored) {}
        }
        return 0;
    }

    // =========================================================================
    //  TRIGGER — YOUR OWN enchant fired
    // =========================================================================

    private static void triggerSelf(CustomEnchant enchant, int level, String targetName) {
        // Push a cooldown tile if this enchant has a cooldown
        if (enchant.hasCooldown) {
            AbilityCooldownManager.CooldownInstance inst = new AbilityCooldownManager.CooldownInstance(
                    enchant.id,
                    enchant.displayName + " " + RomanHelper.toRoman(level),
                    enchant.getCooldownMs(level),
                    enchant.iconChar,
                    enchant.color
            );
            AntigravityClient.ABILITY_COOLDOWN.getConfig().settings
                    .computeIfAbsent(enchant.id, k -> new AbilityCooldownManager.AbilitySetting());
            AntigravityClient.ABILITY_COOLDOWN.getActive().put(enchant.id, inst);
        }

        // Notification
        AntigravityClient.NOTIF_MANAGER.push(
                enchant.buildSelfNotif(level, targetName), enchant.color);

        // Effects on target
        if (enchant.affectsTarget && targetName != null && !targetName.isEmpty()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null
                    && !targetName.equalsIgnoreCase(mc.player.getName().getString())) {

                long dur = enchant.resolveTargetDuration(level);
                if (enchant.makeTargetGlow) {
                    // Pass the registered colour — fixes always-white glow
                    CustomGlowManager.registerGlow(targetName, dur, enchant.resolveTargetGlowColor(level));
                }
                if (!enchant.targetAboveHeadText.isEmpty()) {
                    // Expand {roman}/{level} before registering the label
                    String labelText = enchant.buildLabelText(enchant.targetAboveHeadText, level);
                    CustomHeadLabelManager.registerLabel(targetName, labelText, dur);
                }
            }
        }
    }

    // =========================================================================
    //  TRIGGER — ENEMY enchant fired (on you)
    // =========================================================================

    private static void triggerEnemy(CustomEnchant enchant, int level, String attackerName) {
        // No cooldown started for you — you're the target

        // Warning notification
        AntigravityClient.NOTIF_MANAGER.push(
                enchant.buildEnemyNotif(level, attackerName), 0xFFFF4444);

        // ── Self effects (debuff applied to YOU) ─────────────────────────────
        if (enchant.affectsSelf) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null) {
                String myName = mc.player.getName().getString();
                long dur = enchant.resolveSelfDuration(level);
                if (enchant.makeSelfGlow) {
                    CustomGlowManager.registerGlow(myName, dur);
                }
                if (!enchant.selfAboveHeadText.isEmpty()) {
                    CustomHeadLabelManager.registerLabel(myName, enchant.selfAboveHeadText, dur);
                }
            }
        }

        // ── Target effects on the ATTACKER (glow + label above their head) ──
        if (enchant.affectsTarget && attackerName != null && !attackerName.isEmpty()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null
                    && !attackerName.equalsIgnoreCase(mc.player.getName().getString())) {

                long dur = enchant.resolveTargetDuration(level);
                if (enchant.makeTargetGlow) {
                    CustomGlowManager.registerGlow(attackerName, dur, enchant.resolveTargetGlowColor(level));
                }
                if (!enchant.targetAboveHeadText.isEmpty()) {
                    // Expand {roman}/{level} placeholders before registering
                    String labelText = enchant.buildLabelText(enchant.targetAboveHeadText, level);
                    CustomHeadLabelManager.registerLabel(attackerName, labelText, dur);
                }
            }
        }
    }

    // =========================================================================
    //  PUBLIC TRIGGER  (called externally, e.g. from keybind / wield detection)
    // =========================================================================

    public static void trigger(String id, int level, String targetPlayerName) {
        CustomEnchant enchant = BY_ID.get(id);
        if (enchant != null) triggerSelf(enchant, level, targetPlayerName);
    }

    // =========================================================================
    //  onWieldUse — REMOVED (chat-only triggers, see AntigravityClient)
    // =========================================================================
    // The onWieldUse method has been intentionally removed.
    // Cooldowns now only fire from chat messages (RUNES ✔ / RUNES ⚠ lines).
    // This prevents false triggers from right-clicking on item frames, blocks,
    // or non-player entities.

    // =========================================================================
    //  HELPERS
    // =========================================================================

    /** Extracts the first Roman numeral found in the string. Returns 1 if none found. */
    private static int extractLevel(String text) {
        Matcher m = LEVEL_PATTERN.matcher(text);
        while (m.find()) {
            int parsed = RomanHelper.fromRoman(m.group(1));
            if (parsed > 0) return parsed;
        }
        return 1;
    }

    // Matches a Minecraft username: 3-16 chars, letters/digits/underscores
    private static final Pattern PLAYER_NAME_PATTERN = Pattern.compile("\\b([A-Za-z0-9_]{3,16})\\b");

    // Common words in RUNES chat messages that look like player names but aren't
    private static final Set<String> NAME_STOPWORDS = new HashSet<>(Arrays.asList(
            "your", "you", "you", "has", "have", "been", "the", "their", "they",
            "for", "and", "with", "combo", "runes", "wrath", "activated",
            "enchant", "ability", "level", "rank", "chance", "seconds",
            "second", "minutes", "damage", "effect", "proc", "true", "false",
            "shuffle", "deck", "love", "birds", "squirting", "flower",
            "lovestruck", "invocation", "runic", "obstruction", "disabled",
            "prevented", "working", "custom", "effects", "enchants"
    ));

    /**
     * Extracts a player name from a RUNES chat message.
     *
     * Pass 1: match against world players (accurate when in render range).
     * Pass 2: regex fallback — works even when attacker is far away / offline.
     */
    private static String extractPlayerName(String message, boolean preferFirst) {
        MinecraftClient mc = MinecraftClient.getInstance();
        String myName = (mc != null && mc.player != null)
                ? mc.player.getName().getString() : null;

        // Pass 1: world player list (exact match, highest confidence)
        if (mc != null && mc.world != null) {
            String msgLo = message.toLowerCase();
            for (PlayerEntity player : mc.world.getPlayers()) {
                String name = player.getName().getString();
                if (myName != null && name.equalsIgnoreCase(myName)) continue;
                if (msgLo.contains(name.toLowerCase())) {
                    return name;
                }
            }
        }

        // Pass 2: regex scan — catches attackers out of render range
        Matcher nameMatcher = PLAYER_NAME_PATTERN.matcher(message);
        while (nameMatcher.find()) {
            String token = nameMatcher.group(1);
            if (myName != null && token.equalsIgnoreCase(myName)) continue;
            if (NAME_STOPWORDS.contains(token.toLowerCase())) continue;
            // Skip pure Roman numerals (I, II, III, IV, V, VI ...)
            if (RomanHelper.fromRoman(token) > 0) continue;
            return token;
        }

        return null;
    }
}